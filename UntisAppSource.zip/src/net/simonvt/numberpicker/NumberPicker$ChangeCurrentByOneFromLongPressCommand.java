// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package net.simonvt.numberpicker;


// Referenced classes of package net.simonvt.numberpicker:
//            NumberPicker

class this._cls0
    implements Runnable
{

    private boolean mIncrement;
    final NumberPicker this$0;

    private void setStep(boolean flag)
    {
        mIncrement = flag;
    }

    public void run()
    {
        NumberPicker.access$200(NumberPicker.this, mIncrement);
        postDelayed(this, NumberPicker.access$1800(NumberPicker.this));
    }


    ()
    {
        this$0 = NumberPicker.this;
        super();
    }
}
