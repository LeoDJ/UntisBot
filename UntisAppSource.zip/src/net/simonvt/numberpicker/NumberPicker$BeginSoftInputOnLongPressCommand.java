// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package net.simonvt.numberpicker;


// Referenced classes of package net.simonvt.numberpicker:
//            NumberPicker

class this._cls0
    implements Runnable
{

    final NumberPicker this$0;

    public void run()
    {
        NumberPicker.access$1900(NumberPicker.this);
        NumberPicker.access$2002(NumberPicker.this, true);
    }

    ()
    {
        this$0 = NumberPicker.this;
        super();
    }
}
