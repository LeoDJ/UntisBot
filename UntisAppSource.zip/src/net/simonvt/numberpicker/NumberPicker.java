// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package net.simonvt.numberpicker;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.method.NumberKeyListener;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityNodeProvider;
import android.view.animation.DecelerateInterpolator;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

// Referenced classes of package net.simonvt.numberpicker:
//            Scroller

public class NumberPicker extends LinearLayout
{
    class AccessibilityNodeProviderImpl extends AccessibilityNodeProvider
    {

        private static final int UNDEFINED = 0x80000000;
        private static final int VIRTUAL_VIEW_ID_DECREMENT = 3;
        private static final int VIRTUAL_VIEW_ID_INCREMENT = 1;
        private static final int VIRTUAL_VIEW_ID_INPUT = 2;
        private int mAccessibilityFocusedView;
        private final int mTempArray[] = new int[2];
        private final Rect mTempRect = new Rect();
        final NumberPicker this$0;

        private AccessibilityNodeInfo createAccessibilityNodeInfoForNumberPicker(int i, int j, int k, int l)
        {
            AccessibilityNodeInfo accessibilitynodeinfo = AccessibilityNodeInfo.obtain();
            accessibilitynodeinfo.setClassName(net/simonvt/numberpicker/NumberPicker.getName());
            accessibilitynodeinfo.setPackageName(getContext().getPackageName());
            accessibilitynodeinfo.setSource(NumberPicker.this);
            if (hasVirtualDecrementButton())
            {
                accessibilitynodeinfo.addChild(NumberPicker.this, 3);
            }
            accessibilitynodeinfo.addChild(NumberPicker.this, 2);
            if (hasVirtualIncrementButton())
            {
                accessibilitynodeinfo.addChild(NumberPicker.this, 1);
            }
            accessibilitynodeinfo.setParent((View)getParentForAccessibility());
            accessibilitynodeinfo.setEnabled(isEnabled());
            accessibilitynodeinfo.setScrollable(true);
            if (mAccessibilityFocusedView != -1)
            {
                accessibilitynodeinfo.addAction(64);
            }
            if (mAccessibilityFocusedView == -1)
            {
                accessibilitynodeinfo.addAction(128);
            }
            if (isEnabled())
            {
                if (getWrapSelectorWheel() || getValue() < getMaxValue())
                {
                    accessibilitynodeinfo.addAction(4096);
                }
                if (getWrapSelectorWheel() || getValue() > getMinValue())
                {
                    accessibilitynodeinfo.addAction(8192);
                }
            }
            return accessibilitynodeinfo;
        }

        private AccessibilityNodeInfo createAccessibilityNodeInfoForVirtualButton(int i, String s, int j, int k, int l, int i1)
        {
            AccessibilityNodeInfo accessibilitynodeinfo = AccessibilityNodeInfo.obtain();
            accessibilitynodeinfo.setClassName(android/widget/Button.getName());
            accessibilitynodeinfo.setPackageName(getContext().getPackageName());
            accessibilitynodeinfo.setSource(NumberPicker.this, i);
            accessibilitynodeinfo.setParent(NumberPicker.this);
            accessibilitynodeinfo.setText(s);
            accessibilitynodeinfo.setClickable(true);
            accessibilitynodeinfo.setLongClickable(true);
            accessibilitynodeinfo.setEnabled(isEnabled());
            s = mTempRect;
            s.set(j, k, l, i1);
            accessibilitynodeinfo.setBoundsInParent(s);
            int ai[] = mTempArray;
            getLocationOnScreen(ai);
            s.offset(ai[0], ai[1]);
            accessibilitynodeinfo.setBoundsInScreen(s);
            if (mAccessibilityFocusedView != i)
            {
                accessibilitynodeinfo.addAction(64);
            }
            if (mAccessibilityFocusedView == i)
            {
                accessibilitynodeinfo.addAction(128);
            }
            if (isEnabled())
            {
                accessibilitynodeinfo.addAction(16);
            }
            return accessibilitynodeinfo;
        }

        private AccessibilityNodeInfo createAccessibiltyNodeInfoForInputText()
        {
            AccessibilityNodeInfo accessibilitynodeinfo = mInputText.createAccessibilityNodeInfo();
            accessibilitynodeinfo.setSource(NumberPicker.this, 2);
            if (mAccessibilityFocusedView != 2)
            {
                accessibilitynodeinfo.addAction(64);
            }
            if (mAccessibilityFocusedView == 2)
            {
                accessibilitynodeinfo.addAction(128);
            }
            return accessibilitynodeinfo;
        }

        private void findAccessibilityNodeInfosByTextInChild(String s, int i, List list)
        {
            i;
            JVM INSTR tableswitch 1 3: default 28
        //                       1 171
        //                       2 71
        //                       3 29;
               goto _L1 _L2 _L3 _L4
_L1:
            Object obj;
            return;
_L4:
            if (!TextUtils.isEmpty(((CharSequence) (obj = getVirtualDecrementButtonText()))) && ((String) (obj)).toString().toLowerCase().contains(s))
            {
                list.add(createAccessibilityNodeInfo(3));
                return;
            }
            continue; /* Loop/switch isn't completed */
_L3:
            obj = mInputText.getText();
            if (!TextUtils.isEmpty(((CharSequence) (obj))) && ((CharSequence) (obj)).toString().toLowerCase().contains(s))
            {
                list.add(createAccessibilityNodeInfo(2));
                return;
            }
            obj = mInputText.getText();
            if (!TextUtils.isEmpty(((CharSequence) (obj))) && ((CharSequence) (obj)).toString().toLowerCase().contains(s))
            {
                list.add(createAccessibilityNodeInfo(2));
                return;
            }
            continue; /* Loop/switch isn't completed */
_L2:
            if (!TextUtils.isEmpty(((CharSequence) (obj = getVirtualIncrementButtonText()))) && ((String) (obj)).toString().toLowerCase().contains(s))
            {
                list.add(createAccessibilityNodeInfo(1));
                return;
            }
            if (true) goto _L1; else goto _L5
_L5:
        }

        private String getVirtualDecrementButtonText()
        {
            int j = mValue - 1;
            int i = j;
            if (mWrapSelectorWheel)
            {
                i = getWrappedSelectorIndex(j);
            }
            if (i >= mMinValue)
            {
                if (mDisplayedValues == null)
                {
                    return formatNumber(i);
                } else
                {
                    return mDisplayedValues[i - mMinValue];
                }
            } else
            {
                return null;
            }
        }

        private String getVirtualIncrementButtonText()
        {
            int j = mValue + 1;
            int i = j;
            if (mWrapSelectorWheel)
            {
                i = getWrappedSelectorIndex(j);
            }
            if (i <= mMaxValue)
            {
                if (mDisplayedValues == null)
                {
                    return formatNumber(i);
                } else
                {
                    return mDisplayedValues[i - mMinValue];
                }
            } else
            {
                return null;
            }
        }

        private boolean hasVirtualDecrementButton()
        {
            return getWrapSelectorWheel() || getValue() > getMinValue();
        }

        private boolean hasVirtualIncrementButton()
        {
            return getWrapSelectorWheel() || getValue() < getMaxValue();
        }

        private void sendAccessibilityEventForVirtualButton(int i, int j, String s)
        {
            if (((AccessibilityManager)getContext().getSystemService("accessibility")).isEnabled())
            {
                AccessibilityEvent accessibilityevent = AccessibilityEvent.obtain(j);
                accessibilityevent.setClassName(android/widget/Button.getName());
                accessibilityevent.setPackageName(getContext().getPackageName());
                accessibilityevent.getText().add(s);
                accessibilityevent.setEnabled(isEnabled());
                accessibilityevent.setSource(NumberPicker.this, i);
                requestSendAccessibilityEvent(NumberPicker.this, accessibilityevent);
            }
        }

        private void sendAccessibilityEventForVirtualText(int i)
        {
            if (((AccessibilityManager)getContext().getSystemService("accessibility")).isEnabled())
            {
                AccessibilityEvent accessibilityevent = AccessibilityEvent.obtain(i);
                mInputText.onInitializeAccessibilityEvent(accessibilityevent);
                mInputText.onPopulateAccessibilityEvent(accessibilityevent);
                accessibilityevent.setSource(NumberPicker.this, 2);
                requestSendAccessibilityEvent(NumberPicker.this, accessibilityevent);
            }
        }

        public AccessibilityNodeInfo createAccessibilityNodeInfo(int i)
        {
            switch (i)
            {
            case 0: // '\0'
            default:
                return super.createAccessibilityNodeInfo(i);

            case -1: 
                return createAccessibilityNodeInfoForNumberPicker(getScrollX(), getScrollY(), getScrollX() + (getRight() - getLeft()), getScrollY() + (getBottom() - getTop()));

            case 3: // '\003'
                String s = getVirtualDecrementButtonText();
                i = getScrollX();
                int j = getScrollY();
                int l = getScrollX();
                int j1 = getRight();
                int l1 = getLeft();
                int j2 = mTopSelectionDividerTop;
                return createAccessibilityNodeInfoForVirtualButton(3, s, i, j, (j1 - l1) + l, mSelectionDividerHeight + j2);

            case 2: // '\002'
                return createAccessibiltyNodeInfoForInputText();

            case 1: // '\001'
                String s1 = getVirtualIncrementButtonText();
                i = getScrollX();
                int k = mBottomSelectionDividerBottom;
                int i1 = mSelectionDividerHeight;
                int k1 = getScrollX();
                int i2 = getRight();
                int k2 = getLeft();
                int l2 = getScrollY();
                return createAccessibilityNodeInfoForVirtualButton(1, s1, i, k - i1, (i2 - k2) + k1, (getBottom() - getTop()) + l2);
            }
        }

        public List findAccessibilityNodeInfosByText(String s, int i)
        {
            if (TextUtils.isEmpty(s))
            {
                return Collections.emptyList();
            }
            String s1 = s.toLowerCase();
            ArrayList arraylist = new ArrayList();
            switch (i)
            {
            case 0: // '\0'
            default:
                return super.findAccessibilityNodeInfosByText(s, i);

            case -1: 
                findAccessibilityNodeInfosByTextInChild(s1, 3, arraylist);
                findAccessibilityNodeInfosByTextInChild(s1, 2, arraylist);
                findAccessibilityNodeInfosByTextInChild(s1, 1, arraylist);
                return arraylist;

            case 1: // '\001'
            case 2: // '\002'
            case 3: // '\003'
                findAccessibilityNodeInfosByTextInChild(s1, i, arraylist);
                break;
            }
            return arraylist;
        }

        public boolean performAction(int i, int j, Bundle bundle)
        {
            boolean flag1;
            boolean flag2;
            flag2 = false;
            flag1 = false;
            i;
            JVM INSTR tableswitch -1 3: default 40
        //                       -1 52
        //                       0 40
        //                       1 520
        //                       2 271
        //                       3 701;
               goto _L1 _L2 _L1 _L3 _L4 _L5
_L1:
            boolean flag = super.performAction(i, j, bundle);
_L10:
            return flag;
_L2:
            j;
            JVM INSTR lookupswitch 4: default 96
        //                       64: 99
        //                       128: 129
        //                       4096: 161
        //                       8192: 216;
               goto _L1 _L6 _L7 _L8 _L9
_L6:
            flag = flag1;
            if (mAccessibilityFocusedView != i)
            {
                mAccessibilityFocusedView = i;
                performAccessibilityAction(64, null);
                return true;
            }
              goto _L10
_L7:
            flag = flag1;
            if (mAccessibilityFocusedView == i)
            {
                mAccessibilityFocusedView = 0x80000000;
                performAccessibilityAction(128, null);
                return true;
            }
              goto _L10
_L8:
            flag = flag1;
            if (!isEnabled()) goto _L10; else goto _L11
_L11:
            if (getWrapSelectorWheel())
            {
                break; /* Loop/switch isn't completed */
            }
            flag = flag1;
            if (getValue() >= getMaxValue()) goto _L10; else goto _L12
_L12:
            changeValueByOne(true);
            return true;
_L9:
            flag = flag1;
            if (!isEnabled()) goto _L10; else goto _L13
_L13:
            if (getWrapSelectorWheel())
            {
                break; /* Loop/switch isn't completed */
            }
            flag = flag1;
            if (getValue() <= getMinValue()) goto _L10; else goto _L14
_L14:
            changeValueByOne(false);
            return true;
_L4:
            switch (j)
            {
            default:
                return mInputText.performAccessibilityAction(j, bundle);

            case 1: // '\001'
                flag = flag1;
                if (isEnabled())
                {
                    flag = flag1;
                    if (!mInputText.isFocused())
                    {
                        return mInputText.requestFocus();
                    }
                }
                break;

            case 2: // '\002'
                flag = flag1;
                if (isEnabled())
                {
                    flag = flag1;
                    if (mInputText.isFocused())
                    {
                        mInputText.clearFocus();
                        return true;
                    }
                }
                break;

            case 16: // '\020'
                flag = flag1;
                if (isEnabled())
                {
                    showSoftInput();
                    return true;
                }
                break;

            case 64: // '@'
                flag = flag1;
                if (mAccessibilityFocusedView != i)
                {
                    mAccessibilityFocusedView = i;
                    sendAccessibilityEventForVirtualView(i, 32768);
                    mInputText.invalidate();
                    return true;
                }
                break;

            case 128: 
                flag = flag1;
                if (mAccessibilityFocusedView == i)
                {
                    mAccessibilityFocusedView = 0x80000000;
                    sendAccessibilityEventForVirtualView(i, 0x10000);
                    mInputText.invalidate();
                    return true;
                }
                break;
            }
            if (true) goto _L10; else goto _L15
_L15:
_L3:
            switch (j)
            {
            default:
                return false;

            case 16: // '\020'
                flag = flag1;
                if (isEnabled())
                {
                    changeValueByOne(true);
                    sendAccessibilityEventForVirtualView(i, 1);
                    return true;
                }
                break;

            case 64: // '@'
                flag = flag1;
                if (mAccessibilityFocusedView != i)
                {
                    mAccessibilityFocusedView = i;
                    sendAccessibilityEventForVirtualView(i, 32768);
                    invalidate(0, mBottomSelectionDividerBottom, getRight(), getBottom());
                    return true;
                }
                break;

            case 128: 
                flag = flag1;
                if (mAccessibilityFocusedView == i)
                {
                    mAccessibilityFocusedView = 0x80000000;
                    sendAccessibilityEventForVirtualView(i, 0x10000);
                    invalidate(0, mBottomSelectionDividerBottom, getRight(), getBottom());
                    return true;
                }
                break;
            }
            if (true) goto _L10; else goto _L16
_L16:
_L5:
            switch (j)
            {
            default:
                return false;

            case 16: // '\020'
                flag = flag1;
                if (isEnabled())
                {
                    flag = flag2;
                    if (i == 1)
                    {
                        flag = true;
                    }
                    changeValueByOne(flag);
                    sendAccessibilityEventForVirtualView(i, 1);
                    return true;
                }
                break;

            case 64: // '@'
                flag = flag1;
                if (mAccessibilityFocusedView != i)
                {
                    mAccessibilityFocusedView = i;
                    sendAccessibilityEventForVirtualView(i, 32768);
                    invalidate(0, 0, getRight(), mTopSelectionDividerTop);
                    return true;
                }
                break;

            case 128: 
                flag = flag1;
                if (mAccessibilityFocusedView == i)
                {
                    mAccessibilityFocusedView = 0x80000000;
                    sendAccessibilityEventForVirtualView(i, 0x10000);
                    invalidate(0, 0, getRight(), mTopSelectionDividerTop);
                    return true;
                }
                break;
            }
            if (true) goto _L10; else goto _L17
_L17:
        }

        public void sendAccessibilityEventForVirtualView(int i, int j)
        {
            i;
            JVM INSTR tableswitch 1 3: default 28
        //                       1 53
        //                       2 47
        //                       3 29;
               goto _L1 _L2 _L3 _L4
_L1:
            return;
_L4:
            if (hasVirtualDecrementButton())
            {
                sendAccessibilityEventForVirtualButton(i, j, getVirtualDecrementButtonText());
                return;
            }
            continue; /* Loop/switch isn't completed */
_L3:
            sendAccessibilityEventForVirtualText(j);
            return;
_L2:
            if (hasVirtualIncrementButton())
            {
                sendAccessibilityEventForVirtualButton(i, j, getVirtualIncrementButtonText());
                return;
            }
            if (true) goto _L1; else goto _L5
_L5:
        }

        AccessibilityNodeProviderImpl()
        {
            this$0 = NumberPicker.this;
            super();
            mAccessibilityFocusedView = 0x80000000;
        }
    }

    class BeginSoftInputOnLongPressCommand
        implements Runnable
    {

        final NumberPicker this$0;

        public void run()
        {
            showSoftInput();
            mIngonreMoveEvents = true;
        }

        BeginSoftInputOnLongPressCommand()
        {
            this$0 = NumberPicker.this;
            super();
        }
    }

    class ChangeCurrentByOneFromLongPressCommand
        implements Runnable
    {

        private boolean mIncrement;
        final NumberPicker this$0;

        private void setStep(boolean flag)
        {
            mIncrement = flag;
        }

        public void run()
        {
            changeValueByOne(mIncrement);
            postDelayed(this, mLongPressUpdateInterval);
        }


        ChangeCurrentByOneFromLongPressCommand()
        {
            this$0 = NumberPicker.this;
            super();
        }
    }

    public static class CustomEditText extends EditText
    {

        public void onEditorAction(int i)
        {
            super.onEditorAction(i);
            if (i == 6)
            {
                clearFocus();
            }
        }

        public CustomEditText(Context context, AttributeSet attributeset)
        {
            super(context, attributeset);
        }
    }

    public static interface Formatter
    {

        public abstract String format(int i);
    }

    class InputTextFilter extends NumberKeyListener
    {

        final NumberPicker this$0;

        public CharSequence filter(CharSequence charsequence, int i, int j, Spanned spanned, int k, int l)
        {
            if (mDisplayedValues == null)
            {
                CharSequence charsequence2 = super.filter(charsequence, i, j, spanned, k, l);
                CharSequence charsequence1 = charsequence2;
                if (charsequence2 == null)
                {
                    charsequence1 = charsequence.subSequence(i, j);
                }
                charsequence = (new StringBuilder()).append(String.valueOf(spanned.subSequence(0, k))).append(charsequence1).append(spanned.subSequence(l, spanned.length())).toString();
                if ("".equals(charsequence))
                {
                    return charsequence;
                }
                if (getSelectedPos(charsequence) > mMaxValue)
                {
                    return "";
                } else
                {
                    return charsequence1;
                }
            }
            charsequence = String.valueOf(charsequence.subSequence(i, j));
            if (TextUtils.isEmpty(charsequence))
            {
                return "";
            }
            charsequence = (new StringBuilder()).append(String.valueOf(spanned.subSequence(0, k))).append(charsequence).append(spanned.subSequence(l, spanned.length())).toString();
            spanned = String.valueOf(charsequence).toLowerCase();
            String as[] = mDisplayedValues;
            j = as.length;
            for (i = 0; i < j; i++)
            {
                String s = as[i];
                if (s.toLowerCase().startsWith(spanned))
                {
                    postSetSelectionCommand(charsequence.length(), s.length());
                    return s.subSequence(k, s.length());
                }
            }

            return "";
        }

        protected char[] getAcceptedChars()
        {
            return NumberPicker.DIGIT_CHARACTERS;
        }

        public int getInputType()
        {
            return 1;
        }

        InputTextFilter()
        {
            this$0 = NumberPicker.this;
            super();
        }
    }

    public static interface OnScrollListener
    {

        public static final int SCROLL_STATE_FLING = 2;
        public static final int SCROLL_STATE_IDLE = 0;
        public static final int SCROLL_STATE_TOUCH_SCROLL = 1;

        public abstract void onScrollStateChange(NumberPicker numberpicker, int i);
    }

    public static interface OnValueChangeListener
    {

        public abstract void onValueChange(NumberPicker numberpicker, int i, int j);
    }

    class SetSelectionCommand
        implements Runnable
    {

        private int mSelectionEnd;
        private int mSelectionStart;
        final NumberPicker this$0;

        public void run()
        {
            mInputText.setSelection(mSelectionStart, mSelectionEnd);
        }


/*
        static int access$702(SetSelectionCommand setselectioncommand, int i)
        {
            setselectioncommand.mSelectionStart = i;
            return i;
        }

*/


/*
        static int access$802(SetSelectionCommand setselectioncommand, int i)
        {
            setselectioncommand.mSelectionEnd = i;
            return i;
        }

*/

        SetSelectionCommand()
        {
            this$0 = NumberPicker.this;
            super();
        }
    }

    class SupportAccessibilityNodeProvider
    {

        AccessibilityNodeProviderImpl mProvider;
        final NumberPicker this$0;

        public boolean performAction(int i, int j, Bundle bundle)
        {
            if (mProvider != null)
            {
                return mProvider.performAction(i, j, bundle);
            } else
            {
                return false;
            }
        }

        public void sendAccessibilityEventForVirtualView(int i, int j)
        {
            if (mProvider != null)
            {
                mProvider.sendAccessibilityEventForVirtualView(i, j);
            }
        }

        private SupportAccessibilityNodeProvider()
        {
            this$0 = NumberPicker.this;
            super();
            if (android.os.Build.VERSION.SDK_INT >= 16)
            {
                mProvider = new AccessibilityNodeProviderImpl();
            }
        }

    }

    private static class TwoDigitFormatter
        implements Formatter
    {

        final Object mArgs[] = new Object[1];
        final StringBuilder mBuilder = new StringBuilder();
        java.util.Formatter mFmt;
        char mZeroDigit;

        private java.util.Formatter createFormatter(Locale locale)
        {
            return new Formatter(mBuilder, locale);
        }

        private static char getZeroDigit(Locale locale)
        {
            return (new DecimalFormatSymbols(locale)).getZeroDigit();
        }

        private void init(Locale locale)
        {
            mFmt = createFormatter(locale);
            mZeroDigit = getZeroDigit(locale);
        }

        public String format(int i)
        {
            Locale locale = Locale.getDefault();
            if (mZeroDigit != getZeroDigit(locale))
            {
                init(locale);
            }
            mArgs[0] = Integer.valueOf(i);
            mBuilder.delete(0, mBuilder.length());
            mFmt.format("%02d", mArgs);
            return mFmt.toString();
        }

        TwoDigitFormatter()
        {
            init(Locale.getDefault());
        }
    }


    private static final int DEFAULT_LAYOUT_RESOURCE_ID = 0;
    private static final long DEFAULT_LONG_PRESS_UPDATE_INTERVAL = 300L;
    private static final char DIGIT_CHARACTERS[] = {
        '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 
        '\u0660', '\u0661', '\u0662', '\u0663', '\u0664', '\u0665', '\u0666', '\u0667', '\u0668', '\u0669', 
        '\u06F0', '\u06F1', '\u06F2', '\u06F3', '\u06F4', '\u06F5', '\u06F6', '\u06F7', '\u06F8', '\u06F9'
    };
    private static final int SELECTOR_ADJUSTMENT_DURATION_MILLIS = 800;
    private static final int SELECTOR_MAX_FLING_VELOCITY_ADJUSTMENT = 8;
    private static final int SELECTOR_MIDDLE_ITEM_INDEX = 1;
    private static final int SELECTOR_WHEEL_ITEM_COUNT = 3;
    private static final int SIZE_UNSPECIFIED = -1;
    private static final int SNAP_SCROLL_DURATION = 300;
    private static final float TOP_AND_BOTTOM_FADING_EDGE_STRENGTH = 0.9F;
    private static final int UNSCALED_DEFAULT_SELECTION_DIVIDERS_DISTANCE = 48;
    private static final int UNSCALED_DEFAULT_SELECTION_DIVIDER_HEIGHT = 2;
    private static final TwoDigitFormatter sTwoDigitFormatter = new TwoDigitFormatter();
    private SupportAccessibilityNodeProvider mAccessibilityNodeProvider;
    private final Scroller mAdjustScroller;
    private BeginSoftInputOnLongPressCommand mBeginSoftInputOnLongPressCommand;
    private int mBottomSelectionDividerBottom;
    private ChangeCurrentByOneFromLongPressCommand mChangeCurrentByOneFromLongPressCommand;
    private final boolean mComputeMaxWidth;
    private int mCurrentScrollOffset;
    private final ImageButton mDecrementButton;
    private boolean mDecrementVirtualButtonPressed;
    private String mDisplayedValues[];
    private final Scroller mFlingScroller;
    private Formatter mFormatter;
    private final boolean mHasSelectorWheel;
    private final ImageButton mIncrementButton;
    private boolean mIncrementVirtualButtonPressed;
    private boolean mIngonreMoveEvents;
    private int mInitialScrollOffset;
    private final EditText mInputText;
    private long mLastDownEventTime;
    private float mLastDownEventY;
    private float mLastDownOrMoveEventY;
    private int mLastHandledDownDpadKeyCode;
    private int mLastHoveredChildVirtualViewId;
    private long mLongPressUpdateInterval;
    private final int mMaxHeight;
    private int mMaxValue;
    private int mMaxWidth;
    private int mMaximumFlingVelocity;
    private final int mMinHeight;
    private int mMinValue;
    private final int mMinWidth;
    private int mMinimumFlingVelocity;
    private OnScrollListener mOnScrollListener;
    private OnValueChangeListener mOnValueChangeListener;
    private final PressedStateHelper mPressedStateHelper;
    private int mPreviousScrollerY;
    private int mScrollState;
    private final Drawable mSelectionDivider;
    private final int mSelectionDividerHeight;
    private final int mSelectionDividersDistance;
    private int mSelectorElementHeight;
    private final SparseArray mSelectorIndexToStringCache;
    private final int mSelectorIndices[];
    private int mSelectorTextGapHeight;
    private final Paint mSelectorWheelPaint;
    private SetSelectionCommand mSetSelectionCommand;
    private boolean mShowSoftInputOnTap;
    private final int mSolidColor;
    private final int mTextSize;
    private int mTopSelectionDividerTop;
    private int mTouchSlop;
    private int mValue;
    private VelocityTracker mVelocityTracker;
    private final Drawable mVirtualButtonPressedDrawable;
    private boolean mWrapSelectorWheel;

    public NumberPicker(Context context)
    {
        NumberPicker(context, null);
    }

    public NumberPicker(Context context, AttributeSet attributeset)
    {
        NumberPicker(context, attributeset, R.attr.numberPickerStyle);
    }

    public NumberPicker(Context context, AttributeSet attributeset, int i)
    {
        LinearLayout(context, attributeset);
        mLongPressUpdateInterval = 300L;
        mSelectorIndexToStringCache = new SparseArray();
        mSelectorIndices = new int[3];
        mInitialScrollOffset = 0x80000000;
        mScrollState = 0;
        mLastHandledDownDpadKeyCode = -1;
        attributeset = context.obtainStyledAttributes(attributeset, R.styleable.NumberPicker, i, 0);
        i = attributeset.getResourceId(R.styleable.NumberPicker_internalLayout, 0);
        int j;
        boolean flag;
        if (i != 0)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        mHasSelectorWheel = flag;
        mSolidColor = attributeset.getColor(R.styleable.NumberPicker_solidColor, 0);
        mSelectionDivider = attributeset.getDrawable(R.styleable.NumberPicker_selectionDivider);
        j = (int)TypedValue.applyDimension(1, 2.0F, getResources().getDisplayMetrics());
        mSelectionDividerHeight = attributeset.getDimensionPixelSize(R.styleable.NumberPicker_selectionDividerHeight, j);
        j = (int)TypedValue.applyDimension(1, 48F, getResources().getDisplayMetrics());
        mSelectionDividersDistance = attributeset.getDimensionPixelSize(R.styleable.NumberPicker_selectionDividersDistance, j);
        mMinHeight = attributeset.getDimensionPixelSize(R.styleable.NumberPicker_internalMinHeight, -1);
        mMaxHeight = attributeset.getDimensionPixelSize(R.styleable.NumberPicker_internalMaxHeight, -1);
        if (mMinHeight != -1 && mMaxHeight != -1 && mMinHeight > mMaxHeight)
        {
            throw new IllegalArgumentException("minHeight > maxHeight");
        }
        mMinWidth = attributeset.getDimensionPixelSize(R.styleable.NumberPicker_internalMinWidth, -1);
        mMaxWidth = attributeset.getDimensionPixelSize(R.styleable.NumberPicker_internalMaxWidth, -1);
        if (mMinWidth != -1 && mMaxWidth != -1 && mMinWidth > mMaxWidth)
        {
            throw new IllegalArgumentException("minWidth > maxWidth");
        }
        android.view.View.OnLongClickListener onlongclicklistener;
        if (mMaxWidth == -1)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        mComputeMaxWidth = flag;
        mVirtualButtonPressedDrawable = attributeset.getDrawable(R.styleable.NumberPicker_virtualButtonPressedDrawable);
        attributeset.recycle();
        mPressedStateHelper = new PressedStateHelper();
        if (!mHasSelectorWheel)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        setWillNotDraw(flag);
        ((LayoutInflater)getContext().getSystemService("layout_inflater")).inflate(i, this, true);
        attributeset = new android.view.View.OnClickListener() {

            final NumberPicker this$0;

            public void onClick(View view)
            {
                hideSoftInput();
                mInputText.clearFocus();
                if (view.getId() == R.id.np__increment)
                {
                    changeValueByOne(true);
                    return;
                } else
                {
                    changeValueByOne(false);
                    return;
                }
            }

            
            {
                this$0 = NumberPicker.this;
                super();
            }
        };
        onlongclicklistener = new android.view.View.OnLongClickListener() {

            final NumberPicker this$0;

            public boolean onLongClick(View view)
            {
                hideSoftInput();
                mInputText.clearFocus();
                if (view.getId() == R.id.np__increment)
                {
                    postChangeCurrentByOneFromLongPress(true, 0L);
                    return true;
                } else
                {
                    postChangeCurrentByOneFromLongPress(false, 0L);
                    return true;
                }
            }

            
            {
                this$0 = NumberPicker.this;
                super();
            }
        };
        if (!mHasSelectorWheel)
        {
            mIncrementButton = (ImageButton)findViewById(R.id.np__increment);
            mIncrementButton.setOnClickListener(attributeset);
            mIncrementButton.setOnLongClickListener(onlongclicklistener);
        } else
        {
            mIncrementButton = null;
        }
        if (!mHasSelectorWheel)
        {
            mDecrementButton = (ImageButton)findViewById(R.id.np__decrement);
            mDecrementButton.setOnClickListener(attributeset);
            mDecrementButton.setOnLongClickListener(onlongclicklistener);
        } else
        {
            mDecrementButton = null;
        }
        mInputText = (EditText)findViewById(R.id.np__numberpicker_input);
        mInputText.setOnFocusChangeListener(new android.view.View.OnFocusChangeListener() {

            final NumberPicker this$0;

            public void onFocusChange(View view, boolean flag1)
            {
                if (flag1)
                {
                    mInputText.selectAll();
                    return;
                } else
                {
                    mInputText.setSelection(0, 0);
                    validateInputTextView(view);
                    return;
                }
            }

            
            {
                this$0 = NumberPicker.this;
                super();
            }
        });
        mInputText.setFilters(new InputFilter[] {
            new InputTextFilter()
        });
        mInputText.setRawInputType(2);
        mInputText.setImeOptions(6);
        context = ViewConfiguration.get(context);
        mTouchSlop = context.getScaledTouchSlop();
        mMinimumFlingVelocity = context.getScaledMinimumFlingVelocity();
        mMaximumFlingVelocity = context.getScaledMaximumFlingVelocity() / 8;
        mTextSize = (int)mInputText.getTextSize();
        context = new Paint();
        context.setAntiAlias(true);
        context.setTextAlign(android.graphics.Paint.Align.CENTER);
        context.setTextSize(mTextSize);
        context.setTypeface(mInputText.getTypeface());
        context.setColor(mInputText.getTextColors().getColorForState(ENABLED_STATE_SET, -1));
        mSelectorWheelPaint = context;
        mFlingScroller = new Scroller(getContext(), null, true);
        mAdjustScroller = new Scroller(getContext(), new DecelerateInterpolator(2.5F));
        updateInputTextView();
        if (android.os.Build.VERSION.SDK_INT >= 16 && getImportantForAccessibility() == 0)
        {
            setImportantForAccessibility(1);
        }
    }

    private void changeValueByOne(boolean flag)
    {
        if (mHasSelectorWheel)
        {
            mInputText.setVisibility(4);
            if (!moveToFinalScrollerPosition(mFlingScroller))
            {
                moveToFinalScrollerPosition(mAdjustScroller);
            }
            mPreviousScrollerY = 0;
            if (flag)
            {
                mFlingScroller.startScroll(0, 0, 0, -mSelectorElementHeight, 300);
            } else
            {
                mFlingScroller.startScroll(0, 0, 0, mSelectorElementHeight, 300);
            }
            invalidate();
            return;
        }
        if (flag)
        {
            setValueInternal(mValue + 1, true);
            return;
        } else
        {
            setValueInternal(mValue - 1, true);
            return;
        }
    }

    private void decrementSelectorIndices(int ai[])
    {
        for (int i = ai.length - 1; i > 0; i--)
        {
            ai[i] = ai[i - 1];
        }

        int k = ai[1] - 1;
        int j = k;
        if (mWrapSelectorWheel)
        {
            j = k;
            if (k < mMinValue)
            {
                j = mMaxValue;
            }
        }
        ai[0] = j;
        ensureCachedScrollSelectorValue(j);
    }

    private void ensureCachedScrollSelectorValue(int i)
    {
        SparseArray sparsearray = mSelectorIndexToStringCache;
        if ((String)sparsearray.get(i) != null)
        {
            return;
        }
        String s;
        if (i < mMinValue || i > mMaxValue)
        {
            s = "";
        } else
        if (mDisplayedValues != null)
        {
            int j = mMinValue;
            s = mDisplayedValues[i - j];
        } else
        {
            s = formatNumber(i);
        }
        sparsearray.put(i, s);
    }

    private boolean ensureScrollWheelAdjusted()
    {
        boolean flag = false;
        int j = mInitialScrollOffset - mCurrentScrollOffset;
        if (j != 0)
        {
            mPreviousScrollerY = 0;
            int i = j;
            if (Math.abs(j) > mSelectorElementHeight / 2)
            {
                if (j > 0)
                {
                    i = -mSelectorElementHeight;
                } else
                {
                    i = mSelectorElementHeight;
                }
                i = j + i;
            }
            mAdjustScroller.startScroll(0, 0, 0, i, 800);
            invalidate();
            flag = true;
        }
        return flag;
    }

    private void fling(int i)
    {
        mPreviousScrollerY = 0;
        if (i > 0)
        {
            mFlingScroller.fling(0, 0, 0, i, 0, 0, 0, 0x7fffffff);
        } else
        {
            mFlingScroller.fling(0, 0x7fffffff, 0, i, 0, 0, 0, 0x7fffffff);
        }
        invalidate();
    }

    private String formatNumber(int i)
    {
        if (mFormatter != null)
        {
            return mFormatter.format(i);
        } else
        {
            return formatNumberWithLocale(i);
        }
    }

    private static String formatNumberWithLocale(int i)
    {
        return String.format(Locale.getDefault(), "%d", new Object[] {
            Integer.valueOf(i)
        });
    }

    private int getSelectedPos(String s)
    {
        if (mDisplayedValues != null)
        {
            break MISSING_BLOCK_LABEL_14;
        }
        int i = Integer.parseInt(s);
        return i;
        for (i = 0; i < mDisplayedValues.length; i++)
        {
            s = s.toLowerCase();
            if (mDisplayedValues[i].toLowerCase().startsWith(s))
            {
                return mMinValue + i;
            }
        }

        i = Integer.parseInt(s);
        return i;
        s;
_L2:
        return mMinValue;
        s;
        if (true) goto _L2; else goto _L1
_L1:
    }

    private SupportAccessibilityNodeProvider getSupportAccessibilityNodeProvider()
    {
        return new SupportAccessibilityNodeProvider();
    }

    public static final Formatter getTwoDigitFormatter()
    {
        return sTwoDigitFormatter;
    }

    private int getWrappedSelectorIndex(int i)
    {
        int j;
        if (i > mMaxValue)
        {
            j = (mMinValue + (i - mMaxValue) % (mMaxValue - mMinValue)) - 1;
        } else
        {
            j = i;
            if (i < mMinValue)
            {
                return (mMaxValue - (mMinValue - i) % (mMaxValue - mMinValue)) + 1;
            }
        }
        return j;
    }

    private void hideSoftInput()
    {
        InputMethodManager inputmethodmanager = (InputMethodManager)getContext().getSystemService("input_method");
        if (inputmethodmanager != null && inputmethodmanager.isActive(mInputText))
        {
            inputmethodmanager.hideSoftInputFromWindow(getWindowToken(), 0);
            if (mHasSelectorWheel)
            {
                mInputText.setVisibility(4);
            }
        }
    }

    private void incrementSelectorIndices(int ai[])
    {
        for (int i = 0; i < ai.length - 1; i++)
        {
            ai[i] = ai[i + 1];
        }

        int k = ai[ai.length - 2] + 1;
        int j = k;
        if (mWrapSelectorWheel)
        {
            j = k;
            if (k > mMaxValue)
            {
                j = mMinValue;
            }
        }
        ai[ai.length - 1] = j;
        ensureCachedScrollSelectorValue(j);
    }

    private void initializeFadingEdges()
    {
        setVerticalFadingEdgeEnabled(true);
        setFadingEdgeLength((getBottom() - getTop() - mTextSize) / 2);
    }

    private void initializeSelectorWheel()
    {
        initializeSelectorWheelIndices();
        int ai[] = mSelectorIndices;
        int i = ai.length;
        int j = mTextSize;
        mSelectorTextGapHeight = (int)((float)(getBottom() - getTop() - i * j) / (float)ai.length + 0.5F);
        mSelectorElementHeight = mTextSize + mSelectorTextGapHeight;
        mInitialScrollOffset = (mInputText.getBaseline() + mInputText.getTop()) - mSelectorElementHeight * 1;
        mCurrentScrollOffset = mInitialScrollOffset;
        updateInputTextView();
    }

    private void initializeSelectorWheelIndices()
    {
        mSelectorIndexToStringCache.clear();
        int ai[] = mSelectorIndices;
        int l = getValue();
        for (int i = 0; i < mSelectorIndices.length; i++)
        {
            int k = l + (i - 1);
            int j = k;
            if (mWrapSelectorWheel)
            {
                j = getWrappedSelectorIndex(k);
            }
            ai[i] = j;
            ensureCachedScrollSelectorValue(ai[i]);
        }

    }

    private int makeMeasureSpec(int i, int j)
    {
        if (j != -1) goto _L2; else goto _L1
_L1:
        return i;
_L2:
        int k = android.view.View.MeasureSpec.getSize(i);
        int l = android.view.View.MeasureSpec.getMode(i);
        switch (l)
        {
        default:
            throw new IllegalArgumentException((new StringBuilder()).append("Unknown measure mode: ").append(l).toString());

        case -2147483648: 
            return android.view.View.MeasureSpec.makeMeasureSpec(Math.min(k, j), 0x40000000);

        case 0: // '\0'
            return android.view.View.MeasureSpec.makeMeasureSpec(j, 0x40000000);

        case 1073741824: 
            break;
        }
        if (true) goto _L1; else goto _L3
_L3:
    }

    private boolean moveToFinalScrollerPosition(Scroller scroller)
    {
        scroller.forceFinished(true);
        int l = scroller.getFinalY() - scroller.getCurrY();
        int i = mCurrentScrollOffset;
        int k = mSelectorElementHeight;
        k = mInitialScrollOffset - (i + l) % k;
        if (k != 0)
        {
            int j = k;
            if (Math.abs(k) > mSelectorElementHeight / 2)
            {
                if (k > 0)
                {
                    j = k - mSelectorElementHeight;
                } else
                {
                    j = k + mSelectorElementHeight;
                }
            }
            scrollBy(0, l + j);
            return true;
        } else
        {
            return false;
        }
    }

    private void notifyChange(int i, int j)
    {
        if (mOnValueChangeListener != null)
        {
            mOnValueChangeListener.onValueChange(this, i, mValue);
        }
    }

    private void onScrollStateChange(int i)
    {
        if (mScrollState != i)
        {
            mScrollState = i;
            if (mOnScrollListener != null)
            {
                mOnScrollListener.onScrollStateChange(this, i);
                return;
            }
        }
    }

    private void onScrollerFinished(Scroller scroller)
    {
        if (scroller == mFlingScroller)
        {
            if (!ensureScrollWheelAdjusted())
            {
                updateInputTextView();
            }
            onScrollStateChange(0);
        } else
        if (mScrollState != 1)
        {
            updateInputTextView();
            return;
        }
    }

    private void postBeginSoftInputOnLongPressCommand()
    {
        if (mBeginSoftInputOnLongPressCommand == null)
        {
            mBeginSoftInputOnLongPressCommand = new BeginSoftInputOnLongPressCommand();
        } else
        {
            removeCallbacks(mBeginSoftInputOnLongPressCommand);
        }
        postDelayed(mBeginSoftInputOnLongPressCommand, ViewConfiguration.getLongPressTimeout());
    }

    private void postChangeCurrentByOneFromLongPress(boolean flag, long l)
    {
        if (mChangeCurrentByOneFromLongPressCommand == null)
        {
            mChangeCurrentByOneFromLongPressCommand = new ChangeCurrentByOneFromLongPressCommand();
        } else
        {
            removeCallbacks(mChangeCurrentByOneFromLongPressCommand);
        }
        mChangeCurrentByOneFromLongPressCommand.setStep(flag);
        postDelayed(mChangeCurrentByOneFromLongPressCommand, l);
    }

    private void postSetSelectionCommand(int i, int j)
    {
        if (mSetSelectionCommand == null)
        {
            mSetSelectionCommand = new SetSelectionCommand();
        } else
        {
            removeCallbacks(mSetSelectionCommand);
        }
        mSetSelectionCommand.mSelectionStart = i;
        mSetSelectionCommand.mSelectionEnd = j;
        post(mSetSelectionCommand);
    }

    private void removeAllCallbacks()
    {
        if (mChangeCurrentByOneFromLongPressCommand != null)
        {
            removeCallbacks(mChangeCurrentByOneFromLongPressCommand);
        }
        if (mSetSelectionCommand != null)
        {
            removeCallbacks(mSetSelectionCommand);
        }
        if (mBeginSoftInputOnLongPressCommand != null)
        {
            removeCallbacks(mBeginSoftInputOnLongPressCommand);
        }
        mPressedStateHelper.cancel();
    }

    private void removeBeginSoftInputCommand()
    {
        if (mBeginSoftInputOnLongPressCommand != null)
        {
            removeCallbacks(mBeginSoftInputOnLongPressCommand);
        }
    }

    private void removeChangeCurrentByOneFromLongPress()
    {
        if (mChangeCurrentByOneFromLongPressCommand != null)
        {
            removeCallbacks(mChangeCurrentByOneFromLongPressCommand);
        }
    }

    public static int resolveSizeAndState(int i, int j, int k)
    {
        int l;
        int i1;
        l = i;
        i1 = android.view.View.MeasureSpec.getMode(j);
        j = android.view.View.MeasureSpec.getSize(j);
        i1;
        JVM INSTR lookupswitch 3: default 48
    //                   -2147483648: 61
    //                   0: 58
    //                   1073741824: 78;
           goto _L1 _L2 _L3 _L4
_L3:
        break; /* Loop/switch isn't completed */
_L1:
        i = l;
_L6:
        return 0xff000000 & k | i;
_L2:
        if (j < i)
        {
            i = j | 0x1000000;
        }
        continue; /* Loop/switch isn't completed */
_L4:
        i = j;
        if (true) goto _L6; else goto _L5
_L5:
    }

    private int resolveSizeAndStateRespectingMinSize(int i, int j, int k)
    {
        int l = j;
        if (i != -1)
        {
            l = resolveSizeAndState(Math.max(i, j), k, 0);
        }
        return l;
    }

    private void setValueInternal(int i, boolean flag)
    {
        if (mValue == i)
        {
            return;
        }
        int j;
        if (mWrapSelectorWheel)
        {
            i = getWrappedSelectorIndex(i);
        } else
        {
            i = Math.min(Math.max(i, mMinValue), mMaxValue);
        }
        j = mValue;
        mValue = i;
        updateInputTextView();
        if (flag)
        {
            notifyChange(j, i);
        }
        initializeSelectorWheelIndices();
        invalidate();
    }

    private void showSoftInput()
    {
        InputMethodManager inputmethodmanager = (InputMethodManager)getContext().getSystemService("input_method");
        if (inputmethodmanager != null)
        {
            if (mHasSelectorWheel)
            {
                mInputText.setVisibility(0);
            }
            mInputText.requestFocus();
            inputmethodmanager.showSoftInput(mInputText, 0);
        }
    }

    private void tryComputeMaxWidth()
    {
        if (mComputeMaxWidth) goto _L2; else goto _L1
_L1:
        return;
_L2:
        int i = 0;
        if (mDisplayedValues != null) goto _L4; else goto _L3
_L3:
        int l;
        float f = 0.0F;
        for (i = 0; i <= 9;)
        {
            float f3 = mSelectorWheelPaint.measureText(formatNumberWithLocale(i));
            float f2 = f;
            if (f3 > f)
            {
                f2 = f3;
            }
            i++;
            f = f2;
        }

        int j = 0;
        for (i = mMaxValue; i > 0; i /= 10)
        {
            j++;
        }

        l = (int)((float)j * f);
_L6:
        i = l + (mInputText.getPaddingLeft() + mInputText.getPaddingRight());
        if (mMaxWidth != i)
        {
            float f1;
            int k;
            int i1;
            if (i > mMinWidth)
            {
                mMaxWidth = i;
            } else
            {
                mMaxWidth = mMinWidth;
            }
            invalidate();
            return;
        }
        if (true) goto _L1; else goto _L4
_L4:
        i1 = mDisplayedValues.length;
        k = 0;
_L7:
        l = i;
        if (k >= i1) goto _L6; else goto _L5
_L5:
        f1 = mSelectorWheelPaint.measureText(mDisplayedValues[k]);
        l = i;
        if (f1 > (float)i)
        {
            l = (int)f1;
        }
        k++;
        i = l;
          goto _L7
    }

    private boolean updateInputTextView()
    {
        String s;
        if (mDisplayedValues == null)
        {
            s = formatNumber(mValue);
        } else
        {
            s = mDisplayedValues[mValue - mMinValue];
        }
        if (!TextUtils.isEmpty(s) && !s.equals(mInputText.getText().toString()))
        {
            mInputText.setText(s);
            return true;
        } else
        {
            return false;
        }
    }

    private void validateInputTextView(View view)
    {
        view = String.valueOf(((TextView)view).getText());
        if (TextUtils.isEmpty(view))
        {
            updateInputTextView();
            return;
        } else
        {
            setValueInternal(getSelectedPos(view.toString()), true);
            return;
        }
    }

    public void computeScroll()
    {
        Scroller scroller1 = mFlingScroller;
        Scroller scroller = scroller1;
        if (scroller1.isFinished())
        {
            Scroller scroller2 = mAdjustScroller;
            scroller = scroller2;
            if (scroller2.isFinished())
            {
                return;
            }
        }
        scroller.computeScrollOffset();
        int i = scroller.getCurrY();
        if (mPreviousScrollerY == 0)
        {
            mPreviousScrollerY = scroller.getStartY();
        }
        scrollBy(0, i - mPreviousScrollerY);
        mPreviousScrollerY = i;
        if (scroller.isFinished())
        {
            onScrollerFinished(scroller);
            return;
        } else
        {
            invalidate();
            return;
        }
    }

    protected boolean dispatchHoverEvent(MotionEvent motionevent)
    {
        if (!mHasSelectorWheel)
        {
            return super.dispatchHoverEvent(motionevent);
        }
        if (!((AccessibilityManager)getContext().getSystemService("accessibility")).isEnabled()) goto _L2; else goto _L1
_L1:
        int i;
        i = (int)motionevent.getY();
        int j;
        if (i < mTopSelectionDividerTop)
        {
            i = 3;
        } else
        if (i > mBottomSelectionDividerBottom)
        {
            i = 1;
        } else
        {
            i = 2;
        }
        j = motionevent.getAction();
        motionevent = getSupportAccessibilityNodeProvider();
        j & 0xff;
        JVM INSTR tableswitch 7 10: default 92
    //                   7 137
    //                   8 92
    //                   9 112
    //                   10 189;
           goto _L2 _L3 _L2 _L4 _L5
_L2:
        return false;
_L4:
        motionevent.sendAccessibilityEventForVirtualView(i, 128);
        mLastHoveredChildVirtualViewId = i;
        motionevent.performAction(i, 64, null);
        continue; /* Loop/switch isn't completed */
_L3:
        if (mLastHoveredChildVirtualViewId != i && mLastHoveredChildVirtualViewId != -1)
        {
            motionevent.sendAccessibilityEventForVirtualView(mLastHoveredChildVirtualViewId, 256);
            motionevent.sendAccessibilityEventForVirtualView(i, 128);
            mLastHoveredChildVirtualViewId = i;
            motionevent.performAction(i, 64, null);
        }
        continue; /* Loop/switch isn't completed */
_L5:
        motionevent.sendAccessibilityEventForVirtualView(i, 256);
        mLastHoveredChildVirtualViewId = -1;
        if (true) goto _L2; else goto _L6
_L6:
    }

    public boolean dispatchKeyEvent(KeyEvent keyevent)
    {
        int i;
        boolean flag;
        flag = true;
        i = keyevent.getKeyCode();
        i;
        JVM INSTR lookupswitch 4: default 52
    //                   19: 67
    //                   20: 67
    //                   23: 60
    //                   66: 60;
           goto _L1 _L2 _L2 _L3 _L3
_L12:
        flag = super.dispatchKeyEvent(keyevent);
_L10:
        return flag;
_L3:
        removeAllCallbacks();
        continue; /* Loop/switch isn't completed */
_L2:
        if (!mHasSelectorWheel)
        {
            continue; /* Loop/switch isn't completed */
        }
        keyevent.getAction();
        JVM INSTR tableswitch 0 1: default 100
    //                   0 103
    //                   1 185;
           goto _L4 _L5 _L6
_L4:
        continue; /* Loop/switch isn't completed */
_L6:
        continue; /* Loop/switch isn't completed */
_L5:
        if (!mWrapSelectorWheel && i != 20 ? getValue() <= getMinValue() : getValue() >= getMaxValue()) goto _L8; else goto _L7
_L8:
        continue; /* Loop/switch isn't completed */
_L7:
        requestFocus();
        mLastHandledDownDpadKeyCode = i;
        removeAllCallbacks();
        if (!mFlingScroller.isFinished()) goto _L10; else goto _L9
_L9:
        boolean flag1;
        if (i == 20)
        {
            flag1 = true;
        } else
        {
            flag1 = false;
        }
        changeValueByOne(flag1);
        return true;
        if (mLastHandledDownDpadKeyCode != i) goto _L12; else goto _L11
_L11:
        mLastHandledDownDpadKeyCode = -1;
        return true;
_L1:
        if (true) goto _L12; else goto _L13
_L13:
    }

    public boolean dispatchTouchEvent(MotionEvent motionevent)
    {
        motionevent.getAction() & 0xff;
        JVM INSTR tableswitch 1 3: default 36
    //                   1 42
    //                   2 36
    //                   3 42;
           goto _L1 _L2 _L1 _L2
_L1:
        return super.dispatchTouchEvent(motionevent);
_L2:
        removeAllCallbacks();
        if (true) goto _L1; else goto _L3
_L3:
    }

    public boolean dispatchTrackballEvent(MotionEvent motionevent)
    {
        motionevent.getAction() & 0xff;
        JVM INSTR tableswitch 1 3: default 36
    //                   1 42
    //                   2 36
    //                   3 42;
           goto _L1 _L2 _L1 _L2
_L1:
        return super.dispatchTrackballEvent(motionevent);
_L2:
        removeAllCallbacks();
        if (true) goto _L1; else goto _L3
_L3:
    }

    public AccessibilityNodeProvider getAccessibilityNodeProvider()
    {
        if (!mHasSelectorWheel)
        {
            return super.getAccessibilityNodeProvider();
        }
        if (mAccessibilityNodeProvider == null)
        {
            mAccessibilityNodeProvider = new SupportAccessibilityNodeProvider();
        }
        return mAccessibilityNodeProvider.mProvider;
    }

    protected float getBottomFadingEdgeStrength()
    {
        return 0.9F;
    }

    public String[] getDisplayedValues()
    {
        return mDisplayedValues;
    }

    public int getMaxValue()
    {
        return mMaxValue;
    }

    public int getMinValue()
    {
        return mMinValue;
    }

    public int getSolidColor()
    {
        return mSolidColor;
    }

    protected float getTopFadingEdgeStrength()
    {
        return 0.9F;
    }

    public int getValue()
    {
        return mValue;
    }

    public boolean getWrapSelectorWheel()
    {
        return mWrapSelectorWheel;
    }

    protected void onDetachedFromWindow()
    {
        removeAllCallbacks();
    }

    protected void onDraw(Canvas canvas)
    {
        if (!mHasSelectorWheel)
        {
            super.onDraw(canvas);
        } else
        {
            float f1 = (getRight() - getLeft()) / 2;
            float f = mCurrentScrollOffset;
            if (mVirtualButtonPressedDrawable != null && mScrollState == 0)
            {
                if (mDecrementVirtualButtonPressed)
                {
                    mVirtualButtonPressedDrawable.setState(PRESSED_ENABLED_STATE_SET);
                    mVirtualButtonPressedDrawable.setBounds(0, 0, getRight(), mTopSelectionDividerTop);
                    mVirtualButtonPressedDrawable.draw(canvas);
                }
                if (mIncrementVirtualButtonPressed)
                {
                    mVirtualButtonPressedDrawable.setState(PRESSED_ENABLED_STATE_SET);
                    mVirtualButtonPressedDrawable.setBounds(0, mBottomSelectionDividerBottom, getRight(), getBottom());
                    mVirtualButtonPressedDrawable.draw(canvas);
                }
            }
            int ai[] = mSelectorIndices;
            for (int i = 0; i < ai.length; i++)
            {
                int k = ai[i];
                String s = (String)mSelectorIndexToStringCache.get(k);
                if (i != 1 || mInputText.getVisibility() != 0)
                {
                    canvas.drawText(s, f1, f, mSelectorWheelPaint);
                }
                f += mSelectorElementHeight;
            }

            if (mSelectionDivider != null)
            {
                int j = mTopSelectionDividerTop;
                int l = mSelectionDividerHeight;
                mSelectionDivider.setBounds(0, j, getRight(), j + l);
                mSelectionDivider.draw(canvas);
                j = mBottomSelectionDividerBottom;
                l = mSelectionDividerHeight;
                mSelectionDivider.setBounds(0, j - l, getRight(), j);
                mSelectionDivider.draw(canvas);
                return;
            }
        }
    }

    public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityevent)
    {
        super.onInitializeAccessibilityEvent(accessibilityevent);
        accessibilityevent.setClassName(net/simonvt/numberpicker/NumberPicker.getName());
        accessibilityevent.setScrollable(true);
        accessibilityevent.setScrollY((mMinValue + mValue) * mSelectorElementHeight);
        accessibilityevent.setMaxScrollY((mMaxValue - mMinValue) * mSelectorElementHeight);
    }

    public boolean onInterceptTouchEvent(MotionEvent motionevent)
    {
        if (!mHasSelectorWheel || !isEnabled())
        {
            return false;
        }
        switch (motionevent.getAction() & 0xff)
        {
        default:
            return false;

        case 0: // '\0'
            removeAllCallbacks();
            break;
        }
        mInputText.setVisibility(4);
        float f = motionevent.getY();
        mLastDownEventY = f;
        mLastDownOrMoveEventY = f;
        mLastDownEventTime = motionevent.getEventTime();
        mIngonreMoveEvents = false;
        mShowSoftInputOnTap = false;
        if (mLastDownEventY >= (float)mTopSelectionDividerTop) goto _L2; else goto _L1
_L1:
        if (mScrollState == 0)
        {
            mPressedStateHelper.buttonPressDelayed(2);
        }
_L4:
        getParent().requestDisallowInterceptTouchEvent(true);
        if (!mFlingScroller.isFinished())
        {
            mFlingScroller.forceFinished(true);
            mAdjustScroller.forceFinished(true);
            onScrollStateChange(0);
            return true;
        }
        break; /* Loop/switch isn't completed */
_L2:
        if (mLastDownEventY > (float)mBottomSelectionDividerBottom && mScrollState == 0)
        {
            mPressedStateHelper.buttonPressDelayed(1);
        }
        if (true) goto _L4; else goto _L3
_L3:
        if (!mAdjustScroller.isFinished())
        {
            mFlingScroller.forceFinished(true);
            mAdjustScroller.forceFinished(true);
            return true;
        }
        if (mLastDownEventY < (float)mTopSelectionDividerTop)
        {
            hideSoftInput();
            postChangeCurrentByOneFromLongPress(false, ViewConfiguration.getLongPressTimeout());
            return true;
        }
        if (mLastDownEventY > (float)mBottomSelectionDividerBottom)
        {
            hideSoftInput();
            postChangeCurrentByOneFromLongPress(true, ViewConfiguration.getLongPressTimeout());
            return true;
        } else
        {
            mShowSoftInputOnTap = true;
            postBeginSoftInputOnLongPressCommand();
            return true;
        }
    }

    protected void onLayout(boolean flag, int i, int j, int k, int l)
    {
        if (!mHasSelectorWheel)
        {
            super.onLayout(flag, i, j, k, l);
        } else
        {
            l = getMeasuredWidth();
            k = getMeasuredHeight();
            i = mInputText.getMeasuredWidth();
            j = mInputText.getMeasuredHeight();
            l = (l - i) / 2;
            k = (k - j) / 2;
            mInputText.layout(l, k, l + i, k + j);
            if (flag)
            {
                initializeSelectorWheel();
                initializeFadingEdges();
                mTopSelectionDividerTop = (getHeight() - mSelectionDividersDistance) / 2 - mSelectionDividerHeight;
                mBottomSelectionDividerBottom = mTopSelectionDividerTop + mSelectionDividerHeight * 2 + mSelectionDividersDistance;
                return;
            }
        }
    }

    protected void onMeasure(int i, int j)
    {
        if (!mHasSelectorWheel)
        {
            super.onMeasure(i, j);
            return;
        } else
        {
            super.onMeasure(makeMeasureSpec(i, mMaxWidth), makeMeasureSpec(j, mMaxHeight));
            setMeasuredDimension(resolveSizeAndStateRespectingMinSize(mMinWidth, getMeasuredWidth(), i), resolveSizeAndStateRespectingMinSize(mMinHeight, getMeasuredHeight(), j));
            return;
        }
    }

    public boolean onTouchEvent(MotionEvent motionevent)
    {
        if (!isEnabled() || !mHasSelectorWheel)
        {
            return false;
        }
        if (mVelocityTracker == null)
        {
            mVelocityTracker = VelocityTracker.obtain();
        }
        mVelocityTracker.addMovement(motionevent);
        motionevent.getAction() & 0xff;
        JVM INSTR tableswitch 1 2: default 68
    //                   1 143
    //                   2 70;
           goto _L1 _L2 _L3
_L1:
        return true;
_L3:
        if (!mIngonreMoveEvents)
        {
            float f = motionevent.getY();
            if (mScrollState != 1)
            {
                if ((int)Math.abs(f - mLastDownEventY) > mTouchSlop)
                {
                    removeAllCallbacks();
                    onScrollStateChange(1);
                }
            } else
            {
                scrollBy(0, (int)(f - mLastDownOrMoveEventY));
                invalidate();
            }
            mLastDownOrMoveEventY = f;
        }
        continue; /* Loop/switch isn't completed */
_L2:
        removeBeginSoftInputCommand();
        removeChangeCurrentByOneFromLongPress();
        mPressedStateHelper.cancel();
        VelocityTracker velocitytracker = mVelocityTracker;
        velocitytracker.computeCurrentVelocity(1000, mMaximumFlingVelocity);
        int i = (int)velocitytracker.getYVelocity();
        if (Math.abs(i) <= mMinimumFlingVelocity)
        {
            break; /* Loop/switch isn't completed */
        }
        fling(i);
        onScrollStateChange(2);
_L5:
        mVelocityTracker.recycle();
        mVelocityTracker = null;
        if (true) goto _L1; else goto _L4
_L4:
        int j = (int)motionevent.getY();
        int k = (int)Math.abs((float)j - mLastDownEventY);
        motionevent.getEventTime();
        long l = mLastDownEventTime;
        l = ViewConfiguration.getTapTimeout();
        if (k <= mTouchSlop)
        {
            if (mShowSoftInputOnTap)
            {
                mShowSoftInputOnTap = false;
                showSoftInput();
            } else
            {
                j = j / mSelectorElementHeight - 1;
                if (j > 0)
                {
                    changeValueByOne(true);
                    mPressedStateHelper.buttonTapped(1);
                } else
                if (j < 0)
                {
                    changeValueByOne(false);
                    mPressedStateHelper.buttonTapped(2);
                }
            }
        } else
        {
            ensureScrollWheelAdjusted();
        }
        onScrollStateChange(0);
          goto _L5
        if (true) goto _L1; else goto _L6
_L6:
    }

    public void scrollBy(int i, int j)
    {
        int ai[] = mSelectorIndices;
        if (!mWrapSelectorWheel && j > 0 && ai[1] <= mMinValue)
        {
            mCurrentScrollOffset = mInitialScrollOffset;
        } else
        {
            if (!mWrapSelectorWheel && j < 0 && ai[1] >= mMaxValue)
            {
                mCurrentScrollOffset = mInitialScrollOffset;
                return;
            }
            mCurrentScrollOffset = mCurrentScrollOffset + j;
            do
            {
                if (mCurrentScrollOffset - mInitialScrollOffset <= mSelectorTextGapHeight)
                {
                    break;
                }
                mCurrentScrollOffset = mCurrentScrollOffset - mSelectorElementHeight;
                decrementSelectorIndices(ai);
                setValueInternal(ai[1], true);
                if (!mWrapSelectorWheel && ai[1] <= mMinValue)
                {
                    mCurrentScrollOffset = mInitialScrollOffset;
                }
            } while (true);
            while (mCurrentScrollOffset - mInitialScrollOffset < -mSelectorTextGapHeight) 
            {
                mCurrentScrollOffset = mCurrentScrollOffset + mSelectorElementHeight;
                incrementSelectorIndices(ai);
                setValueInternal(ai[1], true);
                if (!mWrapSelectorWheel && ai[1] >= mMaxValue)
                {
                    mCurrentScrollOffset = mInitialScrollOffset;
                }
            }
        }
    }

    public void setDisplayedValues(String as[])
    {
        if (mDisplayedValues == as)
        {
            return;
        }
        mDisplayedValues = as;
        if (mDisplayedValues != null)
        {
            mInputText.setRawInputType(0x80001);
        } else
        {
            mInputText.setRawInputType(2);
        }
        updateInputTextView();
        initializeSelectorWheelIndices();
        tryComputeMaxWidth();
    }

    public void setEnabled(boolean flag)
    {
        super.setEnabled(flag);
        if (!mHasSelectorWheel)
        {
            mIncrementButton.setEnabled(flag);
        }
        if (!mHasSelectorWheel)
        {
            mDecrementButton.setEnabled(flag);
        }
        mInputText.setEnabled(flag);
    }

    public void setFormatter(Formatter formatter)
    {
        if (formatter == mFormatter)
        {
            return;
        } else
        {
            mFormatter = formatter;
            initializeSelectorWheelIndices();
            updateInputTextView();
            return;
        }
    }

    public void setMaxValue(int i)
    {
        if (mMaxValue == i)
        {
            return;
        }
        if (i < 0)
        {
            throw new IllegalArgumentException("maxValue must be >= 0");
        }
        mMaxValue = i;
        if (mMaxValue < mValue)
        {
            mValue = mMaxValue;
        }
        boolean flag;
        if (mMaxValue - mMinValue > mSelectorIndices.length)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        setWrapSelectorWheel(flag);
        initializeSelectorWheelIndices();
        updateInputTextView();
        tryComputeMaxWidth();
        invalidate();
    }

    public void setMinValue(int i)
    {
        if (mMinValue == i)
        {
            return;
        }
        if (i < 0)
        {
            throw new IllegalArgumentException("minValue must be >= 0");
        }
        mMinValue = i;
        if (mMinValue > mValue)
        {
            mValue = mMinValue;
        }
        boolean flag;
        if (mMaxValue - mMinValue > mSelectorIndices.length)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        setWrapSelectorWheel(flag);
        initializeSelectorWheelIndices();
        updateInputTextView();
        tryComputeMaxWidth();
        invalidate();
    }

    public void setOnLongPressUpdateInterval(long l)
    {
        mLongPressUpdateInterval = l;
    }

    public void setOnScrollListener(OnScrollListener onscrolllistener)
    {
        mOnScrollListener = onscrolllistener;
    }

    public void setOnValueChangedListener(OnValueChangeListener onvaluechangelistener)
    {
        mOnValueChangeListener = onvaluechangelistener;
    }

    public void setValue(int i)
    {
        setValueInternal(i, false);
    }

    public void setWrapSelectorWheel(boolean flag)
    {
        boolean flag1;
        if (mMaxValue - mMinValue >= mSelectorIndices.length)
        {
            flag1 = true;
        } else
        {
            flag1 = false;
        }
        if ((!flag || flag1) && flag != mWrapSelectorWheel)
        {
            mWrapSelectorWheel = flag;
        }
    }










/*
    static boolean access$1402(NumberPicker numberpicker, boolean flag)
    {
        numberpicker.mIncrementVirtualButtonPressed = flag;
        return flag;
    }

*/


/*
    static boolean access$1480(NumberPicker numberpicker, int i)
    {
        boolean flag = (byte)(numberpicker.mIncrementVirtualButtonPressed ^ i);
        numberpicker.mIncrementVirtualButtonPressed = flag;
        return flag;
    }

*/




/*
    static boolean access$1602(NumberPicker numberpicker, boolean flag)
    {
        numberpicker.mDecrementVirtualButtonPressed = flag;
        return flag;
    }

*/


/*
    static boolean access$1680(NumberPicker numberpicker, int i)
    {
        boolean flag = (byte)(numberpicker.mDecrementVirtualButtonPressed ^ i);
        numberpicker.mDecrementVirtualButtonPressed = flag;
        return flag;
    }

*/






/*
    static boolean access$2002(NumberPicker numberpicker, boolean flag)
    {
        numberpicker.mIngonreMoveEvents = flag;
        return flag;
    }

*/









}
