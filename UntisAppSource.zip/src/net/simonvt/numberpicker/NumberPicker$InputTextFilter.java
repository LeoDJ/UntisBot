// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package net.simonvt.numberpicker;

import android.text.Spanned;
import android.text.TextUtils;
import android.text.method.NumberKeyListener;

// Referenced classes of package net.simonvt.numberpicker:
//            NumberPicker

class this._cls0 extends NumberKeyListener
{

    final NumberPicker this$0;

    public CharSequence filter(CharSequence charsequence, int i, int j, Spanned spanned, int k, int l)
    {
        if (NumberPicker.access$1000(NumberPicker.this) == null)
        {
            CharSequence charsequence2 = super.filter(charsequence, i, j, spanned, k, l);
            CharSequence charsequence1 = charsequence2;
            if (charsequence2 == null)
            {
                charsequence1 = charsequence.subSequence(i, j);
            }
            charsequence = (new StringBuilder()).append(String.valueOf(spanned.subSequence(0, k))).append(charsequence1).append(spanned.subSequence(l, spanned.length())).toString();
            if ("".equals(charsequence))
            {
                return charsequence;
            }
            if (NumberPicker.access$1100(NumberPicker.this, charsequence) > NumberPicker.access$1200(NumberPicker.this))
            {
                return "";
            } else
            {
                return charsequence1;
            }
        }
        charsequence = String.valueOf(charsequence.subSequence(i, j));
        if (TextUtils.isEmpty(charsequence))
        {
            return "";
        }
        charsequence = (new StringBuilder()).append(String.valueOf(spanned.subSequence(0, k))).append(charsequence).append(spanned.subSequence(l, spanned.length())).toString();
        spanned = String.valueOf(charsequence).toLowerCase();
        String as[] = NumberPicker.access$1000(NumberPicker.this);
        j = as.length;
        for (i = 0; i < j; i++)
        {
            String s = as[i];
            if (s.toLowerCase().startsWith(spanned))
            {
                NumberPicker.access$1300(NumberPicker.this, charsequence.length(), s.length());
                return s.subSequence(k, s.length());
            }
        }

        return "";
    }

    protected char[] getAcceptedChars()
    {
        return NumberPicker.access$900();
    }

    public int getInputType()
    {
        return 1;
    }

    ()
    {
        this$0 = NumberPicker.this;
        super();
    }
}
