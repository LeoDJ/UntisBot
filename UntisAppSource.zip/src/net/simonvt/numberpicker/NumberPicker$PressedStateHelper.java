// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package net.simonvt.numberpicker;

import android.view.ViewConfiguration;

// Referenced classes of package net.simonvt.numberpicker:
//            NumberPicker

class this._cls0
    implements Runnable
{

    public static final int BUTTON_DECREMENT = 2;
    public static final int BUTTON_INCREMENT = 1;
    private final int MODE_PRESS = 1;
    private final int MODE_TAPPED = 2;
    private int mManagedButton;
    private int mMode;
    final NumberPicker this$0;

    public void buttonPressDelayed(int i)
    {
        cancel();
        mMode = 1;
        mManagedButton = i;
        postDelayed(this, ViewConfiguration.getTapTimeout());
    }

    public void buttonTapped(int i)
    {
        cancel();
        mMode = 2;
        mManagedButton = i;
        post(this);
    }

    public void cancel()
    {
        mMode = 0;
        mManagedButton = 0;
        removeCallbacks(this);
        if (NumberPicker.access$1400(NumberPicker.this))
        {
            NumberPicker.access$1402(NumberPicker.this, false);
            invalidate(0, NumberPicker.access$1500(NumberPicker.this), getRight(), getBottom());
        }
        NumberPicker.access$1602(NumberPicker.this, false);
        if (NumberPicker.access$1600(NumberPicker.this))
        {
            invalidate(0, 0, getRight(), NumberPicker.access$1700(NumberPicker.this));
        }
    }

    public void run()
    {
        switch (mMode)
        {
        default:
            return;

        case 1: // '\001'
            switch (mManagedButton)
            {
            default:
                return;

            case 1: // '\001'
                NumberPicker.access$1402(NumberPicker.this, true);
                invalidate(0, NumberPicker.access$1500(NumberPicker.this), getRight(), getBottom());
                return;

            case 2: // '\002'
                NumberPicker.access$1602(NumberPicker.this, true);
                break;
            }
            invalidate(0, 0, getRight(), NumberPicker.access$1700(NumberPicker.this));
            return;

        case 2: // '\002'
            switch (mManagedButton)
            {
            default:
                return;

            case 1: // '\001'
                if (!NumberPicker.access$1400(NumberPicker.this))
                {
                    postDelayed(this, ViewConfiguration.getPressedStateDuration());
                }
                NumberPicker.access$1480(NumberPicker.this, 1);
                invalidate(0, NumberPicker.access$1500(NumberPicker.this), getRight(), getBottom());
                return;

            case 2: // '\002'
                break;
            }
            break;
        }
        if (!NumberPicker.access$1600(NumberPicker.this))
        {
            postDelayed(this, ViewConfiguration.getPressedStateDuration());
        }
        NumberPicker.access$1680(NumberPicker.this, 1);
        invalidate(0, 0, getRight(), NumberPicker.access$1700(NumberPicker.this));
    }

    ()
    {
        this$0 = NumberPicker.this;
        super();
    }
}
