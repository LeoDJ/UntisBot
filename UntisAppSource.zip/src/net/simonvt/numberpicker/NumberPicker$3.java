// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package net.simonvt.numberpicker;

import android.view.View;
import android.widget.EditText;

// Referenced classes of package net.simonvt.numberpicker:
//            NumberPicker

class this._cls0
    implements android.view.ngeListener
{

    final NumberPicker this$0;

    public void onFocusChange(View view, boolean flag)
    {
        if (flag)
        {
            NumberPicker.access$100(NumberPicker.this).selectAll();
            return;
        } else
        {
            NumberPicker.access$100(NumberPicker.this).setSelection(0, 0);
            NumberPicker.access$400(NumberPicker.this, view);
            return;
        }
    }

    ()
    {
        this$0 = NumberPicker.this;
        super();
    }
}
