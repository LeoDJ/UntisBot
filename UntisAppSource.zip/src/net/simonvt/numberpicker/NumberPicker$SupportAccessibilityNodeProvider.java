// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package net.simonvt.numberpicker;

import android.os.Bundle;

// Referenced classes of package net.simonvt.numberpicker:
//            NumberPicker

class <init>
{

    dAccessibilityEventForVirtualView mProvider;
    final NumberPicker this$0;

    public boolean performAction(int i, int j, Bundle bundle)
    {
        if (mProvider != null)
        {
            return mProvider.formAction(i, j, bundle);
        } else
        {
            return false;
        }
    }

    public void sendAccessibilityEventForVirtualView(int i, int j)
    {
        if (mProvider != null)
        {
            mProvider.dAccessibilityEventForVirtualView(i, j);
        }
    }

    private ()
    {
        this$0 = NumberPicker.this;
        super();
        if (android.os.yNodeProvider.this._fld0 >= 16)
        {
            mProvider = new it>(NumberPicker.this);
        }
    }

    it>(it> it>)
    {
        this();
    }
}
