// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package net.simonvt.numberpicker;

import android.view.View;
import android.widget.EditText;

// Referenced classes of package net.simonvt.numberpicker:
//            NumberPicker

class this._cls0
    implements android.view.tener
{

    final NumberPicker this$0;

    public void onClick(View view)
    {
        NumberPicker.access$000(NumberPicker.this);
        NumberPicker.access$100(NumberPicker.this).clearFocus();
        if (view.getId() == ent)
        {
            NumberPicker.access$200(NumberPicker.this, true);
            return;
        } else
        {
            NumberPicker.access$200(NumberPicker.this, false);
            return;
        }
    }

    ()
    {
        this$0 = NumberPicker.this;
        super();
    }
}
