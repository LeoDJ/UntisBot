// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package net.simonvt.numberpicker;

import java.text.DecimalFormatSymbols;
import java.util.Formatter;
import java.util.Locale;

// Referenced classes of package net.simonvt.numberpicker:
//            NumberPicker

private static class init
    implements init
{

    final Object mArgs[] = new Object[1];
    final StringBuilder mBuilder = new StringBuilder();
    Formatter mFmt;
    char mZeroDigit;

    private Formatter createFormatter(Locale locale)
    {
        return new Formatter(mBuilder, locale);
    }

    private static char getZeroDigit(Locale locale)
    {
        return (new DecimalFormatSymbols(locale)).getZeroDigit();
    }

    private void init(Locale locale)
    {
        mFmt = createFormatter(locale);
        mZeroDigit = getZeroDigit(locale);
    }

    public String format(int i)
    {
        Locale locale = Locale.getDefault();
        if (mZeroDigit != getZeroDigit(locale))
        {
            init(locale);
        }
        mArgs[0] = Integer.valueOf(i);
        mBuilder.delete(0, mBuilder.length());
        mFmt.format("%02d", mArgs);
        return mFmt.toString();
    }

    ()
    {
        init(Locale.getDefault());
    }
}
