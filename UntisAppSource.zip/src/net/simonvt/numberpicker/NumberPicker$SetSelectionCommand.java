// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package net.simonvt.numberpicker;

import android.widget.EditText;

// Referenced classes of package net.simonvt.numberpicker:
//            NumberPicker

class this._cls0
    implements Runnable
{

    private int mSelectionEnd;
    private int mSelectionStart;
    final NumberPicker this$0;

    public void run()
    {
        NumberPicker.access$100(NumberPicker.this).setSelection(mSelectionStart, mSelectionEnd);
    }


/*
    static int access$702( , int i)
    {
        .mSelectionStart = i;
        return i;
    }

*/


/*
    static int access$802(mSelectionStart mselectionstart, int i)
    {
        mselectionstart.mSelectionEnd = i;
        return i;
    }

*/

    mSelectionEnd()
    {
        this$0 = NumberPicker.this;
        super();
    }
}
