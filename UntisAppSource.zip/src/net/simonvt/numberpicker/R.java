// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package net.simonvt.numberpicker;


public final class R
{
    public static final class attr
    {

        public static int internalLayout = 0x7f010009;
        public static int internalMaxHeight = 0x7f010006;
        public static int internalMaxWidth = 0x7f010008;
        public static int internalMinHeight = 0x7f010005;
        public static int internalMinWidth = 0x7f010007;
        public static int numberPickerStyle = 0x7f010000;
        public static int selectionDivider = 0x7f010002;
        public static int selectionDividerHeight = 0x7f010003;
        public static int selectionDividersDistance = 0x7f010004;
        public static int solidColor = 0x7f010001;
        public static int virtualButtonPressedDrawable = 0x7f01000a;


        public attr()
        {
        }
    }

    public static final class color
    {

        public static int transparent = 0x7f070000;


        public color()
        {
        }
    }

    public static final class drawable
    {

        public static int item_background_holo_dark = 0x7f02009c;
        public static int item_background_holo_light = 0x7f02009d;
        public static int list_focused_holo = 0x7f02009e;
        public static int list_longpressed_holo = 0x7f02009f;
        public static int list_pressed_holo_dark = 0x7f0200a0;
        public static int list_pressed_holo_light = 0x7f0200a1;
        public static int list_selector_background_transition_holo_dark = 0x7f0200a2;
        public static int list_selector_background_transition_holo_light = 0x7f0200a3;
        public static int list_selector_disabled_holo_dark = 0x7f0200a4;
        public static int list_selector_disabled_holo_light = 0x7f0200a5;
        public static int np_numberpicker_selection_divider = 0x7f0200a6;


        public drawable()
        {
        }
    }

    public static final class id
    {

        public static int np__decrement = 0x7f080001;
        public static int np__increment = 0x7f080000;
        public static int np__numberpicker_input = 0x7f0800b2;


        public id()
        {
        }
    }

    public static final class layout
    {

        public static int number_picker_with_selector_wheel = 0x7f030038;


        public layout()
        {
        }
    }

    public static final class style
    {

        public static int NPWidget = 0x7f090000;
        public static int NPWidget_Holo_Light_NumberPicker = 0x7f090003;
        public static int NPWidget_Holo_NumberPicker = 0x7f090002;
        public static int NPWidget_NumberPicker = 0x7f090001;


        public style()
        {
        }
    }

    public static final class styleable
    {

        public static final int NumberPicker[] = {
            0x7f010001, 0x7f010002, 0x7f010003, 0x7f010004, 0x7f010005, 0x7f010006, 0x7f010007, 0x7f010008, 0x7f010009, 0x7f01000a
        };
        public static int NumberPicker_internalLayout = 8;
        public static int NumberPicker_internalMaxHeight = 5;
        public static int NumberPicker_internalMaxWidth = 7;
        public static int NumberPicker_internalMinHeight = 4;
        public static int NumberPicker_internalMinWidth = 6;
        public static int NumberPicker_selectionDivider = 1;
        public static int NumberPicker_selectionDividerHeight = 2;
        public static int NumberPicker_selectionDividersDistance = 3;
        public static int NumberPicker_solidColor = 0;
        public static int NumberPicker_virtualButtonPressedDrawable = 9;


        public styleable()
        {
        }
    }


    public R()
    {
    }
}
