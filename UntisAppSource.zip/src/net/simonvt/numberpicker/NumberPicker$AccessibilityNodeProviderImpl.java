// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package net.simonvt.numberpicker;

import android.content.Context;
import android.graphics.Rect;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityNodeProvider;
import android.widget.Button;
import android.widget.EditText;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

// Referenced classes of package net.simonvt.numberpicker:
//            NumberPicker

class mAccessibilityFocusedView extends AccessibilityNodeProvider
{

    private static final int UNDEFINED = 0x80000000;
    private static final int VIRTUAL_VIEW_ID_DECREMENT = 3;
    private static final int VIRTUAL_VIEW_ID_INCREMENT = 1;
    private static final int VIRTUAL_VIEW_ID_INPUT = 2;
    private int mAccessibilityFocusedView;
    private final int mTempArray[] = new int[2];
    private final Rect mTempRect = new Rect();
    final NumberPicker this$0;

    private AccessibilityNodeInfo createAccessibilityNodeInfoForNumberPicker(int i, int j, int k, int l)
    {
        AccessibilityNodeInfo accessibilitynodeinfo = AccessibilityNodeInfo.obtain();
        accessibilitynodeinfo.setClassName(net/simonvt/numberpicker/NumberPicker.getName());
        accessibilitynodeinfo.setPackageName(getContext().getPackageName());
        accessibilitynodeinfo.setSource(NumberPicker.this);
        if (hasVirtualDecrementButton())
        {
            accessibilitynodeinfo.addChild(NumberPicker.this, 3);
        }
        accessibilitynodeinfo.addChild(NumberPicker.this, 2);
        if (hasVirtualIncrementButton())
        {
            accessibilitynodeinfo.addChild(NumberPicker.this, 1);
        }
        accessibilitynodeinfo.setParent((View)getParentForAccessibility());
        accessibilitynodeinfo.setEnabled(isEnabled());
        accessibilitynodeinfo.setScrollable(true);
        if (mAccessibilityFocusedView != -1)
        {
            accessibilitynodeinfo.addAction(64);
        }
        if (mAccessibilityFocusedView == -1)
        {
            accessibilitynodeinfo.addAction(128);
        }
        if (isEnabled())
        {
            if (getWrapSelectorWheel() || getValue() < getMaxValue())
            {
                accessibilitynodeinfo.addAction(4096);
            }
            if (getWrapSelectorWheel() || getValue() > getMinValue())
            {
                accessibilitynodeinfo.addAction(8192);
            }
        }
        return accessibilitynodeinfo;
    }

    private AccessibilityNodeInfo createAccessibilityNodeInfoForVirtualButton(int i, String s, int j, int k, int l, int i1)
    {
        AccessibilityNodeInfo accessibilitynodeinfo = AccessibilityNodeInfo.obtain();
        accessibilitynodeinfo.setClassName(android/widget/Button.getName());
        accessibilitynodeinfo.setPackageName(getContext().getPackageName());
        accessibilitynodeinfo.setSource(NumberPicker.this, i);
        accessibilitynodeinfo.setParent(NumberPicker.this);
        accessibilitynodeinfo.setText(s);
        accessibilitynodeinfo.setClickable(true);
        accessibilitynodeinfo.setLongClickable(true);
        accessibilitynodeinfo.setEnabled(isEnabled());
        s = mTempRect;
        s.set(j, k, l, i1);
        accessibilitynodeinfo.setBoundsInParent(s);
        int ai[] = mTempArray;
        getLocationOnScreen(ai);
        s.offset(ai[0], ai[1]);
        accessibilitynodeinfo.setBoundsInScreen(s);
        if (mAccessibilityFocusedView != i)
        {
            accessibilitynodeinfo.addAction(64);
        }
        if (mAccessibilityFocusedView == i)
        {
            accessibilitynodeinfo.addAction(128);
        }
        if (isEnabled())
        {
            accessibilitynodeinfo.addAction(16);
        }
        return accessibilitynodeinfo;
    }

    private AccessibilityNodeInfo createAccessibiltyNodeInfoForInputText()
    {
        AccessibilityNodeInfo accessibilitynodeinfo = NumberPicker.access$100(NumberPicker.this).createAccessibilityNodeInfo();
        accessibilitynodeinfo.setSource(NumberPicker.this, 2);
        if (mAccessibilityFocusedView != 2)
        {
            accessibilitynodeinfo.addAction(64);
        }
        if (mAccessibilityFocusedView == 2)
        {
            accessibilitynodeinfo.addAction(128);
        }
        return accessibilitynodeinfo;
    }

    private void findAccessibilityNodeInfosByTextInChild(String s, int i, List list)
    {
        i;
        JVM INSTR tableswitch 1 3: default 28
    //                   1 171
    //                   2 71
    //                   3 29;
           goto _L1 _L2 _L3 _L4
_L1:
        Object obj;
        return;
_L4:
        if (!TextUtils.isEmpty(((CharSequence) (obj = getVirtualDecrementButtonText()))) && ((String) (obj)).toString().toLowerCase().contains(s))
        {
            list.add(createAccessibilityNodeInfo(3));
            return;
        }
        continue; /* Loop/switch isn't completed */
_L3:
        obj = NumberPicker.access$100(NumberPicker.this).getText();
        if (!TextUtils.isEmpty(((CharSequence) (obj))) && ((CharSequence) (obj)).toString().toLowerCase().contains(s))
        {
            list.add(createAccessibilityNodeInfo(2));
            return;
        }
        obj = NumberPicker.access$100(NumberPicker.this).getText();
        if (!TextUtils.isEmpty(((CharSequence) (obj))) && ((CharSequence) (obj)).toString().toLowerCase().contains(s))
        {
            list.add(createAccessibilityNodeInfo(2));
            return;
        }
        continue; /* Loop/switch isn't completed */
_L2:
        if (!TextUtils.isEmpty(((CharSequence) (obj = getVirtualIncrementButtonText()))) && ((String) (obj)).toString().toLowerCase().contains(s))
        {
            list.add(createAccessibilityNodeInfo(1));
            return;
        }
        if (true) goto _L1; else goto _L5
_L5:
    }

    private String getVirtualDecrementButtonText()
    {
        int j = NumberPicker.access$2200(NumberPicker.this) - 1;
        int i = j;
        if (NumberPicker.access$2300(NumberPicker.this))
        {
            i = NumberPicker.access$2400(NumberPicker.this, j);
        }
        if (i >= NumberPicker.access$2500(NumberPicker.this))
        {
            if (NumberPicker.access$1000(NumberPicker.this) == null)
            {
                return NumberPicker.access$2600(NumberPicker.this, i);
            } else
            {
                return NumberPicker.access$1000(NumberPicker.this)[i - NumberPicker.access$2500(NumberPicker.this)];
            }
        } else
        {
            return null;
        }
    }

    private String getVirtualIncrementButtonText()
    {
        int j = NumberPicker.access$2200(NumberPicker.this) + 1;
        int i = j;
        if (NumberPicker.access$2300(NumberPicker.this))
        {
            i = NumberPicker.access$2400(NumberPicker.this, j);
        }
        if (i <= NumberPicker.access$1200(NumberPicker.this))
        {
            if (NumberPicker.access$1000(NumberPicker.this) == null)
            {
                return NumberPicker.access$2600(NumberPicker.this, i);
            } else
            {
                return NumberPicker.access$1000(NumberPicker.this)[i - NumberPicker.access$2500(NumberPicker.this)];
            }
        } else
        {
            return null;
        }
    }

    private boolean hasVirtualDecrementButton()
    {
        return getWrapSelectorWheel() || getValue() > getMinValue();
    }

    private boolean hasVirtualIncrementButton()
    {
        return getWrapSelectorWheel() || getValue() < getMaxValue();
    }

    private void sendAccessibilityEventForVirtualButton(int i, int j, String s)
    {
        if (((AccessibilityManager)getContext().getSystemService("accessibility")).isEnabled())
        {
            AccessibilityEvent accessibilityevent = AccessibilityEvent.obtain(j);
            accessibilityevent.setClassName(android/widget/Button.getName());
            accessibilityevent.setPackageName(getContext().getPackageName());
            accessibilityevent.getText().add(s);
            accessibilityevent.setEnabled(isEnabled());
            accessibilityevent.setSource(NumberPicker.this, i);
            requestSendAccessibilityEvent(NumberPicker.this, accessibilityevent);
        }
    }

    private void sendAccessibilityEventForVirtualText(int i)
    {
        if (((AccessibilityManager)getContext().getSystemService("accessibility")).isEnabled())
        {
            AccessibilityEvent accessibilityevent = AccessibilityEvent.obtain(i);
            NumberPicker.access$100(NumberPicker.this).onInitializeAccessibilityEvent(accessibilityevent);
            NumberPicker.access$100(NumberPicker.this).onPopulateAccessibilityEvent(accessibilityevent);
            accessibilityevent.setSource(NumberPicker.this, 2);
            requestSendAccessibilityEvent(NumberPicker.this, accessibilityevent);
        }
    }

    public AccessibilityNodeInfo createAccessibilityNodeInfo(int i)
    {
        switch (i)
        {
        case 0: // '\0'
        default:
            return super.createAccessibilityNodeInfo(i);

        case -1: 
            return createAccessibilityNodeInfoForNumberPicker(getScrollX(), getScrollY(), getScrollX() + (getRight() - getLeft()), getScrollY() + (getBottom() - getTop()));

        case 3: // '\003'
            String s = getVirtualDecrementButtonText();
            i = getScrollX();
            int j = getScrollY();
            int l = getScrollX();
            int j1 = getRight();
            int l1 = getLeft();
            int j2 = NumberPicker.access$1700(NumberPicker.this);
            return createAccessibilityNodeInfoForVirtualButton(3, s, i, j, (j1 - l1) + l, NumberPicker.access$2100(NumberPicker.this) + j2);

        case 2: // '\002'
            return createAccessibiltyNodeInfoForInputText();

        case 1: // '\001'
            String s1 = getVirtualIncrementButtonText();
            i = getScrollX();
            int k = NumberPicker.access$1500(NumberPicker.this);
            int i1 = NumberPicker.access$2100(NumberPicker.this);
            int k1 = getScrollX();
            int i2 = getRight();
            int k2 = getLeft();
            int l2 = getScrollY();
            return createAccessibilityNodeInfoForVirtualButton(1, s1, i, k - i1, (i2 - k2) + k1, (getBottom() - getTop()) + l2);
        }
    }

    public List findAccessibilityNodeInfosByText(String s, int i)
    {
        if (TextUtils.isEmpty(s))
        {
            return Collections.emptyList();
        }
        String s1 = s.toLowerCase();
        ArrayList arraylist = new ArrayList();
        switch (i)
        {
        case 0: // '\0'
        default:
            return super.findAccessibilityNodeInfosByText(s, i);

        case -1: 
            findAccessibilityNodeInfosByTextInChild(s1, 3, arraylist);
            findAccessibilityNodeInfosByTextInChild(s1, 2, arraylist);
            findAccessibilityNodeInfosByTextInChild(s1, 1, arraylist);
            return arraylist;

        case 1: // '\001'
        case 2: // '\002'
        case 3: // '\003'
            findAccessibilityNodeInfosByTextInChild(s1, i, arraylist);
            break;
        }
        return arraylist;
    }

    public boolean performAction(int i, int j, Bundle bundle)
    {
        boolean flag1;
        boolean flag2;
        flag2 = false;
        flag1 = false;
        i;
        JVM INSTR tableswitch -1 3: default 40
    //                   -1 52
    //                   0 40
    //                   1 520
    //                   2 271
    //                   3 701;
           goto _L1 _L2 _L1 _L3 _L4 _L5
_L1:
        boolean flag = super.performAction(i, j, bundle);
_L10:
        return flag;
_L2:
        j;
        JVM INSTR lookupswitch 4: default 96
    //                   64: 99
    //                   128: 129
    //                   4096: 161
    //                   8192: 216;
           goto _L1 _L6 _L7 _L8 _L9
_L6:
        flag = flag1;
        if (mAccessibilityFocusedView != i)
        {
            mAccessibilityFocusedView = i;
            performAccessibilityAction(64, null);
            return true;
        }
          goto _L10
_L7:
        flag = flag1;
        if (mAccessibilityFocusedView == i)
        {
            mAccessibilityFocusedView = 0x80000000;
            performAccessibilityAction(128, null);
            return true;
        }
          goto _L10
_L8:
        flag = flag1;
        if (!isEnabled()) goto _L10; else goto _L11
_L11:
        if (getWrapSelectorWheel())
        {
            break; /* Loop/switch isn't completed */
        }
        flag = flag1;
        if (getValue() >= getMaxValue()) goto _L10; else goto _L12
_L12:
        NumberPicker.access$200(NumberPicker.this, true);
        return true;
_L9:
        flag = flag1;
        if (!isEnabled()) goto _L10; else goto _L13
_L13:
        if (getWrapSelectorWheel())
        {
            break; /* Loop/switch isn't completed */
        }
        flag = flag1;
        if (getValue() <= getMinValue()) goto _L10; else goto _L14
_L14:
        NumberPicker.access$200(NumberPicker.this, false);
        return true;
_L4:
        switch (j)
        {
        default:
            return NumberPicker.access$100(NumberPicker.this).performAccessibilityAction(j, bundle);

        case 1: // '\001'
            flag = flag1;
            if (isEnabled())
            {
                flag = flag1;
                if (!NumberPicker.access$100(NumberPicker.this).isFocused())
                {
                    return NumberPicker.access$100(NumberPicker.this).requestFocus();
                }
            }
            break;

        case 2: // '\002'
            flag = flag1;
            if (isEnabled())
            {
                flag = flag1;
                if (NumberPicker.access$100(NumberPicker.this).isFocused())
                {
                    NumberPicker.access$100(NumberPicker.this).clearFocus();
                    return true;
                }
            }
            break;

        case 16: // '\020'
            flag = flag1;
            if (isEnabled())
            {
                NumberPicker.access$1900(NumberPicker.this);
                return true;
            }
            break;

        case 64: // '@'
            flag = flag1;
            if (mAccessibilityFocusedView != i)
            {
                mAccessibilityFocusedView = i;
                sendAccessibilityEventForVirtualView(i, 32768);
                NumberPicker.access$100(NumberPicker.this).invalidate();
                return true;
            }
            break;

        case 128: 
            flag = flag1;
            if (mAccessibilityFocusedView == i)
            {
                mAccessibilityFocusedView = 0x80000000;
                sendAccessibilityEventForVirtualView(i, 0x10000);
                NumberPicker.access$100(NumberPicker.this).invalidate();
                return true;
            }
            break;
        }
        if (true) goto _L10; else goto _L15
_L15:
_L3:
        switch (j)
        {
        default:
            return false;

        case 16: // '\020'
            flag = flag1;
            if (isEnabled())
            {
                NumberPicker.access$200(NumberPicker.this, true);
                sendAccessibilityEventForVirtualView(i, 1);
                return true;
            }
            break;

        case 64: // '@'
            flag = flag1;
            if (mAccessibilityFocusedView != i)
            {
                mAccessibilityFocusedView = i;
                sendAccessibilityEventForVirtualView(i, 32768);
                invalidate(0, NumberPicker.access$1500(NumberPicker.this), getRight(), getBottom());
                return true;
            }
            break;

        case 128: 
            flag = flag1;
            if (mAccessibilityFocusedView == i)
            {
                mAccessibilityFocusedView = 0x80000000;
                sendAccessibilityEventForVirtualView(i, 0x10000);
                invalidate(0, NumberPicker.access$1500(NumberPicker.this), getRight(), getBottom());
                return true;
            }
            break;
        }
        if (true) goto _L10; else goto _L16
_L16:
_L5:
        switch (j)
        {
        default:
            return false;

        case 16: // '\020'
            flag = flag1;
            if (isEnabled())
            {
                flag = flag2;
                if (i == 1)
                {
                    flag = true;
                }
                NumberPicker.access$200(NumberPicker.this, flag);
                sendAccessibilityEventForVirtualView(i, 1);
                return true;
            }
            break;

        case 64: // '@'
            flag = flag1;
            if (mAccessibilityFocusedView != i)
            {
                mAccessibilityFocusedView = i;
                sendAccessibilityEventForVirtualView(i, 32768);
                invalidate(0, 0, getRight(), NumberPicker.access$1700(NumberPicker.this));
                return true;
            }
            break;

        case 128: 
            flag = flag1;
            if (mAccessibilityFocusedView == i)
            {
                mAccessibilityFocusedView = 0x80000000;
                sendAccessibilityEventForVirtualView(i, 0x10000);
                invalidate(0, 0, getRight(), NumberPicker.access$1700(NumberPicker.this));
                return true;
            }
            break;
        }
        if (true) goto _L10; else goto _L17
_L17:
    }

    public void sendAccessibilityEventForVirtualView(int i, int j)
    {
        i;
        JVM INSTR tableswitch 1 3: default 28
    //                   1 53
    //                   2 47
    //                   3 29;
           goto _L1 _L2 _L3 _L4
_L1:
        return;
_L4:
        if (hasVirtualDecrementButton())
        {
            sendAccessibilityEventForVirtualButton(i, j, getVirtualDecrementButtonText());
            return;
        }
        continue; /* Loop/switch isn't completed */
_L3:
        sendAccessibilityEventForVirtualText(j);
        return;
_L2:
        if (hasVirtualIncrementButton())
        {
            sendAccessibilityEventForVirtualButton(i, j, getVirtualIncrementButtonText());
            return;
        }
        if (true) goto _L1; else goto _L5
_L5:
    }

    I()
    {
        this$0 = NumberPicker.this;
        super();
        mAccessibilityFocusedView = 0x80000000;
    }
}
