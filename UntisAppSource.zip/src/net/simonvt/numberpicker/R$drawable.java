// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package net.simonvt.numberpicker;


// Referenced classes of package net.simonvt.numberpicker:
//            R

public static final class 
{

    public static int item_background_holo_dark = 0x7f02009c;
    public static int item_background_holo_light = 0x7f02009d;
    public static int list_focused_holo = 0x7f02009e;
    public static int list_longpressed_holo = 0x7f02009f;
    public static int list_pressed_holo_dark = 0x7f0200a0;
    public static int list_pressed_holo_light = 0x7f0200a1;
    public static int list_selector_background_transition_holo_dark = 0x7f0200a2;
    public static int list_selector_background_transition_holo_light = 0x7f0200a3;
    public static int list_selector_disabled_holo_dark = 0x7f0200a4;
    public static int list_selector_disabled_holo_light = 0x7f0200a5;
    public static int np_numberpicker_selection_divider = 0x7f0200a6;


    public ()
    {
    }
}
