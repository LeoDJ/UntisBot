// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package net.simonvt.numberpicker;

import android.view.View;
import android.widget.EditText;

// Referenced classes of package net.simonvt.numberpicker:
//            NumberPicker

class this._cls0
    implements android.view.kListener
{

    final NumberPicker this$0;

    public boolean onLongClick(View view)
    {
        NumberPicker.access$000(NumberPicker.this);
        NumberPicker.access$100(NumberPicker.this).clearFocus();
        if (view.getId() == ent)
        {
            NumberPicker.access$300(NumberPicker.this, true, 0L);
            return true;
        } else
        {
            NumberPicker.access$300(NumberPicker.this, false, 0L);
            return true;
        }
    }

    ()
    {
        this$0 = NumberPicker.this;
        super();
    }
}
