// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package net.simonvt.timepicker;

import net.simonvt.numberpicker.NumberPicker;

// Referenced classes of package net.simonvt.timepicker:
//            TimePicker

class this._cls0
    implements net.simonvt.numberpicker.OnValueChangeListener
{

    final TimePicker this$0;

    public void onValueChange(NumberPicker numberpicker, int i, int j)
    {
        int k;
        int l;
        boolean flag;
        boolean flag2;
        flag2 = true;
        flag = true;
        TimePicker.access$000(TimePicker.this);
        k = TimePicker.access$400(TimePicker.this).getMinValue();
        l = TimePicker.access$400(TimePicker.this).getMaxValue();
        if (i != l || j != k) goto _L2; else goto _L1
_L1:
        i = TimePicker.access$500(TimePicker.this).getValue() + 1;
        if (!is24HourView() && i == 12)
        {
            numberpicker = TimePicker.this;
            if (TimePicker.access$100(TimePicker.this))
            {
                flag = false;
            }
            TimePicker.access$102(numberpicker, flag);
            TimePicker.access$200(TimePicker.this);
        }
        TimePicker.access$500(TimePicker.this).setValue(i);
_L4:
        TimePicker.access$300(TimePicker.this);
        return;
_L2:
        if (i == k && j == l)
        {
            i = TimePicker.access$500(TimePicker.this).getValue() - 1;
            if (!is24HourView() && i == 11)
            {
                numberpicker = TimePicker.this;
                boolean flag1;
                if (!TimePicker.access$100(TimePicker.this))
                {
                    flag1 = flag2;
                } else
                {
                    flag1 = false;
                }
                TimePicker.access$102(numberpicker, flag1);
                TimePicker.access$200(TimePicker.this);
            }
            TimePicker.access$500(TimePicker.this).setValue(i);
        }
        if (true) goto _L4; else goto _L3
_L3:
    }

    r()
    {
        this$0 = TimePicker.this;
        super();
    }
}
