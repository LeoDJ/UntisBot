// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package net.simonvt.timepicker;


// Referenced classes of package net.simonvt.timepicker:
//            R

public static final class 
{

    public static int cancel = 0x7f0a0004;
    public static int date_picker_dialog_title = 0x7f0a0001;
    public static int date_time_done = 0x7f0a0003;
    public static int date_time_set = 0x7f0a0002;
    public static int time_picker_decrement_hour_button = 0x7f0a0008;
    public static int time_picker_decrement_minute_button = 0x7f0a0006;
    public static int time_picker_decrement_set_am_button = 0x7f0a000a;
    public static int time_picker_dialog_title = 0x7f0a0000;
    public static int time_picker_increment_hour_button = 0x7f0a0007;
    public static int time_picker_increment_minute_button = 0x7f0a0005;
    public static int time_picker_increment_set_pm_button = 0x7f0a0009;
    public static int time_picker_separator = 0x7f0a000b;


    public ()
    {
    }
}
