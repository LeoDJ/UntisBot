// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package net.simonvt.timepicker;


// Referenced classes of package net.simonvt.timepicker:
//            R

public static final class 
{

    public static int internalLayout = 0x7f010009;
    public static int internalMaxHeight = 0x7f010006;
    public static int internalMaxWidth = 0x7f010008;
    public static int internalMinHeight = 0x7f010005;
    public static int internalMinWidth = 0x7f010007;
    public static int numberPickerStyle = 0x7f010000;
    public static int selectionDivider = 0x7f010002;
    public static int selectionDividerHeight = 0x7f010003;
    public static int selectionDividersDistance = 0x7f010004;
    public static int solidColor = 0x7f010001;
    public static int timePickerStyle = 0x7f01000b;
    public static int virtualButtonPressedDrawable = 0x7f01000a;


    public ()
    {
    }
}
