// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package net.simonvt.timepicker;


// Referenced classes of package net.simonvt.timepicker:
//            R

public static final class 
{

    public static final int NumberPicker[] = {
        0x7f010001, 0x7f010002, 0x7f010003, 0x7f010004, 0x7f010005, 0x7f010006, 0x7f010007, 0x7f010008, 0x7f010009, 0x7f01000a
    };
    public static int NumberPicker_internalLayout = 8;
    public static int NumberPicker_internalMaxHeight = 5;
    public static int NumberPicker_internalMaxWidth = 7;
    public static int NumberPicker_internalMinHeight = 4;
    public static int NumberPicker_internalMinWidth = 6;
    public static int NumberPicker_selectionDivider = 1;
    public static int NumberPicker_selectionDividerHeight = 2;
    public static int NumberPicker_selectionDividersDistance = 3;
    public static int NumberPicker_solidColor = 0;
    public static int NumberPicker_virtualButtonPressedDrawable = 9;


    public ()
    {
    }
}
