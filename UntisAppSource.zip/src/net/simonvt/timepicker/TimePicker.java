// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package net.simonvt.timepicker;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.format.DateUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.TextView;
import java.text.DateFormatSymbols;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import net.simonvt.numberpicker.NumberPicker;

public class TimePicker extends FrameLayout
{
    public static interface OnTimeChangedListener
    {

        public abstract void onTimeChanged(TimePicker timepicker, int i, int j);
    }

    private static class SavedState extends android.view.View.BaseSavedState
    {

        public static final android.os.Parcelable.Creator CREATOR = new android.os.Parcelable.Creator() {

            public volatile Object createFromParcel(Parcel parcel)
            {
                return createFromParcel(parcel);
            }

            public SavedState createFromParcel(Parcel parcel)
            {
                return new SavedState(parcel);
            }

            public volatile Object[] newArray(int i)
            {
                return newArray(i);
            }

            public SavedState[] newArray(int i)
            {
                return new SavedState[i];
            }

        };
        private final int mHour;
        private final int mMinute;

        public int getHour()
        {
            return mHour;
        }

        public int getMinute()
        {
            return mMinute;
        }

        public void writeToParcel(Parcel parcel, int i)
        {
            super.writeToParcel(parcel, i);
            parcel.writeInt(mHour);
            parcel.writeInt(mMinute);
        }


        private SavedState(Parcel parcel)
        {
            super(parcel);
            mHour = parcel.readInt();
            mMinute = parcel.readInt();
        }


        private SavedState(Parcelable parcelable, int i, int j)
        {
            super(parcelable);
            mHour = i;
            mMinute = j;
        }

    }


    private static final boolean DEFAULT_ENABLED_STATE = true;
    private static final int HOURS_IN_HALF_DAY = 12;
    private static final OnTimeChangedListener NO_OP_CHANGE_LISTENER = new OnTimeChangedListener() {

        public void onTimeChanged(TimePicker timepicker, int i, int j)
        {
        }

    };
    private int hourEnd;
    private int hourStart;
    private final Button mAmPmButton;
    private final NumberPicker mAmPmSpinner;
    private final EditText mAmPmSpinnerInput;
    private final String mAmPmStrings[];
    private Locale mCurrentLocale;
    private final TextView mDivider;
    private final NumberPicker mHourSpinner;
    private final EditText mHourSpinnerInput;
    private boolean mIs24HourView;
    private boolean mIsAm;
    private boolean mIsEnabled;
    private final NumberPicker mMinuteSpinner;
    private final EditText mMinuteSpinnerInput;
    private OnTimeChangedListener mOnTimeChangedListener;
    private Calendar mTempCalendar;
    private int minuteEnd;
    private int minuteStart;

    public TimePicker(Context context)
    {
        this(context, null);
    }

    public TimePicker(Context context, AttributeSet attributeset)
    {
        this(context, attributeset, R.attr.timePickerStyle);
    }

    public TimePicker(Context context, AttributeSet attributeset, int i)
    {
        super(context, attributeset, i);
        mIsEnabled = true;
        minuteStart = 0;
        minuteEnd = 59;
        hourStart = 0;
        hourEnd = 23;
        setCurrentLocale(Locale.getDefault());
        i = R.layout.time_picker_holo;
        ((LayoutInflater)context.getSystemService("layout_inflater")).inflate(i, this, true);
        mHourSpinner = (NumberPicker)findViewById(R.id.hour);
        mHourSpinner.setOnValueChangedListener(new net.simonvt.numberpicker.NumberPicker.OnValueChangeListener() {

            final TimePicker this$0;

            public void onValueChange(NumberPicker numberpicker, int j, int k)
            {
                updateInputState();
                if (!is24HourView() && (j == 11 && k == 12 || j == 12 && k == 11))
                {
                    numberpicker = TimePicker.this;
                    boolean flag;
                    if (!mIsAm)
                    {
                        flag = true;
                    } else
                    {
                        flag = false;
                    }
                    numberpicker.mIsAm = flag;
                    updateAmPmControl();
                }
                onTimeChanged();
            }

            
            {
                this$0 = TimePicker.this;
                super();
            }
        });
        mHourSpinnerInput = (EditText)mHourSpinner.findViewById(R.id.np__numberpicker_input);
        mHourSpinnerInput.setImeOptions(5);
        mDivider = (TextView)findViewById(R.id.divider);
        if (mDivider != null)
        {
            mDivider.setText(R.string.time_picker_separator);
        }
        mMinuteSpinner = (NumberPicker)findViewById(R.id.minute);
        mMinuteSpinner.setMinValue(minuteStart);
        mMinuteSpinner.setMaxValue(minuteEnd);
        mMinuteSpinner.setOnLongPressUpdateInterval(100L);
        mMinuteSpinner.setFormatter(NumberPicker.getTwoDigitFormatter());
        mMinuteSpinner.setOnValueChangedListener(new net.simonvt.numberpicker.NumberPicker.OnValueChangeListener() {

            final TimePicker this$0;

            public void onValueChange(NumberPicker numberpicker, int j, int k)
            {
                int l;
                int i1;
                boolean flag;
                boolean flag2;
                flag2 = true;
                flag = true;
                updateInputState();
                l = mMinuteSpinner.getMinValue();
                i1 = mMinuteSpinner.getMaxValue();
                if (j != i1 || k != l) goto _L2; else goto _L1
_L1:
                j = mHourSpinner.getValue() + 1;
                if (!is24HourView() && j == 12)
                {
                    numberpicker = TimePicker.this;
                    if (mIsAm)
                    {
                        flag = false;
                    }
                    numberpicker.mIsAm = flag;
                    updateAmPmControl();
                }
                mHourSpinner.setValue(j);
_L4:
                onTimeChanged();
                return;
_L2:
                if (j == l && k == i1)
                {
                    j = mHourSpinner.getValue() - 1;
                    if (!is24HourView() && j == 11)
                    {
                        numberpicker = TimePicker.this;
                        boolean flag1;
                        if (!mIsAm)
                        {
                            flag1 = flag2;
                        } else
                        {
                            flag1 = false;
                        }
                        numberpicker.mIsAm = flag1;
                        updateAmPmControl();
                    }
                    mHourSpinner.setValue(j);
                }
                if (true) goto _L4; else goto _L3
_L3:
            }

            
            {
                this$0 = TimePicker.this;
                super();
            }
        });
        mMinuteSpinnerInput = (EditText)mMinuteSpinner.findViewById(R.id.np__numberpicker_input);
        mMinuteSpinnerInput.setImeOptions(5);
        mAmPmStrings = (new DateFormatSymbols()).getAmPmStrings();
        context = findViewById(R.id.amPm);
        if (context instanceof Button)
        {
            mAmPmSpinner = null;
            mAmPmSpinnerInput = null;
            mAmPmButton = (Button)context;
            mAmPmButton.setOnClickListener(new android.view.View.OnClickListener() {

                final TimePicker this$0;

                public void onClick(View view)
                {
                    view.requestFocus();
                    view = TimePicker.this;
                    boolean flag;
                    if (!mIsAm)
                    {
                        flag = true;
                    } else
                    {
                        flag = false;
                    }
                    view.mIsAm = flag;
                    updateAmPmControl();
                    onTimeChanged();
                }

            
            {
                this$0 = TimePicker.this;
                super();
            }
            });
        } else
        {
            mAmPmButton = null;
            mAmPmSpinner = (NumberPicker)context;
            mAmPmSpinner.setMinValue(0);
            mAmPmSpinner.setMaxValue(1);
            mAmPmSpinner.setDisplayedValues(mAmPmStrings);
            mAmPmSpinner.setOnValueChangedListener(new net.simonvt.numberpicker.NumberPicker.OnValueChangeListener() {

                final TimePicker this$0;

                public void onValueChange(NumberPicker numberpicker, int j, int k)
                {
                    updateInputState();
                    numberpicker.requestFocus();
                    numberpicker = TimePicker.this;
                    boolean flag;
                    if (!mIsAm)
                    {
                        flag = true;
                    } else
                    {
                        flag = false;
                    }
                    numberpicker.mIsAm = flag;
                    updateAmPmControl();
                    onTimeChanged();
                }

            
            {
                this$0 = TimePicker.this;
                super();
            }
            });
            mAmPmSpinnerInput = (EditText)mAmPmSpinner.findViewById(R.id.np__numberpicker_input);
            mAmPmSpinnerInput.setImeOptions(6);
        }
        updateHourControl();
        updateAmPmControl();
        setOnTimeChangedListener(NO_OP_CHANGE_LISTENER);
        setCurrentHour(Integer.valueOf(mTempCalendar.get(11)));
        setCurrentMinute(Integer.valueOf(mTempCalendar.get(12)));
        if (!isEnabled())
        {
            setEnabled(false);
        }
        setContentDescriptions();
        if (android.os.Build.VERSION.SDK_INT >= 16 && getImportantForAccessibility() == 0)
        {
            setImportantForAccessibility(1);
        }
    }

    private void onTimeChanged()
    {
        sendAccessibilityEvent(4);
        if (mOnTimeChangedListener != null)
        {
            mOnTimeChangedListener.onTimeChanged(this, getCurrentHour().intValue(), getCurrentMinute().intValue());
        }
    }

    private void setContentDescriptions()
    {
    }

    private void setCurrentLocale(Locale locale)
    {
        if (locale.equals(mCurrentLocale))
        {
            return;
        } else
        {
            mCurrentLocale = locale;
            mTempCalendar = Calendar.getInstance(locale);
            return;
        }
    }

    private void trySetContentDescription(View view, int i, int j)
    {
        view = view.findViewById(i);
        if (view != null)
        {
            view.setContentDescription(getContext().getString(j));
        }
    }

    private void updateAmPmControl()
    {
        if (is24HourView())
        {
            if (mAmPmSpinner != null)
            {
                mAmPmSpinner.setVisibility(8);
            } else
            {
                mAmPmButton.setVisibility(8);
            }
        } else
        {
            int i;
            if (mIsAm)
            {
                i = 0;
            } else
            {
                i = 1;
            }
            if (mAmPmSpinner != null)
            {
                mAmPmSpinner.setValue(i);
                mAmPmSpinner.setVisibility(0);
            } else
            {
                mAmPmButton.setText(mAmPmStrings[i]);
                mAmPmButton.setVisibility(0);
            }
        }
        sendAccessibilityEvent(4);
    }

    private void updateHourControl()
    {
        if (is24HourView())
        {
            mHourSpinner.setMinValue(hourStart);
            mHourSpinner.setMaxValue(hourEnd);
            mHourSpinner.setFormatter(NumberPicker.getTwoDigitFormatter());
            return;
        } else
        {
            mHourSpinner.setMinValue(1);
            mHourSpinner.setMaxValue(12);
            mHourSpinner.setFormatter(null);
            return;
        }
    }

    private void updateInputState()
    {
        InputMethodManager inputmethodmanager = (InputMethodManager)getContext().getSystemService("input_method");
        if (inputmethodmanager != null)
        {
            if (inputmethodmanager.isActive(mHourSpinnerInput))
            {
                mHourSpinnerInput.clearFocus();
                inputmethodmanager.hideSoftInputFromWindow(getWindowToken(), 0);
            } else
            {
                if (inputmethodmanager.isActive(mMinuteSpinnerInput))
                {
                    mMinuteSpinnerInput.clearFocus();
                    inputmethodmanager.hideSoftInputFromWindow(getWindowToken(), 0);
                    return;
                }
                if (inputmethodmanager.isActive(mAmPmSpinnerInput))
                {
                    mAmPmSpinnerInput.clearFocus();
                    inputmethodmanager.hideSoftInputFromWindow(getWindowToken(), 0);
                    return;
                }
            }
        }
    }

    public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent accessibilityevent)
    {
        onPopulateAccessibilityEvent(accessibilityevent);
        return true;
    }

    public int getBaseline()
    {
        return mHourSpinner.getBaseline();
    }

    public Integer getCurrentHour()
    {
        int i = mHourSpinner.getValue();
        if (is24HourView())
        {
            return Integer.valueOf(i);
        }
        if (mIsAm)
        {
            return Integer.valueOf(i % 12);
        } else
        {
            return Integer.valueOf(i % 12 + 12);
        }
    }

    public Integer getCurrentMinute()
    {
        return Integer.valueOf(mMinuteSpinner.getValue());
    }

    public boolean is24HourView()
    {
        return true;
    }

    public boolean isEnabled()
    {
        return mIsEnabled;
    }

    protected void onConfigurationChanged(Configuration configuration)
    {
        super.onConfigurationChanged(configuration);
        setCurrentLocale(configuration.locale);
    }

    public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityevent)
    {
        super.onInitializeAccessibilityEvent(accessibilityevent);
        accessibilityevent.setClassName(net/simonvt/timepicker/TimePicker.getName());
    }

    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilitynodeinfo)
    {
        super.onInitializeAccessibilityNodeInfo(accessibilitynodeinfo);
        accessibilitynodeinfo.setClassName(net/simonvt/timepicker/TimePicker.getName());
    }

    public void onPopulateAccessibilityEvent(AccessibilityEvent accessibilityevent)
    {
        super.onPopulateAccessibilityEvent(accessibilityevent);
        String s;
        int i;
        if (mIs24HourView)
        {
            i = 1 | 0x80;
        } else
        {
            i = 1 | 0x40;
        }
        mTempCalendar.set(11, getCurrentHour().intValue());
        mTempCalendar.set(12, getCurrentMinute().intValue());
        s = DateUtils.formatDateTime(getContext(), mTempCalendar.getTimeInMillis(), i);
        accessibilityevent.getText().add(s);
    }

    protected void onRestoreInstanceState(Parcelable parcelable)
    {
        parcelable = (SavedState)parcelable;
        super.onRestoreInstanceState(parcelable.getSuperState());
        setCurrentHour(Integer.valueOf(parcelable.getHour()));
        setCurrentMinute(Integer.valueOf(parcelable.getMinute()));
    }

    protected Parcelable onSaveInstanceState()
    {
        return new SavedState(super.onSaveInstanceState(), getCurrentHour().intValue(), getCurrentMinute().intValue());
    }

    public void setCurrentHour(Integer integer)
    {
        Integer integer1;
        if (integer == null || integer == getCurrentHour())
        {
            return;
        }
        integer1 = integer;
        if (is24HourView()) goto _L2; else goto _L1
_L1:
        if (integer.intValue() < 12) goto _L4; else goto _L3
_L3:
        mIsAm = false;
        integer1 = integer;
        if (integer.intValue() > 12)
        {
            integer1 = Integer.valueOf(integer.intValue() - 12);
        }
_L6:
        updateAmPmControl();
_L2:
        mHourSpinner.setValue(integer1.intValue());
        onTimeChanged();
        return;
_L4:
        mIsAm = true;
        integer1 = integer;
        if (integer.intValue() == 0)
        {
            integer1 = Integer.valueOf(12);
        }
        if (true) goto _L6; else goto _L5
_L5:
    }

    public void setCurrentMinute(Integer integer)
    {
        if (integer == getCurrentMinute())
        {
            return;
        } else
        {
            mMinuteSpinner.setValue(integer.intValue());
            onTimeChanged();
            return;
        }
    }

    public void setEnabled(boolean flag)
    {
        if (mIsEnabled == flag)
        {
            return;
        }
        super.setEnabled(flag);
        mMinuteSpinner.setEnabled(flag);
        if (mDivider != null)
        {
            mDivider.setEnabled(flag);
        }
        mHourSpinner.setEnabled(flag);
        if (mAmPmSpinner != null)
        {
            mAmPmSpinner.setEnabled(flag);
        } else
        {
            mAmPmButton.setEnabled(flag);
        }
        mIsEnabled = flag;
    }

    public void setHourRange(int i, int j)
    {
        hourEnd = j;
        hourStart = i;
        mHourSpinner.setMinValue(i);
        mHourSpinner.setMaxValue(j);
    }

    public void setIs24HourView(Boolean boolean1)
    {
        if (mIs24HourView == boolean1.booleanValue())
        {
            return;
        } else
        {
            mIs24HourView = boolean1.booleanValue();
            int i = getCurrentHour().intValue();
            updateHourControl();
            setCurrentHour(Integer.valueOf(i));
            updateAmPmControl();
            return;
        }
    }

    public void setMinuteRange(int i, int j)
    {
        minuteStart = i;
        minuteEnd = j;
        mMinuteSpinner.setMinValue(i);
        mMinuteSpinner.setMaxValue(j);
    }

    public void setOnTimeChangedListener(OnTimeChangedListener ontimechangedlistener)
    {
        mOnTimeChangedListener = ontimechangedlistener;
    }





/*
    static boolean access$102(TimePicker timepicker, boolean flag)
    {
        timepicker.mIsAm = flag;
        return flag;
    }

*/




}
