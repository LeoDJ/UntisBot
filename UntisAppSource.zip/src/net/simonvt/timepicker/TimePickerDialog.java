// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package net.simonvt.timepicker;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;

// Referenced classes of package net.simonvt.timepicker:
//            TimePicker

public class TimePickerDialog extends AlertDialog
    implements android.content.DialogInterface.OnClickListener, TimePicker.OnTimeChangedListener
{
    public static interface OnTimeSetListener
    {

        public abstract void onTimeSet(TimePicker timepicker, int i, int j);
    }


    private static final String HOUR = "hour";
    private static final String IS_24_HOUR = "is24hour";
    private static final String MINUTE = "minute";
    private final OnTimeSetListener mCallback;
    int mInitialHourOfDay;
    int mInitialMinute;
    boolean mIs24HourView;
    private final TimePicker mTimePicker;

    public TimePickerDialog(Context context, int i, OnTimeSetListener ontimesetlistener, int j, int k, boolean flag)
    {
        super(context, i);
        mCallback = ontimesetlistener;
        mInitialHourOfDay = j;
        mInitialMinute = k;
        mIs24HourView = flag;
        setIcon(0);
        setTitle(R.string.time_picker_dialog_title);
        context = getContext();
        setButton(-1, context.getText(R.string.date_time_done), this);
        context = ((LayoutInflater)context.getSystemService("layout_inflater")).inflate(R.layout.time_picker_dialog, null);
        setView(context);
        mTimePicker = (TimePicker)context.findViewById(R.id.timePicker);
        mTimePicker.setIs24HourView(Boolean.valueOf(mIs24HourView));
        mTimePicker.setCurrentHour(Integer.valueOf(mInitialHourOfDay));
        mTimePicker.setCurrentMinute(Integer.valueOf(mInitialMinute));
        mTimePicker.setOnTimeChangedListener(this);
    }

    public TimePickerDialog(Context context, OnTimeSetListener ontimesetlistener, int i, int j, boolean flag)
    {
        int k;
        if (android.os.Build.VERSION.SDK_INT < 11)
        {
            k = R.style.Theme_Dialog_Alert;
        } else
        {
            k = 0;
        }
        this(context, k, ontimesetlistener, i, j, flag);
    }

    private void tryNotifyTimeSet()
    {
        if (mCallback != null)
        {
            mTimePicker.clearFocus();
            mCallback.onTimeSet(mTimePicker, mTimePicker.getCurrentHour().intValue(), mTimePicker.getCurrentMinute().intValue());
        }
    }

    public void onClick(DialogInterface dialoginterface, int i)
    {
        tryNotifyTimeSet();
    }

    public void onRestoreInstanceState(Bundle bundle)
    {
        super.onRestoreInstanceState(bundle);
        int i = bundle.getInt("hour");
        int j = bundle.getInt("minute");
        mTimePicker.setIs24HourView(Boolean.valueOf(bundle.getBoolean("is24hour")));
        mTimePicker.setCurrentHour(Integer.valueOf(i));
        mTimePicker.setCurrentMinute(Integer.valueOf(j));
    }

    public Bundle onSaveInstanceState()
    {
        Bundle bundle = super.onSaveInstanceState();
        bundle.putInt("hour", mTimePicker.getCurrentHour().intValue());
        bundle.putInt("minute", mTimePicker.getCurrentMinute().intValue());
        bundle.putBoolean("is24hour", mTimePicker.is24HourView());
        return bundle;
    }

    protected void onStop()
    {
        tryNotifyTimeSet();
        super.onStop();
    }

    public void onTimeChanged(TimePicker timepicker, int i, int j)
    {
    }

    public void updateTime(int i, int j)
    {
        mTimePicker.setCurrentHour(Integer.valueOf(i));
        mTimePicker.setCurrentMinute(Integer.valueOf(j));
    }
}
