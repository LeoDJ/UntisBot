// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package net.simonvt.timepicker;


// Referenced classes of package net.simonvt.timepicker:
//            R

public static final class 
{

    public static int amPm = 0x7f0800dd;
    public static int divider = 0x7f08004b;
    public static int hour = 0x7f0800db;
    public static int minute = 0x7f0800dc;
    public static int np__decrement = 0x7f080001;
    public static int np__increment = 0x7f080000;
    public static int np__numberpicker_input = 0x7f0800b2;
    public static int timePicker = 0x7f0800da;


    public ()
    {
    }
}
