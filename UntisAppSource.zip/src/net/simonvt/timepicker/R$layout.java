// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package net.simonvt.timepicker;


// Referenced classes of package net.simonvt.timepicker:
//            R

public static final class 
{

    public static int activity_samples = 0x7f030022;
    public static int number_picker_with_selector_wheel = 0x7f030038;
    public static int time_picker_dialog = 0x7f030046;
    public static int time_picker_holo = 0x7f030047;


    public ()
    {
    }
}
