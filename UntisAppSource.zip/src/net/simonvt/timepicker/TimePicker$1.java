// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package net.simonvt.timepicker;


// Referenced classes of package net.simonvt.timepicker:
//            TimePicker

static final class TimeChangedListener
    implements TimeChangedListener
{

    public void onTimeChanged(TimePicker timepicker, int i, int j)
    {
    }

    TimeChangedListener()
    {
    }
}
