// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package net.simonvt.timepicker;

import android.view.View;

// Referenced classes of package net.simonvt.timepicker:
//            TimePicker

class this._cls0
    implements android.view.istener
{

    final TimePicker this$0;

    public void onClick(View view)
    {
        view.requestFocus();
        view = TimePicker.this;
        boolean flag;
        if (!TimePicker.access$100(TimePicker.this))
        {
            flag = true;
        } else
        {
            flag = false;
        }
        TimePicker.access$102(view, flag);
        TimePicker.access$200(TimePicker.this);
        TimePicker.access$300(TimePicker.this);
    }

    ()
    {
        this$0 = TimePicker.this;
        super();
    }
}
