// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package net.simonvt.timepicker;

import android.os.Parcel;
import android.os.Parcelable;

// Referenced classes of package net.simonvt.timepicker:
//            TimePicker

private static class <init> extends android.view.avedState
{

    public static final android.os..SavedState.mMinute CREATOR = new android.os.Parcelable.Creator() {

        public volatile Object createFromParcel(Parcel parcel)
        {
            return createFromParcel(parcel);
        }

        public TimePicker.SavedState createFromParcel(Parcel parcel)
        {
            return new TimePicker.SavedState(parcel, null);
        }

        public volatile Object[] newArray(int i)
        {
            return newArray(i);
        }

        public TimePicker.SavedState[] newArray(int i)
        {
            return new TimePicker.SavedState[i];
        }

    };
    private final int mHour;
    private final int mMinute;

    public int getHour()
    {
        return mHour;
    }

    public int getMinute()
    {
        return mMinute;
    }

    public void writeToParcel(Parcel parcel, int i)
    {
        super.iteToParcel(parcel, i);
        parcel.writeInt(mHour);
        parcel.writeInt(mMinute);
    }


    private _cls1(Parcel parcel)
    {
        super(parcel);
        mHour = parcel.readInt();
        mMinute = parcel.readInt();
    }

    mMinute(Parcel parcel, mMinute mminute)
    {
        this(parcel);
    }

    private <init>(Parcelable parcelable, int i, int j)
    {
        super(parcelable);
        mHour = i;
        mMinute = j;
    }

    mMinute(Parcelable parcelable, int i, int j, mMinute mminute)
    {
        this(parcelable, i, j);
    }
}
