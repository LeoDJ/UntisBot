// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package net.simonvt.timepicker;

import android.os.Parcel;

// Referenced classes of package net.simonvt.timepicker:
//            TimePicker

static final class 
    implements android.os.avedState._cls1
{

    public volatile Object createFromParcel(Parcel parcel)
    {
        return createFromParcel(parcel);
    }

    public createFromParcel createFromParcel(Parcel parcel)
    {
        return new nit>(parcel, null);
    }

    public volatile Object[] newArray(int i)
    {
        return newArray(i);
    }

    public newArray[] newArray(int i)
    {
        return new newArray[i];
    }

    ()
    {
    }
}
