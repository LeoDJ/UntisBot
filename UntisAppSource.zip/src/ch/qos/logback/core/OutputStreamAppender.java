// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core;

import ch.qos.logback.core.encoder.Encoder;
import ch.qos.logback.core.encoder.LayoutWrappingEncoder;
import ch.qos.logback.core.spi.DeferredProcessingAware;
import ch.qos.logback.core.spi.LogbackLock;
import ch.qos.logback.core.status.ErrorStatus;
import java.io.IOException;
import java.io.OutputStream;

// Referenced classes of package ch.qos.logback.core:
//            UnsynchronizedAppenderBase, Layout

public class OutputStreamAppender extends UnsynchronizedAppenderBase
{

    protected Encoder encoder;
    protected LogbackLock lock;
    private OutputStream outputStream;

    public OutputStreamAppender()
    {
        lock = new LogbackLock();
    }

    protected void append(Object obj)
    {
        if (!isStarted())
        {
            return;
        } else
        {
            subAppend(obj);
            return;
        }
    }

    protected void closeOutputStream()
    {
        if (outputStream == null)
        {
            break MISSING_BLOCK_LABEL_23;
        }
        encoderClose();
        outputStream.close();
        outputStream = null;
        return;
        IOException ioexception;
        ioexception;
        addStatus(new ErrorStatus("Could not close output stream for OutputStreamAppender.", this, ioexception));
        return;
    }

    void encoderClose()
    {
        if (encoder == null || outputStream == null)
        {
            break MISSING_BLOCK_LABEL_23;
        }
        encoder.close();
        return;
        IOException ioexception;
        ioexception;
        started = false;
        addStatus(new ErrorStatus((new StringBuilder()).append("Failed to write footer for appender named [").append(name).append("].").toString(), this, ioexception));
        return;
    }

    void encoderInit()
    {
        if (encoder == null || outputStream == null)
        {
            break MISSING_BLOCK_LABEL_27;
        }
        encoder.init(outputStream);
        return;
        IOException ioexception;
        ioexception;
        started = false;
        addStatus(new ErrorStatus((new StringBuilder()).append("Failed to initialize encoder for appender named [").append(name).append("].").toString(), this, ioexception));
        return;
    }

    public Encoder getEncoder()
    {
        return encoder;
    }

    public OutputStream getOutputStream()
    {
        return outputStream;
    }

    public void setEncoder(Encoder encoder1)
    {
        encoder = encoder1;
    }

    public void setLayout(Layout layout)
    {
        addWarn("This appender no longer admits a layout as a sub-component, set an encoder instead.");
        addWarn("To ensure compatibility, wrapping your layout in LayoutWrappingEncoder.");
        addWarn("See also http://logback.qos.ch/codes.html#layoutInsteadOfEncoder for details");
        LayoutWrappingEncoder layoutwrappingencoder = new LayoutWrappingEncoder();
        layoutwrappingencoder.setLayout(layout);
        layoutwrappingencoder.setContext(context);
        encoder = layoutwrappingencoder;
    }

    public void setOutputStream(OutputStream outputstream)
    {
label0:
        {
            synchronized (lock)
            {
                closeOutputStream();
                outputStream = outputstream;
                if (encoder != null)
                {
                    break label0;
                }
                addWarn("Encoder has not been set. Cannot invoke its init method.");
            }
            return;
        }
        encoderInit();
        logbacklock;
        JVM INSTR monitorexit ;
        return;
        outputstream;
        logbacklock;
        JVM INSTR monitorexit ;
        throw outputstream;
    }

    public void start()
    {
        int i = 0;
        if (encoder == null)
        {
            addStatus(new ErrorStatus((new StringBuilder()).append("No encoder set for the appender named \"").append(name).append("\".").toString(), this));
            i = 1;
        }
        int j = i;
        if (outputStream == null)
        {
            addStatus(new ErrorStatus((new StringBuilder()).append("No output stream set for the appender named \"").append(name).append("\".").toString(), this));
            j = i + 1;
        }
        if (j == 0)
        {
            super.start();
        }
    }

    public void stop()
    {
        synchronized (lock)
        {
            closeOutputStream();
            super.stop();
        }
        return;
        exception;
        logbacklock;
        JVM INSTR monitorexit ;
        throw exception;
    }

    protected void subAppend(Object obj)
    {
        if (!isStarted())
        {
            return;
        }
        if (obj instanceof DeferredProcessingAware)
        {
            ((DeferredProcessingAware)obj).prepareForDeferredProcessing();
        }
        synchronized (lock)
        {
            writeOut(obj);
        }
        return;
        obj;
        logbacklock;
        JVM INSTR monitorexit ;
        try
        {
            throw obj;
        }
        // Misplaced declaration of an exception variable
        catch (Object obj)
        {
            started = false;
        }
        addStatus(new ErrorStatus("IO failure in appender", this, ((Throwable) (obj))));
        return;
    }

    protected void writeOut(Object obj)
        throws IOException
    {
        encoder.doEncode(obj);
    }
}
