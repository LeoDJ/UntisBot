// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.helpers;


public class Transform
{

    private static final String CDATA_EMBEDED_END = "]]>]]&gt;<![CDATA[";
    private static final String CDATA_END = "]]>";
    private static final int CDATA_END_LEN = "]]>".length();
    private static final String CDATA_PSEUDO_END = "]]&gt;";
    private static final String CDATA_START = "<![CDATA[";

    public Transform()
    {
    }

    public static void appendEscapingCDATA(StringBuilder stringbuilder, String s)
    {
        if (s != null) goto _L2; else goto _L1
_L1:
        return;
_L2:
        int i;
        int j = s.indexOf("]]>");
        if (j < 0)
        {
            stringbuilder.append(s);
            return;
        }
        i = 0;
label0:
        do
        {
label1:
            {
                if (j <= -1)
                {
                    break label1;
                }
                stringbuilder.append(s.substring(i, j));
                stringbuilder.append("]]>]]&gt;<![CDATA[");
                i = CDATA_END_LEN + j;
                if (i >= s.length())
                {
                    break label0;
                }
                j = s.indexOf("]]>", i);
            }
        } while (true);
        if (true) goto _L1; else goto _L3
_L3:
        stringbuilder.append(s.substring(i));
        return;
    }

    public static String escapeTags(String s)
    {
        if (s == null || s.length() == 0 || s.indexOf("<") == -1 && s.indexOf(">") == -1)
        {
            return s;
        } else
        {
            return escapeTags(new StringBuffer(s));
        }
    }

    public static String escapeTags(StringBuffer stringbuffer)
    {
        int i = 0;
        while (i < stringbuffer.length()) 
        {
            char c = stringbuffer.charAt(i);
            if (c == '<')
            {
                stringbuffer.replace(i, i + 1, "&lt;");
            } else
            if (c == '>')
            {
                stringbuffer.replace(i, i + 1, "&gt;");
            }
            i++;
        }
        return stringbuffer.toString();
    }

}
