// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.helpers;

import java.util.ArrayList;
import java.util.List;

public class CyclicBuffer
{

    Object ea[];
    int first;
    int last;
    int maxSize;
    int numElems;

    public CyclicBuffer(int i)
        throws IllegalArgumentException
    {
        if (i < 1)
        {
            throw new IllegalArgumentException((new StringBuilder()).append("The maxSize argument (").append(i).append(") is not a positive integer.").toString());
        } else
        {
            init(i);
            return;
        }
    }

    public CyclicBuffer(CyclicBuffer cyclicbuffer)
    {
        maxSize = cyclicbuffer.maxSize;
        ea = (Object[])new Object[maxSize];
        System.arraycopy(((Object) (cyclicbuffer.ea)), 0, ((Object) (ea)), 0, maxSize);
        last = cyclicbuffer.last;
        first = cyclicbuffer.first;
        numElems = cyclicbuffer.numElems;
    }

    private void init(int i)
    {
        maxSize = i;
        ea = (Object[])new Object[i];
        first = 0;
        last = 0;
        numElems = 0;
    }

    public void add(Object obj)
    {
        ea[last] = obj;
        int i = last + 1;
        last = i;
        if (i == maxSize)
        {
            last = 0;
        }
        if (numElems < maxSize)
        {
            numElems = numElems + 1;
        } else
        {
            int j = first + 1;
            first = j;
            if (j == maxSize)
            {
                first = 0;
                return;
            }
        }
    }

    public List asList()
    {
        ArrayList arraylist = new ArrayList();
        for (int i = 0; i < length(); i++)
        {
            arraylist.add(get(i));
        }

        return arraylist;
    }

    public void clear()
    {
        init(maxSize);
    }

    public Object get()
    {
        if (numElems > 0)
        {
            numElems = numElems - 1;
            Object obj = ea[first];
            ea[first] = null;
            int i = first + 1;
            first = i;
            if (i == maxSize)
            {
                first = 0;
            }
            return obj;
        } else
        {
            return null;
        }
    }

    public Object get(int i)
    {
        if (i < 0 || i >= numElems)
        {
            return null;
        } else
        {
            return ea[(first + i) % maxSize];
        }
    }

    public int getMaxSize()
    {
        return maxSize;
    }

    public int length()
    {
        return numElems;
    }

    public void resize(int i)
    {
        if (i < 0)
        {
            throw new IllegalArgumentException((new StringBuilder()).append("Negative array size [").append(i).append("] not allowed.").toString());
        }
        if (i == numElems)
        {
            return;
        }
        Object aobj[] = (Object[])new Object[i];
        int j;
        int k;
        if (i < numElems)
        {
            j = i;
        } else
        {
            j = numElems;
        }
        for (k = 0; k < j; k++)
        {
            aobj[k] = ea[first];
            ea[first] = null;
            int l = first + 1;
            first = l;
            if (l == numElems)
            {
                first = 0;
            }
        }

        ea = aobj;
        first = 0;
        numElems = j;
        maxSize = i;
        if (j == i)
        {
            last = 0;
            return;
        } else
        {
            last = j;
            return;
        }
    }
}
