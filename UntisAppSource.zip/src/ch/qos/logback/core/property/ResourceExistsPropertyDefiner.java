// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.property;

import ch.qos.logback.core.PropertyDefinerBase;
import ch.qos.logback.core.util.Loader;
import ch.qos.logback.core.util.OptionHelper;

public class ResourceExistsPropertyDefiner extends PropertyDefinerBase
{

    String resourceStr;

    public ResourceExistsPropertyDefiner()
    {
    }

    public String getPropertyValue()
    {
        if (OptionHelper.isEmpty(resourceStr))
        {
            addError("The \"resource\" property must be set.");
            return null;
        }
        boolean flag;
        if (Loader.getResourceBySelfClassLoader(resourceStr) != null)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        return booleanAsStr(flag);
    }

    public String getResource()
    {
        return resourceStr;
    }

    public void setResource(String s)
    {
        resourceStr = s;
    }
}
