// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.property;

import ch.qos.logback.core.PropertyDefinerBase;
import ch.qos.logback.core.util.OptionHelper;
import java.io.File;

public class FileExistsPropertyDefiner extends PropertyDefinerBase
{

    String path;

    public FileExistsPropertyDefiner()
    {
    }

    public String getPath()
    {
        return path;
    }

    public String getPropertyValue()
    {
        if (OptionHelper.isEmpty(path))
        {
            addError("The \"path\" property must be set.");
            return null;
        } else
        {
            return booleanAsStr((new File(path)).exists());
        }
    }

    public void setPath(String s)
    {
        path = s;
    }
}
