// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.util;


// Referenced classes of package ch.qos.logback.core.util:
//            DelayStrategy

public class FixedDelay
    implements DelayStrategy
{

    private long nextDelay;
    private final long subsequentDelay;

    public FixedDelay(int i)
    {
        this(i, i);
    }

    public FixedDelay(long l, long l1)
    {
        new String();
        nextDelay = l;
        subsequentDelay = l1;
    }

    public long nextDelay()
    {
        long l = nextDelay;
        nextDelay = subsequentDelay;
        return l;
    }
}
