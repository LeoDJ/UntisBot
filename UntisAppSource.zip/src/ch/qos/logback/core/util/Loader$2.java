// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.util;

import java.security.PrivilegedAction;

// Referenced classes of package ch.qos.logback.core.util:
//            Loader

static final class val.clazz
    implements PrivilegedAction
{

    final Class val$clazz;

    public ClassLoader run()
    {
        return val$clazz.getClassLoader();
    }

    public volatile Object run()
    {
        return run();
    }

    (Class class1)
    {
        val$clazz = class1;
        super();
    }
}
