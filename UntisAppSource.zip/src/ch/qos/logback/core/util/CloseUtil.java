// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.util;

import java.io.Closeable;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class CloseUtil
{

    public CloseUtil()
    {
    }

    public static void closeQuietly(Closeable closeable)
    {
        if (closeable == null)
        {
            return;
        }
        try
        {
            closeable.close();
            return;
        }
        // Misplaced declaration of an exception variable
        catch (Closeable closeable)
        {
            return;
        }
    }

    public static void closeQuietly(ServerSocket serversocket)
    {
        if (serversocket == null)
        {
            return;
        }
        try
        {
            serversocket.close();
            return;
        }
        // Misplaced declaration of an exception variable
        catch (ServerSocket serversocket)
        {
            return;
        }
    }

    public static void closeQuietly(Socket socket)
    {
        if (socket == null)
        {
            return;
        }
        try
        {
            socket.close();
            return;
        }
        // Misplaced declaration of an exception variable
        catch (Socket socket)
        {
            return;
        }
    }
}
