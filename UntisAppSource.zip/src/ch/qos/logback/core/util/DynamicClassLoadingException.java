// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.util;


public class DynamicClassLoadingException extends Exception
{

    private static final long serialVersionUID = 0x44dd8df54ee7da52L;

    public DynamicClassLoadingException(String s, Throwable throwable)
    {
        super(s, throwable);
    }
}
