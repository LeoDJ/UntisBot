// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.util;


public class ContentTypeUtil
{

    public ContentTypeUtil()
    {
    }

    public static String getSubType(String s)
    {
        int i;
        if (s != null)
        {
            if ((i = s.indexOf('/')) != -1 && i++ < s.length())
            {
                return s.substring(i);
            }
        }
        return null;
    }

    public static boolean isTextual(String s)
    {
        if (s == null)
        {
            return false;
        } else
        {
            return s.startsWith("text");
        }
    }
}
