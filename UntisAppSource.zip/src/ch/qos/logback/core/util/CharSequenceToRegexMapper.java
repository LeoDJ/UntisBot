// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.util;


// Referenced classes of package ch.qos.logback.core.util:
//            CharSequenceState

class CharSequenceToRegexMapper
{

    CharSequenceToRegexMapper()
    {
    }

    private String number(int i)
    {
        return (new StringBuilder()).append("\\d{").append(i).append("}").toString();
    }

    String toRegex(CharSequenceState charsequencestate)
    {
        int i = charsequencestate.occurrences;
        char c = charsequencestate.c;
        switch (charsequencestate.c)
        {
        default:
            if (i == 1)
            {
                return (new StringBuilder()).append("").append(c).toString();
            } else
            {
                return (new StringBuilder()).append(c).append("{").append(i).append("}").toString();
            }

        case 71: // 'G'
        case 122: // 'z'
            return ".*";

        case 77: // 'M'
            if (i >= 3)
            {
                return ".{3,12}";
            } else
            {
                return number(i);
            }

        case 68: // 'D'
        case 70: // 'F'
        case 72: // 'H'
        case 75: // 'K'
        case 83: // 'S'
        case 87: // 'W'
        case 100: // 'd'
        case 104: // 'h'
        case 107: // 'k'
        case 109: // 'm'
        case 115: // 's'
        case 119: // 'w'
        case 121: // 'y'
            return number(i);

        case 69: // 'E'
            return ".{2,12}";

        case 97: // 'a'
            return ".{2}";

        case 90: // 'Z'
            return "(\\+|-)\\d{4}";

        case 46: // '.'
            return "\\.";

        case 92: // '\\'
            throw new IllegalStateException("Forward slashes are not allowed");

        case 39: // '\''
            break;
        }
        if (i == 1)
        {
            return "";
        } else
        {
            throw new IllegalStateException("Too many single quotes");
        }
    }
}
