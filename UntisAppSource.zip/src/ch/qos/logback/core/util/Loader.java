// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.util;

import ch.qos.logback.core.Context;
import java.io.IOException;
import java.net.URL;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Set;

// Referenced classes of package ch.qos.logback.core.util:
//            OptionHelper

public class Loader
{

    private static boolean HAS_GET_CLASS_LOADER_PERMISSION = false;
    public static final String IGNORE_TCL_PROPERTY_NAME = "logback.ignoreTCL";
    static final String TSTR = "Caught Exception while in Loader.getResource. This may be innocuous.";
    private static boolean ignoreTCL = false;

    public Loader()
    {
    }

    public static ClassLoader getClassLoaderAsPrivileged(Class class1)
    {
        if (!HAS_GET_CLASS_LOADER_PERMISSION)
        {
            return null;
        } else
        {
            return (ClassLoader)AccessController.doPrivileged(new PrivilegedAction(class1) {

                final Class val$clazz;

                public ClassLoader run()
                {
                    return clazz.getClassLoader();
                }

                public volatile Object run()
                {
                    return run();
                }

            
            {
                clazz = class1;
                super();
            }
            });
        }
    }

    public static ClassLoader getClassLoaderOfClass(Class class1)
    {
        ClassLoader classloader = class1.getClassLoader();
        class1 = classloader;
        if (classloader == null)
        {
            class1 = ClassLoader.getSystemClassLoader();
        }
        return class1;
    }

    public static ClassLoader getClassLoaderOfObject(Object obj)
    {
        if (obj == null)
        {
            throw new NullPointerException("Argument cannot be null");
        } else
        {
            return getClassLoaderOfClass(obj.getClass());
        }
    }

    public static URL getResource(String s, ClassLoader classloader)
    {
        try
        {
            s = classloader.getResource(s);
        }
        // Misplaced declaration of an exception variable
        catch (String s)
        {
            return null;
        }
        return s;
    }

    public static URL getResourceBySelfClassLoader(String s)
    {
        return getResource(s, getClassLoaderOfClass(ch/qos/logback/core/util/Loader));
    }

    public static Set getResourceOccurrenceCount(String s, ClassLoader classloader)
        throws IOException
    {
        HashSet hashset = new HashSet();
        for (s = classloader.getResources(s); s.hasMoreElements(); hashset.add((URL)s.nextElement())) { }
        return hashset;
    }

    public static ClassLoader getTCL()
    {
        return Thread.currentThread().getContextClassLoader();
    }

    public static Class loadClass(String s)
        throws ClassNotFoundException
    {
        if (ignoreTCL)
        {
            return Class.forName(s);
        }
        Class class1;
        try
        {
            class1 = getTCL().loadClass(s);
        }
        catch (Throwable throwable)
        {
            return Class.forName(s);
        }
        return class1;
    }

    public static Class loadClass(String s, Context context)
        throws ClassNotFoundException
    {
        return getClassLoaderOfObject(context).loadClass(s);
    }

    static 
    {
        HAS_GET_CLASS_LOADER_PERMISSION = false;
        String s = OptionHelper.getSystemProperty("logback.ignoreTCL", null);
        if (s != null)
        {
            ignoreTCL = Boolean.valueOf(s).booleanValue();
        }
        HAS_GET_CLASS_LOADER_PERMISSION = ((Boolean)AccessController.doPrivileged(new PrivilegedAction() {

            public Boolean run()
            {
                try
                {
                    AccessController.checkPermission(new RuntimePermission("getClassLoader"));
                }
                catch (SecurityException securityexception)
                {
                    return Boolean.valueOf(false);
                }
                return Boolean.valueOf(true);
            }

            public volatile Object run()
            {
                return run();
            }

        })).booleanValue();
    }
}
