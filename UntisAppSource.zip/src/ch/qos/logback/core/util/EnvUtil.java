// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.util;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

// Referenced classes of package ch.qos.logback.core.util:
//            OptionHelper

public class EnvUtil
{

    public EnvUtil()
    {
    }

    public static boolean isAndroidOS()
    {
        String s = OptionHelper.getSystemProperty("os.name");
        String s1 = OptionHelper.getEnv("ANDROID_ROOT");
        String s2 = OptionHelper.getEnv("ANDROID_DATA");
        return s != null && s.contains("Linux") && s1 != null && s1.contains("/system") && s2 != null && s2.contains("/data");
    }

    public static boolean isJDK5()
    {
        return isJDK_N_OrHigher(5);
    }

    public static boolean isJDK6OrHigher()
    {
        return isJDK_N_OrHigher(6);
    }

    public static boolean isJDK7OrHigher()
    {
        return isJDK_N_OrHigher(7);
    }

    private static boolean isJDK_N_OrHigher(int i)
    {
        Object obj = new ArrayList();
        for (int j = 0; j < 5; j++)
        {
            ((List) (obj)).add((new StringBuilder()).append("1.").append(i + j).toString());
        }

        String s = System.getProperty("java.version");
        if (s == null)
        {
            return false;
        }
        for (obj = ((List) (obj)).iterator(); ((Iterator) (obj)).hasNext();)
        {
            if (s.startsWith((String)((Iterator) (obj)).next()))
            {
                return true;
            }
        }

        return false;
    }

    public static boolean isWindows()
    {
        return System.getProperty("os.name").startsWith("Windows");
    }
}
