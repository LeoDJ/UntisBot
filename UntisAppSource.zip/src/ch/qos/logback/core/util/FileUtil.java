// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.util;

import ch.qos.logback.core.Context;
import ch.qos.logback.core.rolling.RolloverFailure;
import ch.qos.logback.core.spi.ContextAwareBase;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;

// Referenced classes of package ch.qos.logback.core.util:
//            OptionHelper

public class FileUtil extends ContextAwareBase
{

    static final int BUF_SIZE = 32768;

    public FileUtil(Context context)
    {
        setContext(context);
    }

    public static boolean createMissingParentDirectories(File file)
    {
        File file1 = file.getParentFile();
        if (file1 == null)
        {
            throw new IllegalStateException((new StringBuilder()).append(file).append(" should not have a null parent").toString());
        }
        if (file1.exists())
        {
            throw new IllegalStateException((new StringBuilder()).append(file).append(" should not have existing parent directory").toString());
        } else
        {
            return file1.mkdirs();
        }
    }

    public static URL fileToURL(File file)
    {
        URL url;
        try
        {
            url = file.toURI().toURL();
        }
        catch (MalformedURLException malformedurlexception)
        {
            throw new RuntimeException((new StringBuilder()).append("Unexpected exception on file [").append(file).append("]").toString(), malformedurlexception);
        }
        return url;
    }

    public static boolean isParentDirectoryCreationRequired(File file)
    {
        file = file.getParentFile();
        return file != null && !file.exists();
    }

    public static String prefixRelativePath(String s, String s1)
    {
        String s2 = s1;
        if (s != null)
        {
            s2 = s1;
            if (!OptionHelper.isEmpty(s.trim()))
            {
                s2 = s1;
                if (!(new File(s1)).isAbsolute())
                {
                    s2 = (new StringBuilder()).append(s).append("/").append(s1).toString();
                }
            }
        }
        return s2;
    }

    public void copy(String s, String s1)
        throws RolloverFailure
    {
        Object obj;
        Object obj2 = null;
        BufferedOutputStream bufferedoutputstream = null;
        Object obj1 = null;
        byte abyte0[];
        IOException ioexception;
        BufferedOutputStream bufferedoutputstream1;
        int i;
        try
        {
            obj = new BufferedInputStream(new FileInputStream(s));
        }
        // Misplaced declaration of an exception variable
        catch (Object obj)
        {
            bufferedoutputstream = null;
            continue; /* Loop/switch isn't completed */
        }
        finally
        {
            s1 = null;
            obj = bufferedoutputstream;
            continue; /* Loop/switch isn't completed */
        }
        try
        {
_L4:
            bufferedoutputstream = new BufferedOutputStream(new FileOutputStream(s1));
        }
        catch (IOException ioexception1)
        {
            bufferedoutputstream = null;
            obj1 = obj;
            obj = ioexception1;
            continue; /* Loop/switch isn't completed */
        }
        finally
        {
            s1 = null;
            continue; /* Loop/switch isn't completed */
        }
        abyte0 = new byte[32768];
_L3:
        i = ((BufferedInputStream) (obj)).read(abyte0);
        if (i == -1) goto _L2; else goto _L1
_L1:
        bufferedoutputstream.write(abyte0, 0, i);
          goto _L3
        ioexception;
        obj1 = obj;
        obj = ioexception;
_L7:
        bufferedoutputstream1 = bufferedoutputstream;
        obj2 = obj1;
        s = (new StringBuilder()).append("Failed to copy [").append(s).append("] to [").append(s1).append("]").toString();
        bufferedoutputstream1 = bufferedoutputstream;
        obj2 = obj1;
        addError(s, ((Throwable) (obj)));
        bufferedoutputstream1 = bufferedoutputstream;
        obj2 = obj1;
        throw new RolloverFailure(s);
        s;
        obj = obj2;
        s1 = bufferedoutputstream1;
_L5:
        if (obj != null)
        {
            try
            {
                ((BufferedInputStream) (obj)).close();
            }
            // Misplaced declaration of an exception variable
            catch (Object obj) { }
        }
        if (s1 != null)
        {
            try
            {
                s1.close();
            }
            // Misplaced declaration of an exception variable
            catch (String s1) { }
        }
        throw s;
_L2:
        ((BufferedInputStream) (obj)).close();
        bufferedoutputstream1 = bufferedoutputstream;
        bufferedoutputstream.close();
        if (false)
        {
            try
            {
                throw new NullPointerException();
            }
            // Misplaced declaration of an exception variable
            catch (String s) { }
        }
        if (true)
        {
            break MISSING_BLOCK_LABEL_218;
        }
        throw new NullPointerException();
        return;
        s;
        return;
        s;
        s1 = bufferedoutputstream;
        if (true) goto _L5; else goto _L4
        obj;
        if (true) goto _L7; else goto _L6
_L6:
    }
}
