// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.util;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

// Referenced classes of package ch.qos.logback.core.util:
//            CharSequenceToRegexMapper, CharSequenceState

public class DatePatternToRegexUtil
{

    final String datePattern;
    final int datePatternLength;
    final CharSequenceToRegexMapper regexMapper = new CharSequenceToRegexMapper();

    public DatePatternToRegexUtil(String s)
    {
        datePattern = s;
        datePatternLength = s.length();
    }

    private List tokenize()
    {
        ArrayList arraylist = new ArrayList();
        CharSequenceState charsequencestate = null;
        int i = 0;
        while (i < datePatternLength) 
        {
            char c = datePattern.charAt(i);
            if (charsequencestate == null || charsequencestate.c != c)
            {
                charsequencestate = new CharSequenceState(c);
                arraylist.add(charsequencestate);
            } else
            {
                charsequencestate.incrementOccurrences();
            }
            i++;
        }
        return arraylist;
    }

    public String toRegex()
    {
        Object obj = tokenize();
        StringBuilder stringbuilder = new StringBuilder();
        CharSequenceState charsequencestate;
        for (obj = ((List) (obj)).iterator(); ((Iterator) (obj)).hasNext(); stringbuilder.append(regexMapper.toRegex(charsequencestate)))
        {
            charsequencestate = (CharSequenceState)((Iterator) (obj)).next();
        }

        return stringbuilder.toString();
    }
}
