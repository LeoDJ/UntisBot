// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class StringCollectionUtil
{

    public StringCollectionUtil()
    {
    }

    public static void removeMatching(Collection collection, Collection collection1)
    {
        ArrayList arraylist = new ArrayList(collection.size());
        for (collection1 = collection1.iterator(); collection1.hasNext();)
        {
            Pattern pattern = Pattern.compile((String)collection1.next());
            Iterator iterator = collection.iterator();
            while (iterator.hasNext()) 
            {
                String s = (String)iterator.next();
                if (pattern.matcher(s).matches())
                {
                    arraylist.add(s);
                }
            }
        }

        collection.removeAll(arraylist);
    }

    public static transient void removeMatching(Collection collection, String as[])
    {
        removeMatching(collection, ((Collection) (Arrays.asList(as))));
    }

    public static void retainMatching(Collection collection, Collection collection1)
    {
        if (collection1.isEmpty())
        {
            return;
        }
        ArrayList arraylist = new ArrayList(collection.size());
        for (collection1 = collection1.iterator(); collection1.hasNext();)
        {
            Pattern pattern = Pattern.compile((String)collection1.next());
            Iterator iterator = collection.iterator();
            while (iterator.hasNext()) 
            {
                String s = (String)iterator.next();
                if (pattern.matcher(s).matches())
                {
                    arraylist.add(s);
                }
            }
        }

        collection.retainAll(arraylist);
    }

    public static transient void retainMatching(Collection collection, String as[])
    {
        retainMatching(collection, ((Collection) (Arrays.asList(as))));
    }
}
