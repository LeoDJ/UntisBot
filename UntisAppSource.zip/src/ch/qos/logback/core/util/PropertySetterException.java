// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.util;


public class PropertySetterException extends Exception
{

    private static final long serialVersionUID = 0xd98b27739896d633L;

    public PropertySetterException(String s)
    {
        super(s);
    }

    public PropertySetterException(String s, Throwable throwable)
    {
        super(s, throwable);
    }

    public PropertySetterException(Throwable throwable)
    {
        super(throwable);
    }
}
