// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.util;

import java.io.FileNotFoundException;
import java.net.MalformedURLException;
import java.net.URL;

// Referenced classes of package ch.qos.logback.core.util:
//            Loader

public class LocationUtil
{

    public static final String CLASSPATH_SCHEME = "classpath:";
    public static final String SCHEME_PATTERN = "^\\p{Alpha}[\\p{Alnum}+.-]*:.*$";

    public LocationUtil()
    {
    }

    public static URL urlForResource(String s)
        throws MalformedURLException, FileNotFoundException
    {
        if (s == null)
        {
            throw new NullPointerException("location is required");
        }
        Object obj;
        if (!s.matches("^\\p{Alpha}[\\p{Alnum}+.-]*:.*$"))
        {
            obj = Loader.getResourceBySelfClassLoader(s);
        } else
        if (s.startsWith("classpath:"))
        {
            String s1 = s.substring("classpath:".length());
            obj = s1;
            if (s1.startsWith("/"))
            {
                obj = s1.substring(1);
            }
            if (((String) (obj)).length() == 0)
            {
                throw new MalformedURLException("path is required");
            }
            obj = Loader.getResourceBySelfClassLoader(((String) (obj)));
        } else
        {
            obj = new URL(s);
        }
        if (obj == null)
        {
            throw new FileNotFoundException(s);
        } else
        {
            return ((URL) (obj));
        }
    }
}
