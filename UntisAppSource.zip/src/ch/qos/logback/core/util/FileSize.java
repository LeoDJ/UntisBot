// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class FileSize
{

    private static final int DOUBLE_GROUP = 1;
    private static final Pattern FILE_SIZE_PATTERN = Pattern.compile("([0-9]+)\\s*(|kb|mb|gb)s?", 2);
    static final long GB_COEFFICIENT = 0x40000000L;
    static final long KB_COEFFICIENT = 1024L;
    private static final String LENGTH_PART = "([0-9]+)";
    static final long MB_COEFFICIENT = 0x100000L;
    private static final int UNIT_GROUP = 2;
    private static final String UNIT_PART = "(|kb|mb|gb)s?";
    final long size;

    FileSize(long l)
    {
        size = l;
    }

    public static FileSize valueOf(String s)
    {
        Object obj = FILE_SIZE_PATTERN.matcher(s);
        if (((Matcher) (obj)).matches())
        {
            s = ((Matcher) (obj)).group(1);
            obj = ((Matcher) (obj)).group(2);
            long l1 = Long.valueOf(s).longValue();
            long l;
            if (((String) (obj)).equalsIgnoreCase(""))
            {
                l = 1L;
            } else
            if (((String) (obj)).equalsIgnoreCase("kb"))
            {
                l = 1024L;
            } else
            if (((String) (obj)).equalsIgnoreCase("mb"))
            {
                l = 0x100000L;
            } else
            if (((String) (obj)).equalsIgnoreCase("gb"))
            {
                l = 0x40000000L;
            } else
            {
                throw new IllegalStateException((new StringBuilder()).append("Unexpected ").append(((String) (obj))).toString());
            }
            return new FileSize(l * l1);
        } else
        {
            throw new IllegalArgumentException((new StringBuilder()).append("String value [").append(s).append("] is not in the expected format.").toString());
        }
    }

    public long getSize()
    {
        return size;
    }

}
