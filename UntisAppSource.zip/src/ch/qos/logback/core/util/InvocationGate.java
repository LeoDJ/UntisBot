// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.util;


public class InvocationGate
{

    private static final int MAX_MASK = 65535;
    private static final long thresholdForMaskIncrease = 100L;
    private long invocationCounter;
    private volatile long lastMaskCheck;
    private volatile long mask;
    private final long thresholdForMaskDecrease = 800L;

    public InvocationGate()
    {
        mask = 15L;
        lastMaskCheck = System.currentTimeMillis();
        invocationCounter = 0L;
    }

    public boolean skipFurtherWork()
    {
        long l = invocationCounter;
        invocationCounter = 1L + l;
        return (l & mask) != mask;
    }

    public void updateMaskIfNecessary(long l)
    {
        long l1 = l - lastMaskCheck;
        lastMaskCheck = l;
        if (l1 < 100L && mask < 65535L)
        {
            mask = mask << 1 | 1L;
        } else
        if (l1 > 800L)
        {
            mask = mask >>> 2;
            return;
        }
    }
}
