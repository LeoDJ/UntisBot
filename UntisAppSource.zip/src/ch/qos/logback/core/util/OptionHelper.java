// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.util;

import ch.qos.logback.core.Context;
import ch.qos.logback.core.android.SystemPropertiesProxy;
import ch.qos.logback.core.spi.ContextAware;
import ch.qos.logback.core.spi.PropertyContainer;
import ch.qos.logback.core.spi.ScanException;
import ch.qos.logback.core.subst.NodeToStringTransformer;
import java.lang.reflect.Constructor;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;

// Referenced classes of package ch.qos.logback.core.util:
//            IncompatibleClassException, DynamicClassLoadingException, Loader

public class OptionHelper
{

    static final String DELIM_DEFAULT = ":-";
    static final int DELIM_DEFAULT_LEN = 2;
    static final String DELIM_START = "${";
    static final int DELIM_START_LEN = 2;
    static final char DELIM_STOP = 125;
    static final int DELIM_STOP_LEN = 1;
    static final String _IS_UNDEFINED = "_IS_UNDEFINED";

    public OptionHelper()
    {
    }

    public static String[] extractDefaultReplacement(String s)
    {
        String as[] = new String[2];
        if (s != null)
        {
            as[0] = s;
            int i = s.indexOf(":-");
            if (i != -1)
            {
                as[0] = s.substring(0, i);
                as[1] = s.substring(i + 2);
                return as;
            }
        }
        return as;
    }

    public static String getAndroidSystemProperty(String s)
    {
        try
        {
            s = SystemPropertiesProxy.getInstance().get(s, null);
        }
        // Misplaced declaration of an exception variable
        catch (String s)
        {
            return null;
        }
        return s;
    }

    public static String getEnv(String s)
    {
        try
        {
            s = System.getenv(s);
        }
        // Misplaced declaration of an exception variable
        catch (String s)
        {
            return null;
        }
        return s;
    }

    public static Properties getSystemProperties()
    {
        Properties properties;
        try
        {
            properties = System.getProperties();
        }
        catch (SecurityException securityexception)
        {
            return new Properties();
        }
        return properties;
    }

    public static String getSystemProperty(String s)
    {
        String s1;
        String s2;
        try
        {
            s2 = System.getProperty(s);
        }
        // Misplaced declaration of an exception variable
        catch (String s)
        {
            return null;
        }
        s1 = s2;
        if (s2 != null)
        {
            break MISSING_BLOCK_LABEL_16;
        }
        s1 = getAndroidSystemProperty(s);
        return s1;
    }

    public static String getSystemProperty(String s, String s1)
    {
        try
        {
            s = System.getProperty(s, s1);
        }
        // Misplaced declaration of an exception variable
        catch (String s)
        {
            return s1;
        }
        return s;
    }

    public static Object instantiateByClassName(String s, Class class1, Context context)
        throws IncompatibleClassException, DynamicClassLoadingException
    {
        return instantiateByClassName(s, class1, Loader.getClassLoaderOfObject(context));
    }

    public static Object instantiateByClassName(String s, Class class1, ClassLoader classloader)
        throws IncompatibleClassException, DynamicClassLoadingException
    {
        return instantiateByClassNameAndParameter(s, class1, classloader, null, null);
    }

    public static Object instantiateByClassNameAndParameter(String s, Class class1, Context context, Class class2, Object obj)
        throws IncompatibleClassException, DynamicClassLoadingException
    {
        return instantiateByClassNameAndParameter(s, class1, Loader.getClassLoaderOfObject(context), class2, obj);
    }

    public static Object instantiateByClassNameAndParameter(String s, Class class1, ClassLoader classloader, Class class2, Object obj)
        throws IncompatibleClassException, DynamicClassLoadingException
    {
        if (s == null)
        {
            throw new NullPointerException();
        }
        try
        {
            classloader = classloader.loadClass(s);
            if (!class1.isAssignableFrom(classloader))
            {
                throw new IncompatibleClassException(class1, classloader);
            }
        }
        // Misplaced declaration of an exception variable
        catch (String s)
        {
            throw s;
        }
        // Misplaced declaration of an exception variable
        catch (Class class1)
        {
            throw new DynamicClassLoadingException((new StringBuilder()).append("Failed to instantiate type ").append(s).toString(), class1);
        }
        if (class2 != null)
        {
            break MISSING_BLOCK_LABEL_48;
        }
        return classloader.newInstance();
        class1 = ((Class) (classloader.getConstructor(new Class[] {
            class2
        }).newInstance(new Object[] {
            obj
        })));
        return class1;
    }

    public static boolean isEmpty(String s)
    {
        return s == null || "".equals(s);
    }

    public static String propertyLookup(String s, PropertyContainer propertycontainer, PropertyContainer propertycontainer1)
    {
        String s1 = propertycontainer.getProperty(s);
        propertycontainer = s1;
        if (s1 == null)
        {
            propertycontainer = s1;
            if (propertycontainer1 != null)
            {
                propertycontainer = propertycontainer1.getProperty(s);
            }
        }
        propertycontainer1 = propertycontainer;
        if (propertycontainer == null)
        {
            propertycontainer1 = getSystemProperty(s, null);
        }
        propertycontainer = propertycontainer1;
        if (propertycontainer1 == null)
        {
            propertycontainer = getEnv(s);
        }
        return propertycontainer;
    }

    public static void setSystemProperties(ContextAware contextaware, Properties properties)
    {
        String s;
        for (Iterator iterator = properties.keySet().iterator(); iterator.hasNext(); setSystemProperty(contextaware, s, properties.getProperty(s)))
        {
            s = (String)iterator.next();
        }

    }

    public static void setSystemProperty(ContextAware contextaware, String s, String s1)
    {
        try
        {
            System.setProperty(s, s1);
            return;
        }
        // Misplaced declaration of an exception variable
        catch (String s1)
        {
            contextaware.addError((new StringBuilder()).append("Failed to set system property [").append(s).append("]").toString(), s1);
        }
    }

    public static String substVars(String s, PropertyContainer propertycontainer)
    {
        return substVars(s, propertycontainer, null);
    }

    public static String substVars(String s, PropertyContainer propertycontainer, PropertyContainer propertycontainer1)
    {
        try
        {
            propertycontainer = NodeToStringTransformer.substituteVariable(s, propertycontainer, propertycontainer1);
        }
        // Misplaced declaration of an exception variable
        catch (PropertyContainer propertycontainer)
        {
            throw new IllegalArgumentException((new StringBuilder()).append("Failed to parse input [").append(s).append("]").toString(), propertycontainer);
        }
        return propertycontainer;
    }

    public static boolean toBoolean(String s, boolean flag)
    {
        if (s != null)
        {
            s = s.trim();
            if ("true".equalsIgnoreCase(s))
            {
                return true;
            }
            if ("false".equalsIgnoreCase(s))
            {
                return false;
            }
        }
        return flag;
    }
}
