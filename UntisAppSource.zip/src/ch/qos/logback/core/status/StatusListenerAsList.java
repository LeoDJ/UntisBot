// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.status;

import java.util.ArrayList;
import java.util.List;

// Referenced classes of package ch.qos.logback.core.status:
//            StatusListener, Status

public class StatusListenerAsList
    implements StatusListener
{

    List statusList;

    public StatusListenerAsList()
    {
        statusList = new ArrayList();
    }

    public void addStatusEvent(Status status)
    {
        statusList.add(status);
    }

    public List getStatusList()
    {
        return statusList;
    }
}
