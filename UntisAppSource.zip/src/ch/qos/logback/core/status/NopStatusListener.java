// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.status;


// Referenced classes of package ch.qos.logback.core.status:
//            StatusListener, Status

public class NopStatusListener
    implements StatusListener
{

    public NopStatusListener()
    {
    }

    public void addStatusEvent(Status status)
    {
    }
}
