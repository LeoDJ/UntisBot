// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.status;

import ch.qos.logback.core.Context;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

// Referenced classes of package ch.qos.logback.core.status:
//            StatusManager, Status, ErrorStatus, InfoStatus, 
//            WarnStatus

public class StatusUtil
{

    StatusManager sm;

    public StatusUtil(Context context)
    {
        sm = context.getStatusManager();
    }

    public StatusUtil(StatusManager statusmanager)
    {
        sm = statusmanager;
    }

    public static boolean contextHasStatusListener(Context context)
    {
        context = context.getStatusManager();
        if (context != null)
        {
            if ((context = context.getCopyOfStatusListenerList()) != null && context.size() != 0)
            {
                return true;
            }
        }
        return false;
    }

    public static List filterStatusListByTimeThreshold(List list, long l)
    {
        ArrayList arraylist = new ArrayList();
        list = list.iterator();
        do
        {
            if (!list.hasNext())
            {
                break;
            }
            Status status = (Status)list.next();
            if (status.getDate().longValue() >= l)
            {
                arraylist.add(status);
            }
        } while (true);
        return arraylist;
    }

    public void addError(Object obj, String s, Throwable throwable)
    {
        addStatus(new ErrorStatus(s, obj, throwable));
    }

    public void addInfo(Object obj, String s)
    {
        addStatus(new InfoStatus(s, obj));
    }

    public void addStatus(Status status)
    {
        if (sm != null)
        {
            sm.add(status);
        }
    }

    public void addWarn(Object obj, String s)
    {
        addStatus(new WarnStatus(s, obj));
    }

    public boolean containsException(Class class1)
    {
        for (Iterator iterator = sm.getCopyOfStatusList().iterator(); iterator.hasNext();)
        {
            Throwable throwable = ((Status)iterator.next()).getThrowable();
            if (throwable != null && throwable.getClass().getName().equals(class1.getName()))
            {
                return true;
            }
        }

        return false;
    }

    public boolean containsMatch(int i, String s)
    {
        return containsMatch(0L, i, s);
    }

    public boolean containsMatch(long l, int i, String s)
    {
        Object obj = filterStatusListByTimeThreshold(sm.getCopyOfStatusList(), l);
        s = Pattern.compile(s);
        for (obj = ((List) (obj)).iterator(); ((Iterator) (obj)).hasNext();)
        {
            Status status = (Status)((Iterator) (obj)).next();
            if (i == status.getLevel() && s.matcher(status.getMessage()).lookingAt())
            {
                return true;
            }
        }

        return false;
    }

    public boolean containsMatch(String s)
    {
        s = Pattern.compile(s);
        for (Iterator iterator = sm.getCopyOfStatusList().iterator(); iterator.hasNext();)
        {
            if (s.matcher(((Status)iterator.next()).getMessage()).lookingAt())
            {
                return true;
            }
        }

        return false;
    }

    public int getHighestLevel(long l)
    {
        Iterator iterator = filterStatusListByTimeThreshold(sm.getCopyOfStatusList(), l).iterator();
        int i = 0;
        do
        {
            if (!iterator.hasNext())
            {
                break;
            }
            Status status = (Status)iterator.next();
            if (status.getLevel() > i)
            {
                i = status.getLevel();
            }
        } while (true);
        return i;
    }

    public boolean hasXMLParsingErrors(long l)
    {
        return containsMatch(l, 2, "XML_PARSING");
    }

    public boolean isErrorFree(long l)
    {
        return 2 > getHighestLevel(l);
    }

    public int matchCount(String s)
    {
        s = Pattern.compile(s);
        Iterator iterator = sm.getCopyOfStatusList().iterator();
        int i = 0;
        do
        {
            if (!iterator.hasNext())
            {
                break;
            }
            if (s.matcher(((Status)iterator.next()).getMessage()).lookingAt())
            {
                i++;
            }
        } while (true);
        return i;
    }

    public boolean noXMLParsingErrorsOccurred(long l)
    {
        return !hasXMLParsingErrors(l);
    }

    public long timeOfLastReset()
    {
        List list = sm.getCopyOfStatusList();
        if (list == null)
        {
            return -1L;
        }
        for (int i = list.size() - 1; i >= 0; i--)
        {
            Status status = (Status)list.get(i);
            if ("Will reset and reconfigure context ".equals(status.getMessage()))
            {
                return status.getDate().longValue();
            }
        }

        return -1L;
    }
}
