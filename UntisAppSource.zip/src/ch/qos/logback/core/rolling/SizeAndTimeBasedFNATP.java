// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.rolling;

import ch.qos.logback.core.rolling.helper.ArchiveRemover;
import ch.qos.logback.core.rolling.helper.CompressionMode;
import ch.qos.logback.core.rolling.helper.FileFilterUtil;
import ch.qos.logback.core.rolling.helper.FileNamePattern;
import ch.qos.logback.core.rolling.helper.SizeAndTimeBasedArchiveRemover;
import ch.qos.logback.core.util.FileSize;
import java.io.File;
import java.util.Date;

// Referenced classes of package ch.qos.logback.core.rolling:
//            TimeBasedFileNamingAndTriggeringPolicyBase, TimeBasedRollingPolicy

public class SizeAndTimeBasedFNATP extends TimeBasedFileNamingAndTriggeringPolicyBase
{

    int currentPeriodsCounter;
    private int invocationCounter;
    private int invocationMask;
    FileSize maxFileSize;
    String maxFileSizeAsString;

    public SizeAndTimeBasedFNATP()
    {
        currentPeriodsCounter = 0;
        invocationMask = 1;
    }

    private String getFileNameIncludingCompressionSuffix(Date date, int i)
    {
        return tbrp.fileNamePattern.convertMultipleArguments(new Object[] {
            dateInCurrentPeriod, Integer.valueOf(i)
        });
    }

    void computeCurrentPeriodsHighestCounterValue(String s)
    {
        File afile[] = FileFilterUtil.filesInFolderMatchingStemRegex((new File(getCurrentPeriodsFileNameWithoutCompressionSuffix())).getParentFile(), s);
        if (afile == null || afile.length == 0)
        {
            currentPeriodsCounter = 0;
        } else
        {
            currentPeriodsCounter = FileFilterUtil.findHighestCounter(afile, s);
            if (tbrp.getParentsRawFileProperty() != null || tbrp.compressionMode != CompressionMode.NONE)
            {
                currentPeriodsCounter = currentPeriodsCounter + 1;
                return;
            }
        }
    }

    protected ArchiveRemover createArchiveRemover()
    {
        return new SizeAndTimeBasedArchiveRemover(tbrp.fileNamePattern, rc);
    }

    public String getCurrentPeriodsFileNameWithoutCompressionSuffix()
    {
        return tbrp.fileNamePatternWCS.convertMultipleArguments(new Object[] {
            dateInCurrentPeriod, Integer.valueOf(currentPeriodsCounter)
        });
    }

    public String getMaxFileSize()
    {
        return maxFileSizeAsString;
    }

    public boolean isTriggeringEvent(File file, Object obj)
    {
        long l = getCurrentTime();
        if (l >= nextCheck)
        {
            file = dateInCurrentPeriod;
            elapsedPeriodsFileName = tbrp.fileNamePatternWCS.convertMultipleArguments(new Object[] {
                file, Integer.valueOf(currentPeriodsCounter)
            });
            currentPeriodsCounter = 0;
            setDateInCurrentPeriod(l);
            computeNextCheck();
            return true;
        }
        int i = invocationCounter + 1;
        invocationCounter = i;
        if ((i & invocationMask) != invocationMask)
        {
            return false;
        }
        if (invocationMask < 15)
        {
            invocationMask = (invocationMask << 1) + 1;
        }
        if (file.length() >= maxFileSize.getSize())
        {
            elapsedPeriodsFileName = tbrp.fileNamePatternWCS.convertMultipleArguments(new Object[] {
                dateInCurrentPeriod, Integer.valueOf(currentPeriodsCounter)
            });
            currentPeriodsCounter = currentPeriodsCounter + 1;
            return true;
        } else
        {
            return false;
        }
    }

    public void setMaxFileSize(String s)
    {
        maxFileSizeAsString = s;
        maxFileSize = FileSize.valueOf(s);
    }

    public void start()
    {
        super.start();
        archiveRemover = createArchiveRemover();
        archiveRemover.setContext(context);
        computeCurrentPeriodsHighestCounterValue(FileFilterUtil.afterLastSlash(tbrp.fileNamePattern.toRegexForFixedDate(dateInCurrentPeriod)));
        started = true;
    }
}
