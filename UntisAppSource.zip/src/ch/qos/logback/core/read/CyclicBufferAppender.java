// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.read;

import ch.qos.logback.core.AppenderBase;
import ch.qos.logback.core.helpers.CyclicBuffer;

public class CyclicBufferAppender extends AppenderBase
{

    CyclicBuffer cb;
    int maxSize;

    public CyclicBufferAppender()
    {
        maxSize = 512;
    }

    protected void append(Object obj)
    {
        if (!isStarted())
        {
            return;
        } else
        {
            cb.add(obj);
            return;
        }
    }

    public Object get(int i)
    {
        if (isStarted())
        {
            return cb.get(i);
        } else
        {
            return null;
        }
    }

    public int getLength()
    {
        if (isStarted())
        {
            return cb.length();
        } else
        {
            return 0;
        }
    }

    public int getMaxSize()
    {
        return maxSize;
    }

    public void reset()
    {
        cb.clear();
    }

    public void setMaxSize(int i)
    {
        maxSize = i;
    }

    public void start()
    {
        cb = new CyclicBuffer(maxSize);
        super.start();
    }

    public void stop()
    {
        cb = null;
        super.stop();
    }
}
