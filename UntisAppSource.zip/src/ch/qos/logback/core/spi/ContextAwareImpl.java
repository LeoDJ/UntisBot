// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.spi;

import ch.qos.logback.core.Context;
import ch.qos.logback.core.status.ErrorStatus;
import ch.qos.logback.core.status.InfoStatus;
import ch.qos.logback.core.status.Status;
import ch.qos.logback.core.status.StatusManager;
import ch.qos.logback.core.status.WarnStatus;
import java.io.PrintStream;

// Referenced classes of package ch.qos.logback.core.spi:
//            ContextAware

public class ContextAwareImpl
    implements ContextAware
{

    protected Context context;
    private int noContextWarning;
    final Object origin;

    public ContextAwareImpl(Context context1, Object obj)
    {
        noContextWarning = 0;
        context = context1;
        origin = obj;
    }

    public void addError(String s)
    {
        addStatus(new ErrorStatus(s, getOrigin()));
    }

    public void addError(String s, Throwable throwable)
    {
        addStatus(new ErrorStatus(s, getOrigin(), throwable));
    }

    public void addInfo(String s)
    {
        addStatus(new InfoStatus(s, getOrigin()));
    }

    public void addInfo(String s, Throwable throwable)
    {
        addStatus(new InfoStatus(s, getOrigin(), throwable));
    }

    public void addStatus(Status status)
    {
        if (context == null)
        {
            int i = noContextWarning;
            noContextWarning = i + 1;
            if (i == 0)
            {
                System.out.println((new StringBuilder()).append("LOGBACK: No context given for ").append(this).toString());
            }
        } else
        {
            StatusManager statusmanager = context.getStatusManager();
            if (statusmanager != null)
            {
                statusmanager.add(status);
                return;
            }
        }
    }

    public void addWarn(String s)
    {
        addStatus(new WarnStatus(s, getOrigin()));
    }

    public void addWarn(String s, Throwable throwable)
    {
        addStatus(new WarnStatus(s, getOrigin(), throwable));
    }

    public Context getContext()
    {
        return context;
    }

    protected Object getOrigin()
    {
        return origin;
    }

    public StatusManager getStatusManager()
    {
        if (context == null)
        {
            return null;
        } else
        {
            return context.getStatusManager();
        }
    }

    public void setContext(Context context1)
    {
        if (context == null)
        {
            context = context1;
        } else
        if (context != context1)
        {
            throw new IllegalStateException("Context has been already set");
        }
    }
}
