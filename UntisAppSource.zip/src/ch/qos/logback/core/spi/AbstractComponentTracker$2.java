// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.spi;


// Referenced classes of package ch.qos.logback.core.spi:
//            AbstractComponentTracker

class this._cls0
    implements movalPredicator
{

    final AbstractComponentTracker this$0;

    public boolean isSlatedForRemoval(try try1, long l)
    {
        return AbstractComponentTracker.access$000(AbstractComponentTracker.this, try1, l);
    }

    try()
    {
        this$0 = AbstractComponentTracker.this;
        super();
    }
}
