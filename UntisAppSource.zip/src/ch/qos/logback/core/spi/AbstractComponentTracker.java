// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.spi;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;

// Referenced classes of package ch.qos.logback.core.spi:
//            ComponentTracker

public abstract class AbstractComponentTracker
    implements ComponentTracker
{
    private static class Entry
    {

        Object component;
        String key;
        long timestamp;

        public boolean equals(Object obj)
        {
            if (this != obj) goto _L2; else goto _L1
_L1:
            return true;
_L2:
            if (obj == null)
            {
                return false;
            }
            if (getClass() != obj.getClass())
            {
                return false;
            }
            obj = (Entry)obj;
            if (key == null)
            {
                if (((Entry) (obj)).key != null)
                {
                    return false;
                }
            } else
            if (!key.equals(((Entry) (obj)).key))
            {
                return false;
            }
            if (component != null)
            {
                continue; /* Loop/switch isn't completed */
            }
            if (((Entry) (obj)).component == null) goto _L1; else goto _L3
_L3:
            return false;
            if (component.equals(((Entry) (obj)).component)) goto _L1; else goto _L4
_L4:
            return false;
        }

        public int hashCode()
        {
            return key.hashCode();
        }

        public void setTimestamp(long l)
        {
            timestamp = l;
        }

        public String toString()
        {
            return (new StringBuilder()).append("(").append(key).append(", ").append(component).append(")").toString();
        }

        Entry(String s, Object obj, long l)
        {
            key = s;
            component = obj;
            timestamp = l;
        }
    }

    private static interface RemovalPredicator
    {

        public abstract boolean isSlatedForRemoval(Entry entry, long l);
    }


    private static final boolean ACCESS_ORDERED = true;
    public static final long LINGERING_TIMEOUT = 10000L;
    public static final long WAIT_BETWEEN_SUCCESSIVE_REMOVAL_ITERATIONS = 1000L;
    private RemovalPredicator byExcedent;
    private RemovalPredicator byLingering;
    private RemovalPredicator byTimeout;
    long lastCheck;
    LinkedHashMap lingerersMap;
    LinkedHashMap liveMap;
    protected int maxComponents;
    protected long timeout;

    public AbstractComponentTracker()
    {
        maxComponents = 0x7fffffff;
        timeout = 0x1b7740L;
        liveMap = new LinkedHashMap(32, 0.75F, true);
        lingerersMap = new LinkedHashMap(16, 0.75F, true);
        lastCheck = 0L;
        byExcedent = new RemovalPredicator() {

            final AbstractComponentTracker this$0;

            public boolean isSlatedForRemoval(Entry entry, long l)
            {
                return liveMap.size() > maxComponents;
            }

            
            {
                this$0 = AbstractComponentTracker.this;
                super();
            }
        };
        byTimeout = new RemovalPredicator() {

            final AbstractComponentTracker this$0;

            public boolean isSlatedForRemoval(Entry entry, long l)
            {
                return isEntryStale(entry, l);
            }

            
            {
                this$0 = AbstractComponentTracker.this;
                super();
            }
        };
        byLingering = new RemovalPredicator() {

            final AbstractComponentTracker this$0;

            public boolean isSlatedForRemoval(Entry entry, long l)
            {
                return isEntryDoneLingering(entry, l);
            }

            
            {
                this$0 = AbstractComponentTracker.this;
                super();
            }
        };
    }

    private void genericStaleComponentRemover(LinkedHashMap linkedhashmap, long l, RemovalPredicator removalpredicator)
    {
        linkedhashmap = linkedhashmap.entrySet().iterator();
        do
        {
            if (!linkedhashmap.hasNext())
            {
                break;
            }
            Entry entry = (Entry)((java.util.Map.Entry)linkedhashmap.next()).getValue();
            if (!removalpredicator.isSlatedForRemoval(entry, l))
            {
                break;
            }
            linkedhashmap.remove();
            processPriorToRemoval(entry.component);
        } while (true);
    }

    private Entry getFromEitherMap(String s)
    {
        Entry entry = (Entry)liveMap.get(s);
        if (entry != null)
        {
            return entry;
        } else
        {
            return (Entry)lingerersMap.get(s);
        }
    }

    private boolean isEntryDoneLingering(Entry entry, long l)
    {
        return entry.timestamp + 10000L < l;
    }

    private boolean isEntryStale(Entry entry, long l)
    {
        while (isComponentStale(entry.component) || entry.timestamp + timeout < l) 
        {
            return true;
        }
        return false;
    }

    private boolean isTooSoonForRemovalIteration(long l)
    {
        if (lastCheck + 1000L > l)
        {
            return true;
        } else
        {
            lastCheck = l;
            return false;
        }
    }

    private void removeExcedentComponents()
    {
        genericStaleComponentRemover(liveMap, 0L, byExcedent);
    }

    private void removeStaleComponentsFromLingerersMap(long l)
    {
        genericStaleComponentRemover(lingerersMap, l, byLingering);
    }

    private void removeStaleComponentsFromMainMap(long l)
    {
        genericStaleComponentRemover(liveMap, l, byTimeout);
    }

    public Collection allComponents()
    {
        ArrayList arraylist = new ArrayList();
        for (Iterator iterator = liveMap.values().iterator(); iterator.hasNext(); arraylist.add(((Entry)iterator.next()).component)) { }
        for (Iterator iterator1 = lingerersMap.values().iterator(); iterator1.hasNext(); arraylist.add(((Entry)iterator1.next()).component)) { }
        return arraylist;
    }

    public Set allKeys()
    {
        HashSet hashset = new HashSet(liveMap.keySet());
        hashset.addAll(lingerersMap.keySet());
        return hashset;
    }

    protected abstract Object buildComponent(String s);

    public void endOfLife(String s)
    {
        Entry entry = (Entry)liveMap.remove(s);
        if (entry == null)
        {
            return;
        } else
        {
            lingerersMap.put(s, entry);
            return;
        }
    }

    public Object find(String s)
    {
        this;
        JVM INSTR monitorenter ;
        s = getFromEitherMap(s);
        if (s != null) goto _L2; else goto _L1
_L1:
        s = null;
_L4:
        this;
        JVM INSTR monitorexit ;
        return s;
_L2:
        s = ((String) (((Entry) (s)).component));
        if (true) goto _L4; else goto _L3
_L3:
        s;
        throw s;
    }

    public int getComponentCount()
    {
        return liveMap.size() + lingerersMap.size();
    }

    public int getMaxComponents()
    {
        return maxComponents;
    }

    public Object getOrCreate(String s, long l)
    {
        this;
        JVM INSTR monitorenter ;
        Entry entry = getFromEitherMap(s);
        if (entry != null) goto _L2; else goto _L1
_L1:
        entry = new Entry(s, buildComponent(s), l);
        liveMap.put(s, entry);
        s = entry;
_L4:
        s = ((String) (((Entry) (s)).component));
        this;
        JVM INSTR monitorexit ;
        return s;
_L2:
        entry.setTimestamp(l);
        s = entry;
        if (true) goto _L4; else goto _L3
_L3:
        s;
        throw s;
    }

    public long getTimeout()
    {
        return timeout;
    }

    protected abstract boolean isComponentStale(Object obj);

    protected abstract void processPriorToRemoval(Object obj);

    public void removeStaleComponents(long l)
    {
        this;
        JVM INSTR monitorenter ;
        boolean flag = isTooSoonForRemovalIteration(l);
        if (!flag) goto _L2; else goto _L1
_L1:
        this;
        JVM INSTR monitorexit ;
        return;
_L2:
        removeExcedentComponents();
        removeStaleComponentsFromMainMap(l);
        removeStaleComponentsFromLingerersMap(l);
        if (true) goto _L1; else goto _L3
_L3:
        Exception exception;
        exception;
        throw exception;
    }

    public void setMaxComponents(int i)
    {
        maxComponents = i;
    }

    public void setTimeout(long l)
    {
        timeout = l;
    }


}
