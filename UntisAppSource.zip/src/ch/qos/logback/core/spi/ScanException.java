// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.spi;


public class ScanException extends Exception
{

    private static final long serialVersionUID = 0xd488c1d661c8aff6L;
    Throwable cause;

    public ScanException(String s)
    {
        super(s);
    }

    public ScanException(String s, Throwable throwable)
    {
        super(s);
        cause = throwable;
    }

    public Throwable getCause()
    {
        return cause;
    }
}
