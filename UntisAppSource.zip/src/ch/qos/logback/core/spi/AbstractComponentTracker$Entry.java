// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.spi;


// Referenced classes of package ch.qos.logback.core.spi:
//            AbstractComponentTracker

private static class timestamp
{

    Object component;
    String key;
    long timestamp;

    public boolean equals(Object obj)
    {
        if (this != obj) goto _L2; else goto _L1
_L1:
        return true;
_L2:
        if (obj == null)
        {
            return false;
        }
        if (getClass() != obj.getClass())
        {
            return false;
        }
        obj = (timestamp)obj;
        if (key == null)
        {
            if (((key) (obj)).key != null)
            {
                return false;
            }
        } else
        if (!key.equals(((key) (obj)).key))
        {
            return false;
        }
        if (component != null)
        {
            continue; /* Loop/switch isn't completed */
        }
        if (((component) (obj)).component == null) goto _L1; else goto _L3
_L3:
        return false;
        if (component.equals(((component) (obj)).component)) goto _L1; else goto _L4
_L4:
        return false;
    }

    public int hashCode()
    {
        return key.hashCode();
    }

    public void setTimestamp(long l)
    {
        timestamp = l;
    }

    public String toString()
    {
        return (new StringBuilder()).append("(").append(key).append(", ").append(component).append(")").toString();
    }

    (String s, Object obj, long l)
    {
        key = s;
        component = obj;
        timestamp = l;
    }
}
