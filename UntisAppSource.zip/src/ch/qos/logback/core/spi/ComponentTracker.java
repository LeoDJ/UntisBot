// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.spi;

import java.util.Collection;
import java.util.Set;

public interface ComponentTracker
{

    public static final int DEFAULT_MAX_COMPONENTS = 0x7fffffff;
    public static final int DEFAULT_TIMEOUT = 0x1b7740;

    public abstract Collection allComponents();

    public abstract Set allKeys();

    public abstract void endOfLife(String s);

    public abstract Object find(String s);

    public abstract int getComponentCount();

    public abstract Object getOrCreate(String s, long l);

    public abstract void removeStaleComponents(long l);
}
