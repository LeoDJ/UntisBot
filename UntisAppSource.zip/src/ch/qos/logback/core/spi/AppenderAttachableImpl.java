// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.spi;

import ch.qos.logback.core.Appender;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;

// Referenced classes of package ch.qos.logback.core.spi:
//            AppenderAttachable

public class AppenderAttachableImpl
    implements AppenderAttachable
{

    static final long START = System.currentTimeMillis();
    private final CopyOnWriteArrayList appenderList = new CopyOnWriteArrayList();

    public AppenderAttachableImpl()
    {
    }

    public void addAppender(Appender appender)
    {
        if (appender == null)
        {
            throw new IllegalArgumentException("Null argument disallowed");
        } else
        {
            appenderList.addIfAbsent(appender);
            return;
        }
    }

    public int appendLoopOnAppenders(Object obj)
    {
        Iterator iterator = appenderList.iterator();
        int i;
        for (i = 0; iterator.hasNext(); i++)
        {
            ((Appender)iterator.next()).doAppend(obj);
        }

        return i;
    }

    public void detachAndStopAllAppenders()
    {
        for (Iterator iterator = appenderList.iterator(); iterator.hasNext(); ((Appender)iterator.next()).stop()) { }
        appenderList.clear();
    }

    public boolean detachAppender(Appender appender)
    {
        if (appender == null)
        {
            return false;
        } else
        {
            return appenderList.remove(appender);
        }
    }

    public boolean detachAppender(String s)
    {
        Iterator iterator;
        if (s == null)
        {
            return false;
        }
        iterator = appenderList.iterator();
_L4:
        if (!iterator.hasNext()) goto _L2; else goto _L1
_L1:
        Appender appender = (Appender)iterator.next();
        if (!s.equals(appender.getName())) goto _L4; else goto _L3
_L3:
        boolean flag = appenderList.remove(appender);
_L6:
        return flag;
_L2:
        flag = false;
        if (true) goto _L6; else goto _L5
_L5:
    }

    public Appender getAppender(String s)
    {
        if (s == null)
        {
            return null;
        }
        for (Iterator iterator = appenderList.iterator(); iterator.hasNext();)
        {
            Appender appender = (Appender)iterator.next();
            if (s.equals(appender.getName()))
            {
                return appender;
            }
        }

        return null;
    }

    public boolean isAttached(Appender appender)
    {
        if (appender == null)
        {
            return false;
        }
        for (Iterator iterator = appenderList.iterator(); iterator.hasNext();)
        {
            if ((Appender)iterator.next() == appender)
            {
                return true;
            }
        }

        return false;
    }

    public Iterator iteratorForAppenders()
    {
        return appenderList.iterator();
    }

}
