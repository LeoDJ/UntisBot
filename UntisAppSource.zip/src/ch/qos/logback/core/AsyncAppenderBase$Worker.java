// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core;

import ch.qos.logback.core.spi.AppenderAttachableImpl;
import java.util.Iterator;
import java.util.concurrent.BlockingQueue;

// Referenced classes of package ch.qos.logback.core:
//            AsyncAppenderBase

class this._cls0 extends Thread
{

    final AsyncAppenderBase this$0;

    public void run()
    {
        Object obj = AsyncAppenderBase.this;
        AppenderAttachableImpl appenderattachableimpl = ((AsyncAppenderBase) (obj)).aai;
        do
        {
            if (!((AsyncAppenderBase) (obj)).isStarted())
            {
                break;
            }
            try
            {
                appenderattachableimpl.appendLoopOnAppenders(((AsyncAppenderBase) (obj)).blockingQueue.take());
                continue;
            }
            catch (InterruptedException interruptedexception) { }
            break;
        } while (true);
        addInfo("Worker thread will flush remaining events before exiting.");
        for (obj = ((AsyncAppenderBase) (obj)).blockingQueue.iterator(); ((Iterator) (obj)).hasNext(); appenderattachableimpl.appendLoopOnAppenders(((Iterator) (obj)).next())) { }
        appenderattachableimpl.detachAndStopAllAppenders();
    }

    l()
    {
        this$0 = AsyncAppenderBase.this;
        super();
    }
}
