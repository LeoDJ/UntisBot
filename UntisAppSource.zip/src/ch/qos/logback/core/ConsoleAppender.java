// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core;

import ch.qos.logback.core.joran.spi.ConsoleTarget;
import ch.qos.logback.core.status.Status;
import ch.qos.logback.core.status.WarnStatus;
import java.util.Arrays;

// Referenced classes of package ch.qos.logback.core:
//            OutputStreamAppender

public class ConsoleAppender extends OutputStreamAppender
{

    protected ConsoleTarget target;

    public ConsoleAppender()
    {
        target = ConsoleTarget.SystemOut;
    }

    private void targetWarn(String s)
    {
        s = new WarnStatus((new StringBuilder()).append("[").append(s).append("] should be one of ").append(Arrays.toString(ConsoleTarget.values())).toString(), this);
        s.add(new WarnStatus("Using previously set target, System.out by default.", this));
        addStatus(s);
    }

    public String getTarget()
    {
        return target.getName();
    }

    public void setTarget(String s)
    {
        ConsoleTarget consoletarget = ConsoleTarget.findByName(s.trim());
        if (consoletarget == null)
        {
            targetWarn(s);
            return;
        } else
        {
            target = consoletarget;
            return;
        }
    }

    public void start()
    {
        setOutputStream(target.getStream());
        super.start();
    }
}
