// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core;


public class LogbackException extends RuntimeException
{

    private static final long serialVersionUID = 0xf4e5fbf10299c40eL;

    public LogbackException(String s)
    {
        super(s);
    }

    public LogbackException(String s, Throwable throwable)
    {
        super(s, throwable);
    }
}
