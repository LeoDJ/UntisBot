// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.net.server;

import ch.qos.logback.core.net.ssl.ConfigurableSSLServerSocketFactory;
import ch.qos.logback.core.net.ssl.SSLComponent;
import ch.qos.logback.core.net.ssl.SSLConfiguration;
import ch.qos.logback.core.net.ssl.SSLParametersConfiguration;
import javax.net.ServerSocketFactory;
import javax.net.ssl.SSLContext;

// Referenced classes of package ch.qos.logback.core.net.server:
//            AbstractServerSocketAppender

public abstract class SSLServerSocketAppenderBase extends AbstractServerSocketAppender
    implements SSLComponent
{

    private ServerSocketFactory socketFactory;
    private SSLConfiguration ssl;

    public SSLServerSocketAppenderBase()
    {
    }

    protected ServerSocketFactory getServerSocketFactory()
    {
        return socketFactory;
    }

    public SSLConfiguration getSsl()
    {
        if (ssl == null)
        {
            ssl = new SSLConfiguration();
        }
        return ssl;
    }

    public void setSsl(SSLConfiguration sslconfiguration)
    {
        ssl = sslconfiguration;
    }

    public void start()
    {
        try
        {
            SSLContext sslcontext = getSsl().createContext(this);
            SSLParametersConfiguration sslparametersconfiguration = getSsl().getParameters();
            sslparametersconfiguration.setContext(getContext());
            socketFactory = new ConfigurableSSLServerSocketFactory(sslparametersconfiguration, sslcontext.getServerSocketFactory());
            super.start();
            return;
        }
        catch (Exception exception)
        {
            addError(exception.getMessage(), exception);
        }
    }
}
