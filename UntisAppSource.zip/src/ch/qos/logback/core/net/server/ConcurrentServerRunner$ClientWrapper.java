// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.net.server;


// Referenced classes of package ch.qos.logback.core.net.server:
//            Client, ConcurrentServerRunner

private class delegate
    implements Client
{

    private final Client _flddelegate;
    final ConcurrentServerRunner this$0;

    public void close()
    {
        _flddelegate.close();
    }

    public void run()
    {
        ConcurrentServerRunner.access$000(ConcurrentServerRunner.this, _flddelegate);
        _flddelegate.run();
        ConcurrentServerRunner.access$100(ConcurrentServerRunner.this, _flddelegate);
        return;
        Exception exception;
        exception;
        ConcurrentServerRunner.access$100(ConcurrentServerRunner.this, _flddelegate);
        throw exception;
    }

    public I(Client client)
    {
        this$0 = ConcurrentServerRunner.this;
        super();
        _flddelegate = client;
    }
}
