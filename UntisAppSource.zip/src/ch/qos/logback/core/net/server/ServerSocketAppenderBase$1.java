// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.net.server;

import java.io.Serializable;

// Referenced classes of package ch.qos.logback.core.net.server:
//            ClientVisitor, ServerSocketAppenderBase, RemoteReceiverClient, Client

class val.serEvent
    implements ClientVisitor
{

    final ServerSocketAppenderBase this$0;
    final Serializable val$serEvent;

    public volatile void visit(Client client)
    {
        visit((RemoteReceiverClient)client);
    }

    public void visit(RemoteReceiverClient remotereceiverclient)
    {
        remotereceiverclient.offer(val$serEvent);
    }

    ()
    {
        this$0 = final_serversocketappenderbase;
        val$serEvent = Serializable.this;
        super();
    }
}
