// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.net.server;

import ch.qos.logback.core.spi.ContextAwareBase;
import ch.qos.logback.core.util.CloseUtil;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.net.Socket;
import java.net.SocketException;
import java.util.concurrent.BlockingQueue;

// Referenced classes of package ch.qos.logback.core.net.server:
//            RemoteReceiverClient

class RemoteReceiverStreamClient extends ContextAwareBase
    implements RemoteReceiverClient
{

    private final String clientId;
    private final OutputStream outputStream;
    private BlockingQueue queue;
    private final Socket socket;

    RemoteReceiverStreamClient(String s, OutputStream outputstream)
    {
        clientId = (new StringBuilder()).append("client ").append(s).append(": ").toString();
        socket = null;
        outputStream = outputstream;
    }

    public RemoteReceiverStreamClient(String s, Socket socket1)
    {
        clientId = (new StringBuilder()).append("client ").append(s).append(": ").toString();
        socket = socket1;
        outputStream = null;
    }

    private ObjectOutputStream createObjectOutputStream()
        throws IOException
    {
        if (socket == null)
        {
            return new ObjectOutputStream(outputStream);
        } else
        {
            return new ObjectOutputStream(socket.getOutputStream());
        }
    }

    public void close()
    {
        if (socket == null)
        {
            return;
        } else
        {
            CloseUtil.closeQuietly(socket);
            return;
        }
    }

    public boolean offer(Serializable serializable)
    {
        if (queue == null)
        {
            throw new IllegalStateException("client has no event queue");
        } else
        {
            return queue.offer(serializable);
        }
    }

    public void run()
    {
        addInfo((new StringBuilder()).append(clientId).append("connected").toString());
        Object obj = createObjectOutputStream();
        int i = 0;
_L4:
        Object obj1 = obj;
        boolean flag = Thread.currentThread().isInterrupted();
        if (flag) goto _L2; else goto _L1
_L1:
        obj1 = obj;
        ((ObjectOutputStream) (obj)).writeObject((Serializable)queue.take());
        obj1 = obj;
        ((ObjectOutputStream) (obj)).flush();
        int j;
        j = i + 1;
        i = j;
        if (j < 70) goto _L4; else goto _L3
_L3:
        obj1 = obj;
        ((ObjectOutputStream) (obj)).reset();
        i = 0;
          goto _L4
        obj1;
_L13:
        obj1 = obj;
        Thread.currentThread().interrupt();
          goto _L4
_L2:
        if (obj != null)
        {
            CloseUtil.closeQuietly(((java.io.Closeable) (obj)));
        }
        close();
        addInfo((new StringBuilder()).append(clientId).append("connection closed").toString());
        return;
        obj1;
        obj = null;
_L12:
        addInfo((new StringBuilder()).append(clientId).append(obj1).toString());
        if (obj != null)
        {
            CloseUtil.closeQuietly(((java.io.Closeable) (obj)));
        }
        close();
        addInfo((new StringBuilder()).append(clientId).append("connection closed").toString());
        return;
        Object obj2;
        obj2;
        obj = null;
_L10:
        obj1 = obj;
        addError((new StringBuilder()).append(clientId).append(obj2).toString());
        if (obj != null)
        {
            CloseUtil.closeQuietly(((java.io.Closeable) (obj)));
        }
        close();
        addInfo((new StringBuilder()).append(clientId).append("connection closed").toString());
        return;
        obj2;
        obj = null;
_L8:
        obj1 = obj;
        addError((new StringBuilder()).append(clientId).append(obj2).toString());
        if (obj != null)
        {
            CloseUtil.closeQuietly(((java.io.Closeable) (obj)));
        }
        close();
        addInfo((new StringBuilder()).append(clientId).append("connection closed").toString());
        return;
        obj;
        obj1 = null;
_L6:
        if (obj1 != null)
        {
            CloseUtil.closeQuietly(((java.io.Closeable) (obj1)));
        }
        close();
        addInfo((new StringBuilder()).append(clientId).append("connection closed").toString());
        throw obj;
        obj;
        continue; /* Loop/switch isn't completed */
        obj2;
        obj1 = obj;
        obj = obj2;
        if (true) goto _L6; else goto _L5
_L5:
        obj2;
        if (true) goto _L8; else goto _L7
_L7:
        obj2;
        if (true) goto _L10; else goto _L9
_L9:
        obj1;
        if (true) goto _L12; else goto _L11
_L11:
        InterruptedException interruptedexception;
        interruptedexception;
        i = 0;
          goto _L13
    }

    public void setQueue(BlockingQueue blockingqueue)
    {
        queue = blockingqueue;
    }
}
