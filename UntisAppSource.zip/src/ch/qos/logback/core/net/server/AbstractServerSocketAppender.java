// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.net.server;

import ch.qos.logback.core.AppenderBase;
import ch.qos.logback.core.Context;
import ch.qos.logback.core.spi.PreSerializationTransformer;
import java.io.IOException;
import java.io.Serializable;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.UnknownHostException;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import javax.net.ServerSocketFactory;

// Referenced classes of package ch.qos.logback.core.net.server:
//            ServerRunner, RemoteReceiverServerListener, RemoteReceiverServerRunner, ServerListener, 
//            ClientVisitor, RemoteReceiverClient, Client

public abstract class AbstractServerSocketAppender extends AppenderBase
{

    public static final int DEFAULT_BACKLOG = 50;
    public static final int DEFAULT_CLIENT_QUEUE_SIZE = 100;
    private String address;
    private int backlog;
    private int clientQueueSize;
    private int port;
    private ServerRunner runner;

    public AbstractServerSocketAppender()
    {
        port = 4560;
        backlog = 50;
        clientQueueSize = 100;
    }

    protected void append(final Object serEvent)
    {
        if (serEvent == null)
        {
            return;
        } else
        {
            postProcessEvent(serEvent);
            serEvent = getPST().transform(serEvent);
            runner.accept(new ClientVisitor() {

                final AbstractServerSocketAppender this$0;
                final Serializable val$serEvent;

                public volatile void visit(Client client)
                {
                    visit((RemoteReceiverClient)client);
                }

                public void visit(RemoteReceiverClient remotereceiverclient)
                {
                    remotereceiverclient.offer(serEvent);
                }

            
            {
                this$0 = AbstractServerSocketAppender.this;
                serEvent = serializable;
                super();
            }
            });
            return;
        }
    }

    protected ServerListener createServerListener(ServerSocket serversocket)
    {
        return new RemoteReceiverServerListener(serversocket);
    }

    protected ServerRunner createServerRunner(ServerListener serverlistener, Executor executor)
    {
        return new RemoteReceiverServerRunner(serverlistener, executor, getClientQueueSize());
    }

    public String getAddress()
    {
        return address;
    }

    public int getBacklog()
    {
        return backlog;
    }

    public int getClientQueueSize()
    {
        return clientQueueSize;
    }

    protected InetAddress getInetAddress()
        throws UnknownHostException
    {
        if (getAddress() == null)
        {
            return null;
        } else
        {
            return InetAddress.getByName(getAddress());
        }
    }

    protected abstract PreSerializationTransformer getPST();

    public int getPort()
    {
        return port;
    }

    protected ServerSocketFactory getServerSocketFactory()
        throws Exception
    {
        return ServerSocketFactory.getDefault();
    }

    protected abstract void postProcessEvent(Object obj);

    public void setAddress(String s)
    {
        address = s;
    }

    public void setBacklog(int i)
    {
        backlog = i;
    }

    public void setClientQueueSize(int i)
    {
        clientQueueSize = i;
    }

    public void setPort(int i)
    {
        port = i;
    }

    public void start()
    {
        if (isStarted())
        {
            return;
        }
        try
        {
            runner = createServerRunner(createServerListener(getServerSocketFactory().createServerSocket(getPort(), getBacklog(), getInetAddress())), getContext().getExecutorService());
            runner.setContext(getContext());
            getContext().getExecutorService().execute(runner);
            super.start();
            return;
        }
        catch (Exception exception)
        {
            addError((new StringBuilder()).append("server startup error: ").append(exception).toString(), exception);
        }
    }

    public void stop()
    {
        if (!isStarted())
        {
            return;
        }
        try
        {
            runner.stop();
            super.stop();
            return;
        }
        catch (IOException ioexception)
        {
            addError((new StringBuilder()).append("server shutdown error: ").append(ioexception).toString(), ioexception);
        }
    }
}
