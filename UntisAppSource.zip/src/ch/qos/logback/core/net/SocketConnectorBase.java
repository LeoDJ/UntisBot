// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.net;

import java.io.PrintStream;
import java.net.InetAddress;
import java.net.Socket;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import javax.net.SocketFactory;

// Referenced classes of package ch.qos.logback.core.net:
//            SocketConnector

public class SocketConnectorBase
    implements SocketConnector
{
    private static class ConsoleExceptionHandler
        implements SocketConnector.ExceptionHandler
    {

        public void connectionFailed(SocketConnector socketconnector, Exception exception)
        {
            System.out.println(exception);
        }

        private ConsoleExceptionHandler()
        {
        }

    }

    public static interface DelayStrategy
    {

        public abstract int nextDelay();
    }

    private static class FixedDelay
        implements DelayStrategy
    {

        private int nextDelay;
        private final int retryDelay;

        public int nextDelay()
        {
            int i = nextDelay;
            nextDelay = retryDelay;
            return i;
        }

        public FixedDelay(int i, int j)
        {
            nextDelay = i;
            retryDelay = j;
        }
    }


    private final InetAddress address;
    private final Condition connectCondition;
    private DelayStrategy delayStrategy;
    private SocketConnector.ExceptionHandler exceptionHandler;
    private final Lock lock;
    private final int port;
    private Socket socket;
    private SocketFactory socketFactory;

    public SocketConnectorBase(InetAddress inetaddress, int i, int j, int k)
    {
        this(inetaddress, i, ((DelayStrategy) (new FixedDelay(j, k))));
    }

    public SocketConnectorBase(InetAddress inetaddress, int i, DelayStrategy delaystrategy)
    {
        lock = new ReentrantLock();
        connectCondition = lock.newCondition();
        address = inetaddress;
        port = i;
        delayStrategy = delaystrategy;
    }

    private void signalConnected()
    {
        lock.lock();
        connectCondition.signalAll();
        lock.unlock();
        return;
        Exception exception;
        exception;
        lock.unlock();
        throw exception;
    }

    public Socket awaitConnection()
        throws InterruptedException
    {
        return awaitConnection(0x7fffffffffffffffL);
    }

    public Socket awaitConnection(long l)
        throws InterruptedException
    {
        boolean flag;
        lock.lock();
        flag = false;
_L3:
        if (socket != null || flag) goto _L2; else goto _L1
_L1:
        Socket socket1;
        Exception exception;
        if (!connectCondition.await(l, TimeUnit.MILLISECONDS))
        {
            flag = true;
        } else
        {
            flag = false;
        }
        if (true) goto _L3; else goto _L2
_L2:
        socket1 = socket;
        lock.unlock();
        return socket1;
        exception;
        lock.unlock();
        throw exception;
    }

    public volatile Object call()
        throws Exception
    {
        return call();
    }

    public Socket call()
        throws InterruptedException
    {
        return null;
    }

    public void run()
    {
        if (socket != null)
        {
            throw new IllegalStateException("connector cannot be reused");
        }
        if (exceptionHandler == null)
        {
            exceptionHandler = new ConsoleExceptionHandler();
        }
        if (socketFactory == null)
        {
            socketFactory = SocketFactory.getDefault();
        }
_L2:
        if (Thread.currentThread().isInterrupted())
        {
            break MISSING_BLOCK_LABEL_95;
        }
        Thread.sleep(delayStrategy.nextDelay());
        socket = socketFactory.createSocket(address, port);
        signalConnected();
        return;
        Exception exception;
        exception;
        try
        {
            exceptionHandler.connectionFailed(this, exception);
        }
        catch (InterruptedException interruptedexception)
        {
            exceptionHandler.connectionFailed(this, interruptedexception);
            return;
        }
        if (true) goto _L2; else goto _L1
_L1:
    }

    public void setExceptionHandler(SocketConnector.ExceptionHandler exceptionhandler)
    {
        exceptionHandler = exceptionhandler;
    }

    public void setSocketFactory(SocketFactory socketfactory)
    {
        socketFactory = socketfactory;
    }
}
