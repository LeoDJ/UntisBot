// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.net;


// Referenced classes of package ch.qos.logback.core.net:
//            SocketConnectorBase

private static class retryDelay
    implements gy
{

    private int nextDelay;
    private final int retryDelay;

    public int nextDelay()
    {
        int i = nextDelay;
        nextDelay = retryDelay;
        return i;
    }

    public gy(int i, int j)
    {
        nextDelay = i;
        retryDelay = j;
    }
}
