// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.net.ssl;

import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.SecureRandom;

public class SecureRandomFactoryBean
{

    private String algorithm;
    private String provider;

    public SecureRandomFactoryBean()
    {
    }

    public SecureRandom createSecureRandom()
        throws NoSuchProviderException, NoSuchAlgorithmException
    {
        SecureRandom securerandom;
        try
        {
            if (getProvider() != null)
            {
                return SecureRandom.getInstance(getAlgorithm(), getProvider());
            }
            securerandom = SecureRandom.getInstance(getAlgorithm());
        }
        catch (NoSuchProviderException nosuchproviderexception)
        {
            throw new NoSuchProviderException((new StringBuilder()).append("no such secure random provider: ").append(getProvider()).toString());
        }
        catch (NoSuchAlgorithmException nosuchalgorithmexception)
        {
            throw new NoSuchAlgorithmException((new StringBuilder()).append("no such secure random algorithm: ").append(getAlgorithm()).toString());
        }
        return securerandom;
    }

    public String getAlgorithm()
    {
        if (algorithm == null)
        {
            return "SHA1PRNG";
        } else
        {
            return algorithm;
        }
    }

    public String getProvider()
    {
        return provider;
    }

    public void setAlgorithm(String s)
    {
        algorithm = s;
    }

    public void setProvider(String s)
    {
        provider = s;
    }
}
