// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.net.ssl;

import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import javax.net.ssl.KeyManagerFactory;

public class KeyManagerFactoryFactoryBean
{

    private String algorithm;
    private String provider;

    public KeyManagerFactoryFactoryBean()
    {
    }

    public KeyManagerFactory createKeyManagerFactory()
        throws NoSuchProviderException, NoSuchAlgorithmException
    {
        if (getProvider() != null)
        {
            return KeyManagerFactory.getInstance(getAlgorithm(), getProvider());
        } else
        {
            return KeyManagerFactory.getInstance(getAlgorithm());
        }
    }

    public String getAlgorithm()
    {
        if (algorithm == null)
        {
            return KeyManagerFactory.getDefaultAlgorithm();
        } else
        {
            return algorithm;
        }
    }

    public String getProvider()
    {
        return provider;
    }

    public void setAlgorithm(String s)
    {
        algorithm = s;
    }

    public void setProvider(String s)
    {
        provider = s;
    }
}
