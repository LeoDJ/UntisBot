// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.net.ssl;

import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import javax.net.ssl.TrustManagerFactory;

public class TrustManagerFactoryFactoryBean
{

    private String algorithm;
    private String provider;

    public TrustManagerFactoryFactoryBean()
    {
    }

    public TrustManagerFactory createTrustManagerFactory()
        throws NoSuchProviderException, NoSuchAlgorithmException
    {
        if (getProvider() != null)
        {
            return TrustManagerFactory.getInstance(getAlgorithm(), getProvider());
        } else
        {
            return TrustManagerFactory.getInstance(getAlgorithm());
        }
    }

    public String getAlgorithm()
    {
        if (algorithm == null)
        {
            return TrustManagerFactory.getDefaultAlgorithm();
        } else
        {
            return algorithm;
        }
    }

    public String getProvider()
    {
        return provider;
    }

    public void setAlgorithm(String s)
    {
        algorithm = s;
    }

    public void setProvider(String s)
    {
        provider = s;
    }
}
