// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.net.ssl;

import ch.qos.logback.core.util.LocationUtil;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;

public class KeyStoreFactoryBean
{

    private String location;
    private String password;
    private String provider;
    private String type;

    public KeyStoreFactoryBean()
    {
    }

    private KeyStore newKeyStore()
        throws NoSuchAlgorithmException, NoSuchProviderException, KeyStoreException
    {
        if (getProvider() != null)
        {
            return KeyStore.getInstance(getType(), getProvider());
        } else
        {
            return KeyStore.getInstance(getType());
        }
    }

    public KeyStore createKeyStore()
        throws NoSuchProviderException, NoSuchAlgorithmException, KeyStoreException
    {
        Object obj2;
        Object obj3;
        Object obj4;
        if (getLocation() == null)
        {
            throw new IllegalArgumentException("location is required");
        }
        obj3 = null;
        obj4 = null;
        obj2 = null;
        Object obj = LocationUtil.urlForResource(getLocation()).openStream();
        Object obj1;
        obj2 = obj;
        obj1 = obj;
        obj3 = obj;
        obj4 = obj;
        KeyStore keystore = newKeyStore();
        obj2 = obj;
        obj1 = obj;
        obj3 = obj;
        obj4 = obj;
        keystore.load(((InputStream) (obj)), getPassword().toCharArray());
        if (obj != null)
        {
            try
            {
                ((InputStream) (obj)).close();
            }
            // Misplaced declaration of an exception variable
            catch (Object obj)
            {
                ((IOException) (obj)).printStackTrace(System.err);
                return keystore;
            }
        }
        return keystore;
        obj;
        obj1 = obj2;
        throw new NoSuchProviderException((new StringBuilder()).append("no such keystore provider: ").append(getProvider()).toString());
        obj;
_L1:
        if (obj1 != null)
        {
            try
            {
                ((InputStream) (obj1)).close();
            }
            // Misplaced declaration of an exception variable
            catch (Object obj1)
            {
                ((IOException) (obj1)).printStackTrace(System.err);
            }
        }
        throw obj;
        obj;
        obj1 = obj3;
        throw new NoSuchAlgorithmException((new StringBuilder()).append("no such keystore type: ").append(getType()).toString());
        obj;
        obj1 = obj4;
        throw new KeyStoreException((new StringBuilder()).append(getLocation()).append(": file not found").toString());
        obj;
        obj1 = null;
        obj2 = obj;
_L2:
        throw new KeyStoreException((new StringBuilder()).append(getLocation()).append(": ").append(((Exception) (obj2)).getMessage()).toString(), ((Throwable) (obj2)));
        obj;
          goto _L1
        obj;
        obj1 = null;
          goto _L1
        obj2;
        obj1 = obj;
          goto _L2
    }

    public String getLocation()
    {
        return location;
    }

    public String getPassword()
    {
        if (password == null)
        {
            return "changeit";
        } else
        {
            return password;
        }
    }

    public String getProvider()
    {
        return provider;
    }

    public String getType()
    {
        if (type == null)
        {
            return "JKS";
        } else
        {
            return type;
        }
    }

    public void setLocation(String s)
    {
        location = s;
    }

    public void setPassword(String s)
    {
        password = s;
    }

    public void setProvider(String s)
    {
        provider = s;
    }

    public void setType(String s)
    {
        type = s;
    }
}
