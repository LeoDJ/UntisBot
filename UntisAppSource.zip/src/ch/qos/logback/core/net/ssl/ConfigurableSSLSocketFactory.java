// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.net.ssl;

import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import javax.net.SocketFactory;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

// Referenced classes of package ch.qos.logback.core.net.ssl:
//            SSLConfigurableSocket, SSLParametersConfiguration

public class ConfigurableSSLSocketFactory extends SocketFactory
{

    private final SSLSocketFactory _flddelegate;
    private final SSLParametersConfiguration parameters;

    public ConfigurableSSLSocketFactory(SSLParametersConfiguration sslparametersconfiguration, SSLSocketFactory sslsocketfactory)
    {
        parameters = sslparametersconfiguration;
        _flddelegate = sslsocketfactory;
    }

    public Socket createSocket(String s, int i)
        throws IOException, UnknownHostException
    {
        s = (SSLSocket)_flddelegate.createSocket(s, i);
        parameters.configure(new SSLConfigurableSocket(s));
        return s;
    }

    public Socket createSocket(String s, int i, InetAddress inetaddress, int j)
        throws IOException, UnknownHostException
    {
        s = (SSLSocket)_flddelegate.createSocket(s, i, inetaddress, j);
        parameters.configure(new SSLConfigurableSocket(s));
        return s;
    }

    public Socket createSocket(InetAddress inetaddress, int i)
        throws IOException
    {
        inetaddress = (SSLSocket)_flddelegate.createSocket(inetaddress, i);
        parameters.configure(new SSLConfigurableSocket(inetaddress));
        return inetaddress;
    }

    public Socket createSocket(InetAddress inetaddress, int i, InetAddress inetaddress1, int j)
        throws IOException
    {
        inetaddress = (SSLSocket)_flddelegate.createSocket(inetaddress, i, inetaddress1, j);
        parameters.configure(new SSLConfigurableSocket(inetaddress));
        return inetaddress;
    }
}
