// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.net.ssl;

import ch.qos.logback.core.spi.ContextAware;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.SecureRandom;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import javax.net.ssl.KeyManager;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;

// Referenced classes of package ch.qos.logback.core.net.ssl:
//            KeyStoreFactoryBean, KeyManagerFactoryFactoryBean, SecureRandomFactoryBean, TrustManagerFactoryFactoryBean

public class SSLContextFactoryBean
{

    private static final String JSSE_KEY_STORE_PROPERTY = "javax.net.ssl.keyStore";
    private static final String JSSE_TRUST_STORE_PROPERTY = "javax.net.ssl.trustStore";
    private KeyManagerFactoryFactoryBean keyManagerFactory;
    private KeyStoreFactoryBean keyStore;
    private String protocol;
    private String provider;
    private SecureRandomFactoryBean secureRandom;
    private TrustManagerFactoryFactoryBean trustManagerFactory;
    private KeyStoreFactoryBean trustStore;

    public SSLContextFactoryBean()
    {
    }

    private KeyManager[] createKeyManagers(ContextAware contextaware)
        throws NoSuchProviderException, NoSuchAlgorithmException, UnrecoverableKeyException, KeyStoreException
    {
        if (getKeyStore() == null)
        {
            return null;
        } else
        {
            KeyStore keystore = getKeyStore().createKeyStore();
            contextaware.addInfo((new StringBuilder()).append("key store of type '").append(keystore.getType()).append("' provider '").append(keystore.getProvider()).append("': ").append(getKeyStore().getLocation()).toString());
            KeyManagerFactory keymanagerfactory = getKeyManagerFactory().createKeyManagerFactory();
            contextaware.addInfo((new StringBuilder()).append("key manager algorithm '").append(keymanagerfactory.getAlgorithm()).append("' provider '").append(keymanagerfactory.getProvider()).append("'").toString());
            keymanagerfactory.init(keystore, getKeyStore().getPassword().toCharArray());
            return keymanagerfactory.getKeyManagers();
        }
    }

    private SecureRandom createSecureRandom(ContextAware contextaware)
        throws NoSuchProviderException, NoSuchAlgorithmException
    {
        SecureRandom securerandom = getSecureRandom().createSecureRandom();
        contextaware.addInfo((new StringBuilder()).append("secure random algorithm '").append(securerandom.getAlgorithm()).append("' provider '").append(securerandom.getProvider()).append("'").toString());
        return securerandom;
    }

    private TrustManager[] createTrustManagers(ContextAware contextaware)
        throws NoSuchProviderException, NoSuchAlgorithmException, KeyStoreException
    {
        if (getTrustStore() == null)
        {
            return null;
        } else
        {
            KeyStore keystore = getTrustStore().createKeyStore();
            contextaware.addInfo((new StringBuilder()).append("trust store of type '").append(keystore.getType()).append("' provider '").append(keystore.getProvider()).append("': ").append(getTrustStore().getLocation()).toString());
            TrustManagerFactory trustmanagerfactory = getTrustManagerFactory().createTrustManagerFactory();
            contextaware.addInfo((new StringBuilder()).append("trust manager algorithm '").append(trustmanagerfactory.getAlgorithm()).append("' provider '").append(trustmanagerfactory.getProvider()).append("'").toString());
            trustmanagerfactory.init(keystore);
            return trustmanagerfactory.getTrustManagers();
        }
    }

    private KeyStoreFactoryBean keyStoreFromSystemProperties(String s)
    {
        if (System.getProperty(s) == null)
        {
            return null;
        } else
        {
            KeyStoreFactoryBean keystorefactorybean = new KeyStoreFactoryBean();
            keystorefactorybean.setLocation(locationFromSystemProperty(s));
            keystorefactorybean.setProvider(System.getProperty((new StringBuilder()).append(s).append("Provider").toString()));
            keystorefactorybean.setPassword(System.getProperty((new StringBuilder()).append(s).append("Password").toString()));
            keystorefactorybean.setType(System.getProperty((new StringBuilder()).append(s).append("Type").toString()));
            return keystorefactorybean;
        }
    }

    private String locationFromSystemProperty(String s)
    {
        String s1 = System.getProperty(s);
        s = s1;
        if (s1 != null)
        {
            s = s1;
            if (!s1.startsWith("file:"))
            {
                s = (new StringBuilder()).append("file:").append(s1).toString();
            }
        }
        return s;
    }

    public SSLContext createContext(ContextAware contextaware)
        throws NoSuchProviderException, NoSuchAlgorithmException, KeyManagementException, UnrecoverableKeyException, KeyStoreException, CertificateException
    {
        SSLContext sslcontext;
        if (getProvider() != null)
        {
            sslcontext = SSLContext.getInstance(getProtocol(), getProvider());
        } else
        {
            sslcontext = SSLContext.getInstance(getProtocol());
        }
        contextaware.addInfo((new StringBuilder()).append("SSL protocol '").append(sslcontext.getProtocol()).append("' provider '").append(sslcontext.getProvider()).append("'").toString());
        sslcontext.init(createKeyManagers(contextaware), createTrustManagers(contextaware), createSecureRandom(contextaware));
        return sslcontext;
    }

    public KeyManagerFactoryFactoryBean getKeyManagerFactory()
    {
        if (keyManagerFactory == null)
        {
            return new KeyManagerFactoryFactoryBean();
        } else
        {
            return keyManagerFactory;
        }
    }

    public KeyStoreFactoryBean getKeyStore()
    {
        if (keyStore == null)
        {
            keyStore = keyStoreFromSystemProperties("javax.net.ssl.keyStore");
        }
        return keyStore;
    }

    public String getProtocol()
    {
        if (protocol == null)
        {
            return "SSL";
        } else
        {
            return protocol;
        }
    }

    public String getProvider()
    {
        return provider;
    }

    public SecureRandomFactoryBean getSecureRandom()
    {
        if (secureRandom == null)
        {
            return new SecureRandomFactoryBean();
        } else
        {
            return secureRandom;
        }
    }

    public TrustManagerFactoryFactoryBean getTrustManagerFactory()
    {
        if (trustManagerFactory == null)
        {
            return new TrustManagerFactoryFactoryBean();
        } else
        {
            return trustManagerFactory;
        }
    }

    public KeyStoreFactoryBean getTrustStore()
    {
        if (trustStore == null)
        {
            trustStore = keyStoreFromSystemProperties("javax.net.ssl.trustStore");
        }
        return trustStore;
    }

    public void setKeyManagerFactory(KeyManagerFactoryFactoryBean keymanagerfactoryfactorybean)
    {
        keyManagerFactory = keymanagerfactoryfactorybean;
    }

    public void setKeyStore(KeyStoreFactoryBean keystorefactorybean)
    {
        keyStore = keystorefactorybean;
    }

    public void setProtocol(String s)
    {
        protocol = s;
    }

    public void setProvider(String s)
    {
        provider = s;
    }

    public void setSecureRandom(SecureRandomFactoryBean securerandomfactorybean)
    {
        secureRandom = securerandomfactorybean;
    }

    public void setTrustManagerFactory(TrustManagerFactoryFactoryBean trustmanagerfactoryfactorybean)
    {
        trustManagerFactory = trustmanagerfactoryfactorybean;
    }

    public void setTrustStore(KeyStoreFactoryBean keystorefactorybean)
    {
        trustStore = keystorefactorybean;
    }
}
