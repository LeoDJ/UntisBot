// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.net.ssl;


// Referenced classes of package ch.qos.logback.core.net.ssl:
//            SSLContextFactoryBean, SSLParametersConfiguration

public class SSLConfiguration extends SSLContextFactoryBean
{

    private SSLParametersConfiguration parameters;

    public SSLConfiguration()
    {
    }

    public SSLParametersConfiguration getParameters()
    {
        if (parameters == null)
        {
            parameters = new SSLParametersConfiguration();
        }
        return parameters;
    }

    public void setParameters(SSLParametersConfiguration sslparametersconfiguration)
    {
        parameters = sslparametersconfiguration;
    }
}
