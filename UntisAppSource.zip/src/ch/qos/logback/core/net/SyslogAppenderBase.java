// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.net;

import ch.qos.logback.core.AppenderBase;
import ch.qos.logback.core.Layout;
import java.io.IOException;
import java.io.OutputStream;
import java.net.SocketException;
import java.net.UnknownHostException;

// Referenced classes of package ch.qos.logback.core.net:
//            SyslogOutputStream

public abstract class SyslogAppenderBase extends AppenderBase
{

    static final int MAX_MESSAGE_SIZE_LIMIT = 65000;
    static final String SYSLOG_LAYOUT_URL = "http://logback.qos.ch/codes.html#syslog_layout";
    String facilityStr;
    boolean initialized;
    Layout layout;
    private boolean lazyInit;
    int maxMessageSize;
    int port;
    protected SyslogOutputStream sos;
    protected String suffixPattern;
    String syslogHost;

    public SyslogAppenderBase()
    {
        port = 514;
        initialized = false;
        lazyInit = false;
    }

    private boolean connect()
    {
        int i;
        sos = new SyslogOutputStream(syslogHost, port);
        i = sos.getSendBufferSize();
        if (maxMessageSize != 0) goto _L2; else goto _L1
_L1:
        maxMessageSize = Math.min(i, 65000);
        addInfo((new StringBuilder()).append("Defaulting maxMessageSize to [").append(maxMessageSize).append("]").toString());
_L4:
        Object obj;
        return sos != null;
_L2:
        if (maxMessageSize <= i) goto _L4; else goto _L3
_L3:
        addWarn((new StringBuilder()).append("maxMessageSize of [").append(maxMessageSize).append("] is larger than the system defined datagram size of [").append(i).append("].").toString());
        addWarn("This may result in dropped logs.");
          goto _L4
        obj;
        addError("Could not create SyslogWriter", ((Throwable) (obj)));
          goto _L4
        obj;
        addWarn("Failed to bind to a random datagram socket. Will try to reconnect later.", ((Throwable) (obj)));
          goto _L4
    }

    public static int facilityStringToint(String s)
    {
        if ("KERN".equalsIgnoreCase(s))
        {
            return 0;
        }
        if ("USER".equalsIgnoreCase(s))
        {
            return 8;
        }
        if ("MAIL".equalsIgnoreCase(s))
        {
            return 16;
        }
        if ("DAEMON".equalsIgnoreCase(s))
        {
            return 24;
        }
        if ("AUTH".equalsIgnoreCase(s))
        {
            return 32;
        }
        if ("SYSLOG".equalsIgnoreCase(s))
        {
            return 40;
        }
        if ("LPR".equalsIgnoreCase(s))
        {
            return 48;
        }
        if ("NEWS".equalsIgnoreCase(s))
        {
            return 56;
        }
        if ("UUCP".equalsIgnoreCase(s))
        {
            return 64;
        }
        if ("CRON".equalsIgnoreCase(s))
        {
            return 72;
        }
        if ("AUTHPRIV".equalsIgnoreCase(s))
        {
            return 80;
        }
        if ("FTP".equalsIgnoreCase(s))
        {
            return 88;
        }
        if ("NTP".equalsIgnoreCase(s))
        {
            return 96;
        }
        if ("AUDIT".equalsIgnoreCase(s))
        {
            return 104;
        }
        if ("ALERT".equalsIgnoreCase(s))
        {
            return 112;
        }
        if ("CLOCK".equalsIgnoreCase(s))
        {
            return 120;
        }
        if ("LOCAL0".equalsIgnoreCase(s))
        {
            return 128;
        }
        if ("LOCAL1".equalsIgnoreCase(s))
        {
            return 136;
        }
        if ("LOCAL2".equalsIgnoreCase(s))
        {
            return 144;
        }
        if ("LOCAL3".equalsIgnoreCase(s))
        {
            return 152;
        }
        if ("LOCAL4".equalsIgnoreCase(s))
        {
            return 160;
        }
        if ("LOCAL5".equalsIgnoreCase(s))
        {
            return 168;
        }
        if ("LOCAL6".equalsIgnoreCase(s))
        {
            return 176;
        }
        if ("LOCAL7".equalsIgnoreCase(s))
        {
            return 184;
        } else
        {
            throw new IllegalArgumentException((new StringBuilder()).append(s).append(" is not a valid syslog facility string").toString());
        }
    }

    protected void append(Object obj)
    {
        if (isStarted()) goto _L2; else goto _L1
_L1:
        return;
_L2:
        if (!initialized && lazyInit)
        {
            initialized = true;
            connect();
        }
        if (sos == null)
        {
            continue; /* Loop/switch isn't completed */
        }
        String s1 = layout.doLayout(obj);
        if (s1 != null)
        {
            String s = s1;
            try
            {
                if (s1.length() > maxMessageSize)
                {
                    s = s1.substring(0, maxMessageSize);
                }
                sos.write(s.getBytes());
                sos.flush();
                postProcess(obj, sos);
                return;
            }
            // Misplaced declaration of an exception variable
            catch (Object obj)
            {
                addError((new StringBuilder()).append("Failed to send diagram to ").append(syslogHost).toString(), ((Throwable) (obj)));
            }
            return;
        }
        if (true) goto _L1; else goto _L3
_L3:
    }

    public abstract Layout buildLayout();

    public String getFacility()
    {
        return facilityStr;
    }

    public Layout getLayout()
    {
        return layout;
    }

    public boolean getLazy()
    {
        return lazyInit;
    }

    public int getMaxMessageSize()
    {
        return maxMessageSize;
    }

    public int getPort()
    {
        return port;
    }

    public abstract int getSeverityForEvent(Object obj);

    public String getSuffixPattern()
    {
        return suffixPattern;
    }

    public String getSyslogHost()
    {
        return syslogHost;
    }

    protected void postProcess(Object obj, OutputStream outputstream)
    {
    }

    public void setFacility(String s)
    {
        String s1 = s;
        if (s != null)
        {
            s1 = s.trim();
        }
        facilityStr = s1;
    }

    public void setLayout(Layout layout1)
    {
        addWarn("The layout of a SyslogAppender cannot be set directly. See also http://logback.qos.ch/codes.html#syslog_layout");
    }

    public void setLazy(boolean flag)
    {
        lazyInit = flag;
    }

    public void setMaxMessageSize(int i)
    {
        maxMessageSize = i;
    }

    public void setPort(int i)
    {
        port = i;
    }

    public void setSuffixPattern(String s)
    {
        suffixPattern = s;
    }

    public void setSyslogHost(String s)
    {
        syslogHost = s;
    }

    public void start()
    {
        int i = 0;
        if (facilityStr == null)
        {
            addError("The Facility option is mandatory");
            i = 1;
        }
        int j = i;
        if (!lazyInit)
        {
            j = i;
            if (!connect())
            {
                j = i + 1;
            }
        }
        if (layout == null)
        {
            layout = buildLayout();
        }
        if (j == 0)
        {
            super.start();
        }
    }

    public void stop()
    {
        sos.close();
        super.stop();
    }
}
