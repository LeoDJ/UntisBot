// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.pattern.color;

import ch.qos.logback.core.pattern.CompositeConverter;

public abstract class ForegroundCompositeConverterBase extends CompositeConverter
{

    private static final String SET_DEFAULT_COLOR = "\033[0;39m";

    public ForegroundCompositeConverterBase()
    {
    }

    protected abstract String getForegroundColorCode(Object obj);

    protected String transform(Object obj, String s)
    {
        StringBuilder stringbuilder = new StringBuilder();
        stringbuilder.append("\033[");
        stringbuilder.append(getForegroundColorCode(obj));
        stringbuilder.append("m");
        stringbuilder.append(s);
        stringbuilder.append("\033[0;39m");
        return stringbuilder.toString();
    }
}
