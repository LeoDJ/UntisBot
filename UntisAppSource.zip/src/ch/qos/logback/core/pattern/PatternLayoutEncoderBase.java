// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.pattern;

import ch.qos.logback.core.Layout;
import ch.qos.logback.core.encoder.LayoutWrappingEncoder;

public class PatternLayoutEncoderBase extends LayoutWrappingEncoder
{

    protected boolean outputPatternAsHeader;
    String pattern;

    public PatternLayoutEncoderBase()
    {
        outputPatternAsHeader = false;
    }

    public String getPattern()
    {
        return pattern;
    }

    public boolean isOutputPatternAsHeader()
    {
        return outputPatternAsHeader;
    }

    public boolean isOutputPatternAsPresentationHeader()
    {
        return outputPatternAsHeader;
    }

    public void setLayout(Layout layout)
    {
        throw new UnsupportedOperationException((new StringBuilder()).append("one cannot set the layout of ").append(getClass().getName()).toString());
    }

    public void setOutputPatternAsHeader(boolean flag)
    {
        outputPatternAsHeader = flag;
    }

    public void setOutputPatternAsPresentationHeader(boolean flag)
    {
        addWarn("[outputPatternAsPresentationHeader] property is deprecated. Please use [outputPatternAsHeader] option instead.");
        outputPatternAsHeader = flag;
    }

    public void setPattern(String s)
    {
        pattern = s;
    }
}
