// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.pattern;


// Referenced classes of package ch.qos.logback.core.pattern:
//            CompositeConverter

public class IdentityCompositeConverter extends CompositeConverter
{

    public IdentityCompositeConverter()
    {
    }

    protected String transform(Object obj, String s)
    {
        return s;
    }
}
