// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.joran.action;

import ch.qos.logback.core.Context;
import ch.qos.logback.core.joran.spi.ActionException;
import ch.qos.logback.core.joran.spi.InterpretationContext;
import ch.qos.logback.core.util.CachingDateFormatter;
import ch.qos.logback.core.util.OptionHelper;
import org.xml.sax.Attributes;

// Referenced classes of package ch.qos.logback.core.joran.action:
//            Action, ActionUtil

public class TimestampAction extends Action
{

    static String CONTEXT_BIRTH = "contextBirth";
    static String DATE_PATTERN_ATTRIBUTE = "datePattern";
    static String TIME_REFERENCE_ATTRIBUTE = "timeReference";
    boolean inError;

    public TimestampAction()
    {
        inError = false;
    }

    public void begin(InterpretationContext interpretationcontext, String s, Attributes attributes)
        throws ActionException
    {
        s = attributes.getValue("key");
        if (OptionHelper.isEmpty(s))
        {
            addError("Attribute named [key] cannot be empty");
            inError = true;
        }
        String s1 = attributes.getValue(DATE_PATTERN_ATTRIBUTE);
        if (OptionHelper.isEmpty(s1))
        {
            addError((new StringBuilder()).append("Attribute named [").append(DATE_PATTERN_ATTRIBUTE).append("] cannot be empty").toString());
            inError = true;
        }
        String s2 = attributes.getValue(TIME_REFERENCE_ATTRIBUTE);
        long l;
        if (CONTEXT_BIRTH.equalsIgnoreCase(s2))
        {
            addInfo("Using context birth as time reference.");
            l = context.getBirthTime();
        } else
        {
            l = System.currentTimeMillis();
            addInfo("Using current interpretation time, i.e. now, as time reference.");
        }
        if (inError)
        {
            return;
        } else
        {
            attributes = ActionUtil.stringToScope(attributes.getValue("scope"));
            s1 = (new CachingDateFormatter(s1)).format(l);
            addInfo((new StringBuilder()).append("Adding property to the context with key=\"").append(s).append("\" and value=\"").append(s1).append("\" to the ").append(attributes).append(" scope").toString());
            ActionUtil.setProperty(interpretationcontext, s, s1, attributes);
            return;
        }
    }

    public void end(InterpretationContext interpretationcontext, String s)
        throws ActionException
    {
    }

}
