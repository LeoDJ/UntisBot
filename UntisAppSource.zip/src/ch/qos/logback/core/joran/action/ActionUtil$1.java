// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.joran.action;


// Referenced classes of package ch.qos.logback.core.joran.action:
//            ActionUtil

static class ope
{

    static final int $SwitchMap$ch$qos$logback$core$joran$action$ActionUtil$Scope[];

    static 
    {
        $SwitchMap$ch$qos$logback$core$joran$action$ActionUtil$Scope = new int[ope.values().length];
        try
        {
            $SwitchMap$ch$qos$logback$core$joran$action$ActionUtil$Scope[ope.LOCAL.ordinal()] = 1;
        }
        catch (NoSuchFieldError nosuchfielderror2) { }
        try
        {
            $SwitchMap$ch$qos$logback$core$joran$action$ActionUtil$Scope[ope.CONTEXT.ordinal()] = 2;
        }
        catch (NoSuchFieldError nosuchfielderror1) { }
        try
        {
            $SwitchMap$ch$qos$logback$core$joran$action$ActionUtil$Scope[ope.SYSTEM.ordinal()] = 3;
        }
        catch (NoSuchFieldError nosuchfielderror)
        {
            return;
        }
    }
}
