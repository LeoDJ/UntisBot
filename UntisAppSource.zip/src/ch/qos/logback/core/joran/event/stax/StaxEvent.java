// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.joran.event.stax;

import javax.xml.stream.Location;

public class StaxEvent
{

    final Location location;
    final String name;

    StaxEvent(String s, Location location1)
    {
        name = s;
        location = location1;
    }

    public Location getLocation()
    {
        return location;
    }

    public String getName()
    {
        return name;
    }
}
