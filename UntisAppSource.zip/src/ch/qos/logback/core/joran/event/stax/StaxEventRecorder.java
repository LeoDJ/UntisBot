// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.joran.event.stax;

import ch.qos.logback.core.Context;
import ch.qos.logback.core.joran.spi.ElementPath;
import ch.qos.logback.core.joran.spi.JoranException;
import ch.qos.logback.core.spi.ContextAwareBase;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import javax.xml.namespace.QName;
import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.Characters;
import javax.xml.stream.events.EndElement;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;

// Referenced classes of package ch.qos.logback.core.joran.event.stax:
//            BodyEvent, EndEvent, StartEvent, StaxEvent

public class StaxEventRecorder extends ContextAwareBase
{

    List eventList;
    ElementPath globalElementPath;

    public StaxEventRecorder(Context context)
    {
        eventList = new ArrayList();
        globalElementPath = new ElementPath();
        setContext(context);
    }

    private void addCharacters(XMLEvent xmlevent)
    {
        Characters characters = xmlevent.asCharacters();
        StaxEvent staxevent = getLastEvent();
        if (staxevent instanceof BodyEvent)
        {
            ((BodyEvent)staxevent).append(characters.getData());
        } else
        if (!characters.isWhiteSpace())
        {
            xmlevent = new BodyEvent(characters.getData(), xmlevent.getLocation());
            eventList.add(xmlevent);
            return;
        }
    }

    private void addEndEvent(XMLEvent xmlevent)
    {
        xmlevent = xmlevent.asEndElement();
        xmlevent = new EndEvent(xmlevent.getName().getLocalPart(), xmlevent.getLocation());
        eventList.add(xmlevent);
        globalElementPath.pop();
    }

    private void addStartElement(XMLEvent xmlevent)
    {
        xmlevent = xmlevent.asStartElement();
        String s = xmlevent.getName().getLocalPart();
        globalElementPath.push(s);
        xmlevent = new StartEvent(globalElementPath.duplicate(), s, xmlevent.getAttributes(), xmlevent.getLocation());
        eventList.add(xmlevent);
    }

    private void read(XMLEventReader xmleventreader)
        throws XMLStreamException
    {
        do
        {
            if (!xmleventreader.hasNext())
            {
                break;
            }
            XMLEvent xmlevent = xmleventreader.nextEvent();
            switch (xmlevent.getEventType())
            {
            case 1: // '\001'
                addStartElement(xmlevent);
                break;

            case 4: // '\004'
                addCharacters(xmlevent);
                break;

            case 2: // '\002'
                addEndEvent(xmlevent);
                break;
            }
        } while (true);
    }

    public List getEventList()
    {
        return eventList;
    }

    StaxEvent getLastEvent()
    {
        int i;
        if (!eventList.isEmpty())
        {
            if ((i = eventList.size()) != 0)
            {
                return (StaxEvent)eventList.get(i - 1);
            }
        }
        return null;
    }

    public void recordEvents(InputStream inputstream)
        throws JoranException
    {
        try
        {
            read(XMLInputFactory.newInstance().createXMLEventReader(inputstream));
            return;
        }
        // Misplaced declaration of an exception variable
        catch (InputStream inputstream)
        {
            throw new JoranException("Problem parsing XML document. See previously reported errors.", inputstream);
        }
    }
}
