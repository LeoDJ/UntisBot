// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.joran.event.stax;

import javax.xml.stream.Location;

// Referenced classes of package ch.qos.logback.core.joran.event.stax:
//            StaxEvent

public class BodyEvent extends StaxEvent
{

    private String text;

    BodyEvent(String s, Location location)
    {
        super(null, location);
        text = s;
    }

    void append(String s)
    {
        text = (new StringBuilder()).append(text).append(s).toString();
    }

    public String getText()
    {
        return text;
    }

    public String toString()
    {
        return (new StringBuilder()).append("BodyEvent(").append(getText()).append(")").append(location.getLineNumber()).append(",").append(location.getColumnNumber()).toString();
    }
}
