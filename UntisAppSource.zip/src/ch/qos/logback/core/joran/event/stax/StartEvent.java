// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.joran.event.stax;

import ch.qos.logback.core.joran.spi.ElementPath;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.xml.namespace.QName;
import javax.xml.stream.Location;
import javax.xml.stream.events.Attribute;

// Referenced classes of package ch.qos.logback.core.joran.event.stax:
//            StaxEvent

public class StartEvent extends StaxEvent
{

    List attributes;
    public ElementPath elementPath;

    StartEvent(ElementPath elementpath, String s, Iterator iterator, Location location)
    {
        super(s, location);
        populateAttributes(iterator);
        elementPath = elementpath;
    }

    private void populateAttributes(Iterator iterator)
    {
        for (; iterator.hasNext(); attributes.add(iterator.next()))
        {
            if (attributes == null)
            {
                attributes = new ArrayList(2);
            }
        }

    }

    Attribute getAttributeByName(String s)
    {
        if (attributes == null)
        {
            return null;
        }
        for (Iterator iterator = attributes.iterator(); iterator.hasNext();)
        {
            Attribute attribute = (Attribute)iterator.next();
            if (s.equals(attribute.getName().getLocalPart()))
            {
                return attribute;
            }
        }

        return null;
    }

    public List getAttributeList()
    {
        return attributes;
    }

    public ElementPath getElementPath()
    {
        return elementPath;
    }

    public String toString()
    {
        return (new StringBuilder()).append("StartEvent(").append(getName()).append(")  [").append(location.getLineNumber()).append(",").append(location.getColumnNumber()).append("]").toString();
    }
}
