// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.joran.event.stax;

import javax.xml.stream.Location;

// Referenced classes of package ch.qos.logback.core.joran.event.stax:
//            StaxEvent

public class EndEvent extends StaxEvent
{

    public EndEvent(String s, Location location)
    {
        super(s, location);
    }

    public String toString()
    {
        return (new StringBuilder()).append("EndEvent(").append(getName()).append(")  [").append(location.getLineNumber()).append(",").append(location.getColumnNumber()).append("]").toString();
    }
}
