// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.joran.spi;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ElementPath
{

    ArrayList partList;

    public ElementPath()
    {
        partList = new ArrayList();
    }

    public ElementPath(String s)
    {
        partList = new ArrayList();
        if (s != null) goto _L2; else goto _L1
_L1:
        return;
_L2:
        if ((s = s.split("/")) != null)
        {
            int j = s.length;
            int i = 0;
            while (i < j) 
            {
                String s1 = s[i];
                if (s1.length() > 0)
                {
                    partList.add(s1);
                }
                i++;
            }
        }
        if (true) goto _L1; else goto _L3
_L3:
    }

    public ElementPath(List list)
    {
        partList = new ArrayList();
        partList.addAll(list);
    }

    private boolean equalityCheck(String s, String s1)
    {
        return s.equalsIgnoreCase(s1);
    }

    public ElementPath duplicate()
    {
        ElementPath elementpath = new ElementPath();
        elementpath.partList.addAll(partList);
        return elementpath;
    }

    public boolean equals(Object obj)
    {
        if (obj != null && (obj instanceof ElementPath)) goto _L2; else goto _L1
_L1:
        return false;
_L2:
        if (((ElementPath) (obj = (ElementPath)obj)).size() == size())
        {
            int j = size();
            int i = 0;
label0:
            do
            {
label1:
                {
                    if (i >= j)
                    {
                        break label1;
                    }
                    if (!equalityCheck(get(i), ((ElementPath) (obj)).get(i)))
                    {
                        break label0;
                    }
                    i++;
                }
            } while (true);
        }
        if (true) goto _L1; else goto _L3
_L3:
        return true;
    }

    public String get(int i)
    {
        return (String)partList.get(i);
    }

    public List getCopyOfPartList()
    {
        return new ArrayList(partList);
    }

    public String peekLast()
    {
        if (!partList.isEmpty())
        {
            int i = partList.size();
            return (String)partList.get(i - 1);
        } else
        {
            return null;
        }
    }

    public void pop()
    {
        if (!partList.isEmpty())
        {
            partList.remove(partList.size() - 1);
        }
    }

    public void push(String s)
    {
        partList.add(s);
    }

    public int size()
    {
        return partList.size();
    }

    protected String toStableString()
    {
        StringBuilder stringbuilder = new StringBuilder();
        String s;
        for (Iterator iterator = partList.iterator(); iterator.hasNext(); stringbuilder.append("[").append(s).append("]"))
        {
            s = (String)iterator.next();
        }

        return stringbuilder.toString();
    }

    public String toString()
    {
        return toStableString();
    }
}
