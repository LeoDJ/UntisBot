// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.joran.spi;

import java.util.ArrayList;
import java.util.List;

// Referenced classes of package ch.qos.logback.core.joran.spi:
//            ElementPath

public class ElementSelector extends ElementPath
{

    public ElementSelector()
    {
    }

    public ElementSelector(String s)
    {
        super(s);
    }

    public ElementSelector(List list)
    {
        super(list);
    }

    private boolean equalityCheck(String s, String s1)
    {
        return s.equalsIgnoreCase(s1);
    }

    public boolean equals(Object obj)
    {
        if (obj != null && (obj instanceof ElementSelector)) goto _L2; else goto _L1
_L1:
        return false;
_L2:
        if (((ElementSelector) (obj = (ElementSelector)obj)).size() == size())
        {
            int j = size();
            int i = 0;
label0:
            do
            {
label1:
                {
                    if (i >= j)
                    {
                        break label1;
                    }
                    if (!equalityCheck(get(i), ((ElementSelector) (obj)).get(i)))
                    {
                        break label0;
                    }
                    i++;
                }
            } while (true);
        }
        if (true) goto _L1; else goto _L3
_L3:
        return true;
    }

    public boolean fullPathMatch(ElementPath elementpath)
    {
        if (elementpath.size() == size()) goto _L2; else goto _L1
_L1:
        return false;
_L2:
        int j = size();
        int i = 0;
label0:
        do
        {
label1:
            {
                if (i >= j)
                {
                    break label1;
                }
                if (!equalityCheck(get(i), elementpath.get(i)))
                {
                    break label0;
                }
                i++;
            }
        } while (true);
        if (true) goto _L1; else goto _L3
_L3:
        return true;
    }

    public int getPrefixMatchLength(ElementPath elementpath)
    {
        int j = 0;
        if (elementpath == null)
        {
            return 0;
        }
        int i = partList.size();
        int k = elementpath.partList.size();
        if (i == 0 || k == 0)
        {
            return 0;
        }
        if (i > k)
        {
            i = k;
        }
        for (k = 0; k < i && equalityCheck((String)partList.get(k), (String)elementpath.partList.get(k));)
        {
            k++;
            j++;
        }

        return j;
    }

    public int getTailMatchLength(ElementPath elementpath)
    {
        if (elementpath != null)
        {
            int l = partList.size();
            int i1 = elementpath.partList.size();
            if (l != 0 && i1 != 0)
            {
                int i;
                int j;
                int k;
                if (l <= i1)
                {
                    i = l;
                } else
                {
                    i = i1;
                }
                j = 1;
                k = 0;
                for (; j <= i && equalityCheck((String)partList.get(l - j), (String)elementpath.partList.get(i1 - j)); j++)
                {
                    k++;
                }

                return k;
            }
        }
        return 0;
    }

    public int hashCode()
    {
        int i = 0;
        int k = size();
        int j = 0;
        for (; i < k; i++)
        {
            j ^= get(i).toLowerCase().hashCode();
        }

        return j;
    }

    public boolean isContainedIn(ElementPath elementpath)
    {
        if (elementpath == null)
        {
            return false;
        } else
        {
            return elementpath.toStableString().contains(toStableString());
        }
    }
}
