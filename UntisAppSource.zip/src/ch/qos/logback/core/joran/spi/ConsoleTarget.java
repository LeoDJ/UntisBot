// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.joran.spi;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;

public final class ConsoleTarget extends Enum
{

    private static final ConsoleTarget $VALUES[];
    public static final ConsoleTarget SystemErr;
    public static final ConsoleTarget SystemOut;
    private final String name;
    private final OutputStream stream;

    private ConsoleTarget(String s, int i, String s1, OutputStream outputstream)
    {
        super(s, i);
        name = s1;
        stream = outputstream;
    }

    public static ConsoleTarget findByName(String s)
    {
        ConsoleTarget aconsoletarget[] = values();
        int j = aconsoletarget.length;
        for (int i = 0; i < j; i++)
        {
            ConsoleTarget consoletarget = aconsoletarget[i];
            if (consoletarget.name.equalsIgnoreCase(s))
            {
                return consoletarget;
            }
        }

        return null;
    }

    public static ConsoleTarget valueOf(String s)
    {
        return (ConsoleTarget)Enum.valueOf(ch/qos/logback/core/joran/spi/ConsoleTarget, s);
    }

    public static ConsoleTarget[] values()
    {
        return (ConsoleTarget[])$VALUES.clone();
    }

    public String getName()
    {
        return name;
    }

    public OutputStream getStream()
    {
        return stream;
    }

    static 
    {
        SystemOut = new ConsoleTarget("SystemOut", 0, "System.out", new OutputStream() {

            public void flush()
                throws IOException
            {
                System.out.flush();
            }

            public void write(int i)
                throws IOException
            {
                System.out.write(i);
            }

            public void write(byte abyte0[])
                throws IOException
            {
                System.out.write(abyte0);
            }

            public void write(byte abyte0[], int i, int j)
                throws IOException
            {
                System.out.write(abyte0, i, j);
            }

        });
        SystemErr = new ConsoleTarget("SystemErr", 1, "System.err", new OutputStream() {

            public void flush()
                throws IOException
            {
                System.err.flush();
            }

            public void write(int i)
                throws IOException
            {
                System.err.write(i);
            }

            public void write(byte abyte0[])
                throws IOException
            {
                System.err.write(abyte0);
            }

            public void write(byte abyte0[], int i, int j)
                throws IOException
            {
                System.err.write(abyte0, i, j);
            }

        });
        $VALUES = (new ConsoleTarget[] {
            SystemOut, SystemErr
        });
    }
}
