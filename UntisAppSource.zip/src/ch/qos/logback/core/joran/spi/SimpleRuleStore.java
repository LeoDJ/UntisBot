// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.joran.spi;

import ch.qos.logback.core.Context;
import ch.qos.logback.core.joran.action.Action;
import ch.qos.logback.core.spi.ContextAwareBase;
import ch.qos.logback.core.util.OptionHelper;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

// Referenced classes of package ch.qos.logback.core.joran.spi:
//            RuleStore, ElementSelector, ElementPath

public class SimpleRuleStore extends ContextAwareBase
    implements RuleStore
{

    static String KLEENE_STAR = "*";
    HashMap rules;

    public SimpleRuleStore(Context context)
    {
        rules = new HashMap();
        setContext(context);
    }

    private boolean isKleeneStar(String s)
    {
        return KLEENE_STAR.equals(s);
    }

    private boolean isSuffixPattern(ElementSelector elementselector)
    {
        return elementselector.size() > 1 && elementselector.get(0).equals(KLEENE_STAR);
    }

    public void addRule(ElementSelector elementselector, Action action)
    {
        action.setContext(context);
        List list = (List)rules.get(elementselector);
        Object obj = list;
        if (list == null)
        {
            obj = new ArrayList();
            rules.put(elementselector, obj);
        }
        ((List) (obj)).add(action);
    }

    public void addRule(ElementSelector elementselector, String s)
    {
        Action action = (Action)OptionHelper.instantiateByClassName(s, ch/qos/logback/core/joran/action/Action, context);
        s = action;
_L2:
        if (s != null)
        {
            addRule(elementselector, ((Action) (s)));
        }
        return;
        Exception exception;
        exception;
        addError((new StringBuilder()).append("Could not instantiate class [").append(s).append("]").toString(), exception);
        s = null;
        if (true) goto _L2; else goto _L1
_L1:
    }

    List fullPathMatch(ElementPath elementpath)
    {
        for (Iterator iterator = rules.keySet().iterator(); iterator.hasNext();)
        {
            ElementSelector elementselector = (ElementSelector)iterator.next();
            if (elementselector.fullPathMatch(elementpath))
            {
                return (List)rules.get(elementselector);
            }
        }

        return null;
    }

    public List matchActions(ElementPath elementpath)
    {
        Object obj = fullPathMatch(elementpath);
        if (obj == null)
        {
            List list = suffixMatch(elementpath);
            obj = list;
            if (list == null)
            {
                List list1 = prefixMatch(elementpath);
                obj = list1;
                if (list1 == null)
                {
                    elementpath = middleMatch(elementpath);
                    obj = elementpath;
                    if (elementpath == null)
                    {
                        return null;
                    }
                }
            }
        }
        return ((List) (obj));
    }

    List middleMatch(ElementPath elementpath)
    {
        Iterator iterator = rules.keySet().iterator();
        ElementSelector elementselector = null;
        int i = 0;
        do
        {
            if (!iterator.hasNext())
            {
                break;
            }
            ElementSelector elementselector1 = (ElementSelector)iterator.next();
            String s = elementselector1.peekLast();
            Object obj;
            if (elementselector1.size() > 1)
            {
                obj = elementselector1.get(0);
            } else
            {
                obj = null;
            }
            if (isKleeneStar(s) && isKleeneStar(((String) (obj))))
            {
                obj = elementselector1.getCopyOfPartList();
                if (((List) (obj)).size() > 2)
                {
                    ((List) (obj)).remove(0);
                    ((List) (obj)).remove(((List) (obj)).size() - 1);
                }
                obj = new ElementSelector(((List) (obj)));
                int j;
                if (((ElementSelector) (obj)).isContainedIn(elementpath))
                {
                    j = ((ElementSelector) (obj)).size();
                } else
                {
                    j = 0;
                }
                if (j > i)
                {
                    i = j;
                    elementselector = elementselector1;
                }
            }
        } while (true);
        if (elementselector != null)
        {
            return (List)rules.get(elementselector);
        } else
        {
            return null;
        }
    }

    List prefixMatch(ElementPath elementpath)
    {
        int i = 0;
        Iterator iterator = rules.keySet().iterator();
        ElementSelector elementselector = null;
        do
        {
            if (!iterator.hasNext())
            {
                break;
            }
            ElementSelector elementselector1 = (ElementSelector)iterator.next();
            if (isKleeneStar(elementselector1.peekLast()))
            {
                int j = elementselector1.getPrefixMatchLength(elementpath);
                if (j == elementselector1.size() - 1 && j > i)
                {
                    i = j;
                    elementselector = elementselector1;
                }
            }
        } while (true);
        if (elementselector != null)
        {
            return (List)rules.get(elementselector);
        } else
        {
            return null;
        }
    }

    List suffixMatch(ElementPath elementpath)
    {
        int i = 0;
        Iterator iterator = rules.keySet().iterator();
        ElementSelector elementselector = null;
        do
        {
            if (!iterator.hasNext())
            {
                break;
            }
            ElementSelector elementselector1 = (ElementSelector)iterator.next();
            if (isSuffixPattern(elementselector1))
            {
                int j = elementselector1.getTailMatchLength(elementpath);
                if (j > i)
                {
                    i = j;
                    elementselector = elementselector1;
                }
            }
        } while (true);
        if (elementselector != null)
        {
            return (List)rules.get(elementselector);
        } else
        {
            return null;
        }
    }

    public String toString()
    {
        StringBuilder stringbuilder = new StringBuilder();
        stringbuilder.append("SimpleRuleStore ( ").append("rules = ").append(rules).append("  ").append(" )");
        return stringbuilder.toString();
    }

}
