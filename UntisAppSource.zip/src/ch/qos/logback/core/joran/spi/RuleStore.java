// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.joran.spi;

import ch.qos.logback.core.joran.action.Action;
import java.util.List;

// Referenced classes of package ch.qos.logback.core.joran.spi:
//            ElementSelector, ElementPath

public interface RuleStore
{

    public abstract void addRule(ElementSelector elementselector, Action action);

    public abstract void addRule(ElementSelector elementselector, String s)
        throws ClassNotFoundException;

    public abstract List matchActions(ElementPath elementpath);
}
