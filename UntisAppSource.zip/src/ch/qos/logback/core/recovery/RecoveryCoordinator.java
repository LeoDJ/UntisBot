// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.recovery;


public class RecoveryCoordinator
{

    static long BACKOFF_COEFFICIENT_MAX = 0L;
    public static final long BACKOFF_COEFFICIENT_MIN = 20L;
    private static long UNSET = -1L;
    private long backOffCoefficient;
    private long currentTime;
    long next;

    public RecoveryCoordinator()
    {
        backOffCoefficient = 20L;
        currentTime = UNSET;
        next = System.currentTimeMillis() + getBackoffCoefficient();
    }

    private long getBackoffCoefficient()
    {
        long l = backOffCoefficient;
        if (backOffCoefficient < BACKOFF_COEFFICIENT_MAX)
        {
            backOffCoefficient = backOffCoefficient * 4L;
        }
        return l;
    }

    private long getCurrentTime()
    {
        if (currentTime != UNSET)
        {
            return currentTime;
        } else
        {
            return System.currentTimeMillis();
        }
    }

    public boolean isTooSoon()
    {
        long l = getCurrentTime();
        if (l > next)
        {
            next = l + getBackoffCoefficient();
            return false;
        } else
        {
            return true;
        }
    }

    void setCurrentTime(long l)
    {
        currentTime = l;
    }

    static 
    {
        BACKOFF_COEFFICIENT_MAX = 0x50000L;
    }
}
