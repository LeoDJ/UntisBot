// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.recovery;

import ch.qos.logback.core.Context;
import ch.qos.logback.core.status.ErrorStatus;
import ch.qos.logback.core.status.InfoStatus;
import ch.qos.logback.core.status.Status;
import ch.qos.logback.core.status.StatusManager;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;

// Referenced classes of package ch.qos.logback.core.recovery:
//            RecoveryCoordinator

public abstract class ResilientOutputStreamBase extends OutputStream
{

    static final int STATUS_COUNT_LIMIT = 8;
    private Context context;
    private int noContextWarning;
    protected OutputStream os;
    protected boolean presumedClean;
    private RecoveryCoordinator recoveryCoordinator;
    private int statusCount;

    public ResilientOutputStreamBase()
    {
        noContextWarning = 0;
        statusCount = 0;
        presumedClean = true;
    }

    private boolean isPresumedInError()
    {
        return recoveryCoordinator != null && !presumedClean;
    }

    private void postSuccessfulWrite()
    {
        if (recoveryCoordinator != null)
        {
            recoveryCoordinator = null;
            statusCount = 0;
            addStatus(new InfoStatus((new StringBuilder()).append("Recovered from IO failure on ").append(getDescription()).toString(), this));
        }
    }

    public void addStatus(Status status)
    {
        if (context == null)
        {
            int i = noContextWarning;
            noContextWarning = i + 1;
            if (i == 0)
            {
                System.out.println((new StringBuilder()).append("LOGBACK: No context given for ").append(this).toString());
            }
        } else
        {
            StatusManager statusmanager = context.getStatusManager();
            if (statusmanager != null)
            {
                statusmanager.add(status);
                return;
            }
        }
    }

    void addStatusIfCountNotOverLimit(Status status)
    {
        statusCount = statusCount + 1;
        if (statusCount < 8)
        {
            addStatus(status);
        }
        if (statusCount == 8)
        {
            addStatus(status);
            addStatus(new InfoStatus((new StringBuilder()).append("Will supress future messages regarding ").append(getDescription()).toString(), this));
        }
    }

    void attemptRecovery()
    {
        try
        {
            close();
        }
        catch (IOException ioexception1) { }
        addStatusIfCountNotOverLimit(new InfoStatus((new StringBuilder()).append("Attempting to recover from IO failure on ").append(getDescription()).toString(), this));
        try
        {
            os = openNewOutputStream();
            presumedClean = true;
            return;
        }
        catch (IOException ioexception)
        {
            addStatusIfCountNotOverLimit(new ErrorStatus((new StringBuilder()).append("Failed to open ").append(getDescription()).toString(), this, ioexception));
        }
    }

    public void close()
        throws IOException
    {
        if (os != null)
        {
            os.close();
        }
    }

    public void flush()
    {
        if (os == null)
        {
            break MISSING_BLOCK_LABEL_18;
        }
        os.flush();
        postSuccessfulWrite();
        return;
        IOException ioexception;
        ioexception;
        postIOFailure(ioexception);
        return;
    }

    public Context getContext()
    {
        return context;
    }

    abstract String getDescription();

    abstract OutputStream openNewOutputStream()
        throws IOException;

    void postIOFailure(IOException ioexception)
    {
        addStatusIfCountNotOverLimit(new ErrorStatus((new StringBuilder()).append("IO failure while writing to ").append(getDescription()).toString(), this, ioexception));
        presumedClean = false;
        if (recoveryCoordinator == null)
        {
            recoveryCoordinator = new RecoveryCoordinator();
        }
    }

    public void setContext(Context context1)
    {
        context = context1;
    }

    public void write(int i)
    {
        if (isPresumedInError())
        {
            if (!recoveryCoordinator.isTooSoon())
            {
                attemptRecovery();
            }
            return;
        }
        try
        {
            os.write(i);
            postSuccessfulWrite();
            return;
        }
        catch (IOException ioexception)
        {
            postIOFailure(ioexception);
        }
    }

    public void write(byte abyte0[], int i, int j)
    {
        if (isPresumedInError())
        {
            if (!recoveryCoordinator.isTooSoon())
            {
                attemptRecovery();
            }
            return;
        }
        try
        {
            os.write(abyte0, i, j);
            postSuccessfulWrite();
            return;
        }
        // Misplaced declaration of an exception variable
        catch (byte abyte0[])
        {
            postIOFailure(abyte0);
        }
    }
}
