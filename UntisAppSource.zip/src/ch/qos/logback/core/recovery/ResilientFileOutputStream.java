// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.recovery;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.channels.FileChannel;

// Referenced classes of package ch.qos.logback.core.recovery:
//            ResilientOutputStreamBase

public class ResilientFileOutputStream extends ResilientOutputStreamBase
{

    private File file;
    private FileOutputStream fos;

    public ResilientFileOutputStream(File file1, boolean flag)
        throws FileNotFoundException
    {
        file = file1;
        fos = new FileOutputStream(file1, flag);
        os = new BufferedOutputStream(fos);
        presumedClean = true;
    }

    public FileChannel getChannel()
    {
        if (os == null)
        {
            return null;
        } else
        {
            return fos.getChannel();
        }
    }

    String getDescription()
    {
        return (new StringBuilder()).append("file [").append(file).append("]").toString();
    }

    public File getFile()
    {
        return file;
    }

    OutputStream openNewOutputStream()
        throws IOException
    {
        fos = new FileOutputStream(file, true);
        return new BufferedOutputStream(fos);
    }

    public String toString()
    {
        return (new StringBuilder()).append("c.q.l.c.recovery.ResilientFileOutputStream@").append(System.identityHashCode(this)).toString();
    }
}
