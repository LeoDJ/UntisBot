// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.sift;

import ch.qos.logback.core.Appender;
import ch.qos.logback.core.Context;
import ch.qos.logback.core.helpers.NOPAppender;
import ch.qos.logback.core.joran.spi.JoranException;
import ch.qos.logback.core.spi.AbstractComponentTracker;
import ch.qos.logback.core.spi.ContextAwareImpl;

// Referenced classes of package ch.qos.logback.core.sift:
//            AppenderFactory

public class AppenderTracker extends AbstractComponentTracker
{

    final AppenderFactory appenderFactory;
    final Context context;
    final ContextAwareImpl contextAware;
    int nopaWarningCount;

    public AppenderTracker(Context context1, AppenderFactory appenderfactory)
    {
        nopaWarningCount = 0;
        context = context1;
        appenderFactory = appenderfactory;
        contextAware = new ContextAwareImpl(context1, this);
    }

    private NOPAppender buildNOPAppender(String s)
    {
        if (nopaWarningCount < 4)
        {
            nopaWarningCount = nopaWarningCount + 1;
            contextAware.addError((new StringBuilder()).append("Building NOPAppender for discriminating value [").append(s).append("]").toString());
        }
        s = new NOPAppender();
        s.setContext(context);
        s.start();
        return s;
    }

    protected Appender buildComponent(String s)
    {
        Appender appender = null;
        Appender appender1 = appenderFactory.buildAppender(context, s);
        appender = appender1;
_L2:
        Object obj = appender;
        if (appender == null)
        {
            obj = buildNOPAppender(s);
        }
        return ((Appender) (obj));
        JoranException joranexception;
        joranexception;
        contextAware.addError((new StringBuilder()).append("Error while building appender with discriminating value [").append(s).append("]").toString());
        if (true) goto _L2; else goto _L1
_L1:
    }

    protected volatile Object buildComponent(String s)
    {
        return buildComponent(s);
    }

    protected boolean isComponentStale(Appender appender)
    {
        return !appender.isStarted();
    }

    protected volatile boolean isComponentStale(Object obj)
    {
        return isComponentStale((Appender)obj);
    }

    protected void processPriorToRemoval(Appender appender)
    {
        appender.stop();
    }

    protected volatile void processPriorToRemoval(Object obj)
    {
        processPriorToRemoval((Appender)obj);
    }
}
