// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.sift;

import ch.qos.logback.core.spi.ContextAwareBase;

// Referenced classes of package ch.qos.logback.core.sift:
//            Discriminator

public abstract class AbstractDiscriminator extends ContextAwareBase
    implements Discriminator
{

    protected boolean started;

    public AbstractDiscriminator()
    {
    }

    public boolean isStarted()
    {
        return started;
    }

    public void start()
    {
        started = true;
    }

    public void stop()
    {
        started = false;
    }
}
