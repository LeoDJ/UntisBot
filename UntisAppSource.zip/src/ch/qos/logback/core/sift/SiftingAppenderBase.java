// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.sift;

import ch.qos.logback.core.Appender;
import ch.qos.logback.core.AppenderBase;
import ch.qos.logback.core.util.Duration;
import java.util.Collection;
import java.util.Iterator;

// Referenced classes of package ch.qos.logback.core.sift:
//            Discriminator, AppenderTracker, AppenderFactory

public abstract class SiftingAppenderBase extends AppenderBase
{

    AppenderFactory appenderFactory;
    protected AppenderTracker appenderTracker;
    Discriminator discriminator;
    int maxAppenderCount;
    Duration timeout;

    public SiftingAppenderBase()
    {
        timeout = new Duration(0x1b7740L);
        maxAppenderCount = 0x7fffffff;
    }

    protected void append(Object obj)
    {
        if (!isStarted())
        {
            return;
        }
        String s = discriminator.getDiscriminatingValue(obj);
        long l = getTimestamp(obj);
        Appender appender = (Appender)appenderTracker.getOrCreate(s, l);
        if (eventMarksEndOfLife(obj))
        {
            appenderTracker.endOfLife(s);
        }
        appenderTracker.removeStaleComponents(l);
        appender.doAppend(obj);
    }

    protected abstract boolean eventMarksEndOfLife(Object obj);

    public AppenderTracker getAppenderTracker()
    {
        return appenderTracker;
    }

    public Discriminator getDiscriminator()
    {
        return discriminator;
    }

    public String getDiscriminatorKey()
    {
        if (discriminator != null)
        {
            return discriminator.getKey();
        } else
        {
            return null;
        }
    }

    public int getMaxAppenderCount()
    {
        return maxAppenderCount;
    }

    public Duration getTimeout()
    {
        return timeout;
    }

    protected abstract long getTimestamp(Object obj);

    public void setAppenderFactory(AppenderFactory appenderfactory)
    {
        appenderFactory = appenderfactory;
    }

    public void setDiscriminator(Discriminator discriminator1)
    {
        discriminator = discriminator1;
    }

    public void setMaxAppenderCount(int i)
    {
        maxAppenderCount = i;
    }

    public void setTimeout(Duration duration)
    {
        timeout = duration;
    }

    public void start()
    {
        int i = 0;
        if (discriminator == null)
        {
            addError("Missing discriminator. Aborting");
            i = 1;
        }
        int j = i;
        if (!discriminator.isStarted())
        {
            addError("Discriminator has not started successfully. Aborting");
            j = i + 1;
        }
        if (appenderFactory == null)
        {
            addError("AppenderFactory has not been set. Aborting");
            j++;
        } else
        {
            appenderTracker = new AppenderTracker(context, appenderFactory);
            appenderTracker.setMaxComponents(maxAppenderCount);
            appenderTracker.setTimeout(timeout.getMilliseconds());
        }
        if (j == 0)
        {
            super.start();
        }
    }

    public void stop()
    {
        for (Iterator iterator = appenderTracker.allComponents().iterator(); iterator.hasNext(); ((Appender)iterator.next()).stop()) { }
    }
}
