// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core;

import ch.qos.logback.core.spi.AppenderAttachable;
import ch.qos.logback.core.spi.AppenderAttachableImpl;
import java.util.Iterator;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

// Referenced classes of package ch.qos.logback.core:
//            UnsynchronizedAppenderBase, Appender

public class AsyncAppenderBase extends UnsynchronizedAppenderBase
    implements AppenderAttachable
{
    class Worker extends Thread
    {

        final AsyncAppenderBase this$0;

        public void run()
        {
            Object obj = AsyncAppenderBase.this;
            AppenderAttachableImpl appenderattachableimpl = ((AsyncAppenderBase) (obj)).aai;
            do
            {
                if (!((AsyncAppenderBase) (obj)).isStarted())
                {
                    break;
                }
                try
                {
                    appenderattachableimpl.appendLoopOnAppenders(((AsyncAppenderBase) (obj)).blockingQueue.take());
                    continue;
                }
                catch (InterruptedException interruptedexception) { }
                break;
            } while (true);
            addInfo("Worker thread will flush remaining events before exiting.");
            for (obj = ((AsyncAppenderBase) (obj)).blockingQueue.iterator(); ((Iterator) (obj)).hasNext(); appenderattachableimpl.appendLoopOnAppenders(((Iterator) (obj)).next())) { }
            appenderattachableimpl.detachAndStopAllAppenders();
        }

        Worker()
        {
            this$0 = AsyncAppenderBase.this;
            super();
        }
    }


    public static final int DEFAULT_QUEUE_SIZE = 256;
    static final int UNDEFINED = -1;
    AppenderAttachableImpl aai;
    int appenderCount;
    BlockingQueue blockingQueue;
    int discardingThreshold;
    int queueSize;
    Worker worker;

    public AsyncAppenderBase()
    {
        aai = new AppenderAttachableImpl();
        queueSize = 256;
        appenderCount = 0;
        discardingThreshold = -1;
        worker = new Worker();
    }

    private boolean isQueueBelowDiscardingThreshold()
    {
        return blockingQueue.remainingCapacity() < discardingThreshold;
    }

    private void put(Object obj)
    {
        try
        {
            blockingQueue.put(obj);
            return;
        }
        // Misplaced declaration of an exception variable
        catch (Object obj)
        {
            return;
        }
    }

    public void addAppender(Appender appender)
    {
        if (appenderCount == 0)
        {
            appenderCount = appenderCount + 1;
            addInfo((new StringBuilder()).append("Attaching appender named [").append(appender.getName()).append("] to AsyncAppender.").toString());
            aai.addAppender(appender);
            return;
        } else
        {
            addWarn("One and only one appender may be attached to AsyncAppender.");
            addWarn((new StringBuilder()).append("Ignoring additional appender named [").append(appender.getName()).append("]").toString());
            return;
        }
    }

    protected void append(Object obj)
    {
        if (isQueueBelowDiscardingThreshold() && isDiscardable(obj))
        {
            return;
        } else
        {
            preprocess(obj);
            put(obj);
            return;
        }
    }

    public void detachAndStopAllAppenders()
    {
        aai.detachAndStopAllAppenders();
    }

    public boolean detachAppender(Appender appender)
    {
        return aai.detachAppender(appender);
    }

    public boolean detachAppender(String s)
    {
        return aai.detachAppender(s);
    }

    public Appender getAppender(String s)
    {
        return aai.getAppender(s);
    }

    public int getDiscardingThreshold()
    {
        return discardingThreshold;
    }

    public int getNumberOfElementsInQueue()
    {
        return blockingQueue.size();
    }

    public int getQueueSize()
    {
        return queueSize;
    }

    public int getRemainingCapacity()
    {
        return blockingQueue.remainingCapacity();
    }

    public boolean isAttached(Appender appender)
    {
        return aai.isAttached(appender);
    }

    protected boolean isDiscardable(Object obj)
    {
        return false;
    }

    public Iterator iteratorForAppenders()
    {
        return aai.iteratorForAppenders();
    }

    protected void preprocess(Object obj)
    {
    }

    public void setDiscardingThreshold(int i)
    {
        discardingThreshold = i;
    }

    public void setQueueSize(int i)
    {
        queueSize = i;
    }

    public void start()
    {
        if (appenderCount == 0)
        {
            addError("No attached appenders found.");
            return;
        }
        if (queueSize < 1)
        {
            addError((new StringBuilder()).append("Invalid queue size [").append(queueSize).append("]").toString());
            return;
        }
        blockingQueue = new ArrayBlockingQueue(queueSize);
        if (discardingThreshold == -1)
        {
            discardingThreshold = queueSize / 5;
        }
        addInfo((new StringBuilder()).append("Setting discardingThreshold to ").append(discardingThreshold).toString());
        worker.setDaemon(true);
        worker.setName((new StringBuilder()).append("AsyncAppender-Worker-").append(worker.getName()).toString());
        super.start();
        worker.start();
    }

    public void stop()
    {
        if (!isStarted())
        {
            return;
        }
        super.stop();
        worker.interrupt();
        try
        {
            worker.join(1000L);
            return;
        }
        catch (InterruptedException interruptedexception)
        {
            addError("Failed to join worker thread", interruptedexception);
        }
    }
}
