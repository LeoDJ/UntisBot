// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.encoder;

import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;

public class NonClosableInputStream extends FilterInputStream
{

    NonClosableInputStream(InputStream inputstream)
    {
        super(inputstream);
    }

    public void close()
    {
    }

    public void realClose()
        throws IOException
    {
        super.close();
    }
}
