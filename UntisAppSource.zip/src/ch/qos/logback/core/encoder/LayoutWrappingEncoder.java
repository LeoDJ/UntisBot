// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.encoder;

import ch.qos.logback.core.CoreConstants;
import ch.qos.logback.core.Layout;
import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;

// Referenced classes of package ch.qos.logback.core.encoder:
//            EncoderBase

public class LayoutWrappingEncoder extends EncoderBase
{

    private Charset charset;
    private boolean immediateFlush;
    protected Layout layout;

    public LayoutWrappingEncoder()
    {
        immediateFlush = true;
    }

    private void appendIfNotNull(StringBuilder stringbuilder, String s)
    {
        if (s != null)
        {
            stringbuilder.append(s);
        }
    }

    private byte[] convertToBytes(String s)
    {
        if (charset == null)
        {
            return s.getBytes();
        }
        try
        {
            s = s.getBytes(charset.name());
        }
        // Misplaced declaration of an exception variable
        catch (String s)
        {
            throw new IllegalStateException("An existing charset cannot possibly be unsupported.");
        }
        return s;
    }

    public void close()
        throws IOException
    {
        writeFooter();
    }

    public void doEncode(Object obj)
        throws IOException
    {
        obj = layout.doLayout(obj);
        outputStream.write(convertToBytes(((String) (obj))));
        if (immediateFlush)
        {
            outputStream.flush();
        }
    }

    public Charset getCharset()
    {
        return charset;
    }

    public Layout getLayout()
    {
        return layout;
    }

    public void init(OutputStream outputstream)
        throws IOException
    {
        super.init(outputstream);
        writeHeader();
    }

    public boolean isImmediateFlush()
    {
        return immediateFlush;
    }

    public boolean isStarted()
    {
        return false;
    }

    public void setCharset(Charset charset1)
    {
        charset = charset1;
    }

    public void setImmediateFlush(boolean flag)
    {
        immediateFlush = flag;
    }

    public void setLayout(Layout layout1)
    {
        layout = layout1;
    }

    public void start()
    {
        started = true;
    }

    public void stop()
    {
        started = false;
        if (outputStream == null)
        {
            break MISSING_BLOCK_LABEL_19;
        }
        outputStream.flush();
        return;
        IOException ioexception;
        ioexception;
    }

    void writeFooter()
        throws IOException
    {
        if (layout != null && outputStream != null)
        {
            StringBuilder stringbuilder = new StringBuilder();
            appendIfNotNull(stringbuilder, layout.getPresentationFooter());
            appendIfNotNull(stringbuilder, layout.getFileFooter());
            if (stringbuilder.length() > 0)
            {
                outputStream.write(convertToBytes(stringbuilder.toString()));
                outputStream.flush();
            }
        }
    }

    void writeHeader()
        throws IOException
    {
        if (layout != null && outputStream != null)
        {
            StringBuilder stringbuilder = new StringBuilder();
            appendIfNotNull(stringbuilder, layout.getFileHeader());
            appendIfNotNull(stringbuilder, layout.getPresentationHeader());
            if (stringbuilder.length() > 0)
            {
                stringbuilder.append(CoreConstants.LINE_SEPARATOR);
                outputStream.write(convertToBytes(stringbuilder.toString()));
                outputStream.flush();
            }
        }
    }
}
