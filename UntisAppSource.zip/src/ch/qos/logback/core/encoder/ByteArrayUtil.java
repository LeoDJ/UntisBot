// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.encoder;

import java.io.ByteArrayOutputStream;

public class ByteArrayUtil
{

    public ByteArrayUtil()
    {
    }

    public static byte[] hexStringToByteArray(String s)
    {
        byte abyte0[] = new byte[s.length() / 2];
        for (int i = 0; i < abyte0.length; i++)
        {
            int j = i * 2;
            abyte0[i] = (byte)(Integer.parseInt(s.substring(j, j + 2), 16) & 0xff);
        }

        return abyte0;
    }

    static int readInt(byte abyte0[], int i)
    {
        int j = 0;
        int k = 0;
        for (; j < 4; j++)
        {
            k += (abyte0[i + j] & 0xff) << 24 - j * 8;
        }

        return k;
    }

    public static String toHexString(byte abyte0[])
    {
        StringBuffer stringbuffer = new StringBuffer();
        int j = abyte0.length;
        for (int i = 0; i < j; i++)
        {
            String s = Integer.toHexString(abyte0[i] & 0xff);
            if (s.length() == 1)
            {
                stringbuffer.append('0');
            }
            stringbuffer.append(s);
        }

        return stringbuffer.toString();
    }

    static void writeInt(ByteArrayOutputStream bytearrayoutputstream, int i)
    {
        for (int j = 0; j < 4; j++)
        {
            bytearrayoutputstream.write((byte)(i >>> 24 - j * 8));
        }

    }

    static void writeInt(byte abyte0[], int i, int j)
    {
        for (int k = 0; k < 4; k++)
        {
            abyte0[i + k] = (byte)(j >>> 24 - k * 8);
        }

    }
}
