// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.core.encoder;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.List;

// Referenced classes of package ch.qos.logback.core.encoder:
//            NonClosableInputStream, ByteArrayUtil

public class EventObjectInputStream extends InputStream
{

    List buffer;
    int index;
    NonClosableInputStream ncis;

    EventObjectInputStream(InputStream inputstream)
        throws IOException
    {
        buffer = new ArrayList();
        index = 0;
        ncis = new NonClosableInputStream(inputstream);
    }

    private void internalReset()
    {
        index = 0;
        buffer.clear();
    }

    public int available()
        throws IOException
    {
        return ncis.available();
    }

    public void close()
        throws IOException
    {
        ncis.realClose();
    }

    Object getFromBuffer()
    {
        if (index >= buffer.size())
        {
            return null;
        } else
        {
            List list = buffer;
            int i = index;
            index = i + 1;
            return list.get(i);
        }
    }

    public int read()
        throws IOException
    {
        throw new UnsupportedOperationException("Only the readEvent method is supported.");
    }

    public Object readEvent()
        throws IOException
    {
        Object obj = getFromBuffer();
        if (obj != null)
        {
            return obj;
        }
        internalReset();
        int i = readHeader();
        if (i == -1)
        {
            return null;
        } else
        {
            readPayload(i);
            readFooter(i);
            return getFromBuffer();
        }
    }

    Object readEvents(ObjectInputStream objectinputstream)
        throws IOException
    {
        objectinputstream = ((ObjectInputStream) (objectinputstream.readObject()));
        buffer.add(objectinputstream);
        return objectinputstream;
        ClassNotFoundException classnotfoundexception;
        classnotfoundexception;
        objectinputstream = null;
_L2:
        classnotfoundexception.printStackTrace();
        return objectinputstream;
        classnotfoundexception;
        if (true) goto _L2; else goto _L1
_L1:
    }

    void readFooter(int i)
        throws IOException
    {
        byte abyte0[] = new byte[8];
        if (ncis.read(abyte0) == -1)
        {
            throw new IllegalStateException("Looks like a corrupt stream");
        }
        if (ByteArrayUtil.readInt(abyte0, 0) != 0x262b5373)
        {
            throw new IllegalStateException("Looks like a corrupt stream");
        }
        if (ByteArrayUtil.readInt(abyte0, 4) != (0x262b5373 ^ i))
        {
            throw new IllegalStateException("Invalid checksum");
        } else
        {
            return;
        }
    }

    int readHeader()
        throws IOException
    {
        int i = -1;
        byte abyte0[] = new byte[16];
        if (ncis.read(abyte0) != -1)
        {
            if (ByteArrayUtil.readInt(abyte0, 0) != 0x6e78f671)
            {
                throw new IllegalStateException("Does not look like data created by ObjectStreamEncoder");
            }
            int j = ByteArrayUtil.readInt(abyte0, 4);
            i = j;
            if (ByteArrayUtil.readInt(abyte0, 12) != (0x6e78f671 ^ j))
            {
                throw new IllegalStateException("Invalid checksum");
            }
        }
        return i;
    }

    void readPayload(int i)
        throws IOException
    {
        ArrayList arraylist = new ArrayList(i);
        ObjectInputStream objectinputstream = new ObjectInputStream(ncis);
        for (int j = 0; j < i; j++)
        {
            arraylist.add(readEvents(objectinputstream));
        }

        objectinputstream.close();
    }
}
