// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.classic.joran.action;

import ch.qos.logback.classic.net.ReceiverBase;
import ch.qos.logback.core.Context;
import ch.qos.logback.core.joran.action.Action;
import ch.qos.logback.core.joran.spi.ActionException;
import ch.qos.logback.core.joran.spi.InterpretationContext;
import ch.qos.logback.core.util.OptionHelper;
import org.xml.sax.Attributes;

public class ReceiverAction extends Action
{

    private boolean inError;
    private ReceiverBase receiver;

    public ReceiverAction()
    {
    }

    public void begin(InterpretationContext interpretationcontext, String s, Attributes attributes)
        throws ActionException
    {
        attributes = attributes.getValue("class");
        if (OptionHelper.isEmpty(attributes))
        {
            addError((new StringBuilder()).append("Missing class name for receiver. Near [").append(s).append("] line ").append(getLineNumber(interpretationcontext)).toString());
            inError = true;
            return;
        }
        try
        {
            addInfo((new StringBuilder()).append("About to instantiate receiver of type [").append(attributes).append("]").toString());
            receiver = (ReceiverBase)OptionHelper.instantiateByClassName(attributes, ch/qos/logback/classic/net/ReceiverBase, context);
            receiver.setContext(context);
            interpretationcontext.pushObject(receiver);
            return;
        }
        // Misplaced declaration of an exception variable
        catch (InterpretationContext interpretationcontext)
        {
            inError = true;
        }
        addError((new StringBuilder()).append("Could not create a receiver of type [").append(attributes).append("].").toString(), interpretationcontext);
        throw new ActionException(interpretationcontext);
    }

    public void end(InterpretationContext interpretationcontext, String s)
        throws ActionException
    {
        if (inError)
        {
            return;
        }
        interpretationcontext.getContext().register(receiver);
        receiver.start();
        if (interpretationcontext.peekObject() != receiver)
        {
            addWarn("The object at the of the stack is not the remote pushed earlier.");
            return;
        } else
        {
            interpretationcontext.popObject();
            return;
        }
    }
}
