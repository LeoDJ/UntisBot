// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.classic.joran.action;

import java.net.URL;

// Referenced classes of package ch.qos.logback.classic.joran.action:
//            ConditionalIncludeAction

class this._cls0
{

    final ConditionalIncludeAction this$0;
    private URL url;

    URL getUrl()
    {
        return url;
    }

    void setUrl(URL url1)
    {
        url = url1;
    }

    ()
    {
        this$0 = ConditionalIncludeAction.this;
        super();
    }
}
