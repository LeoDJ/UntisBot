// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.classic.turbo;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import ch.qos.logback.core.spi.FilterReply;
import java.util.HashMap;
import java.util.Map;
import org.slf4j.MDC;
import org.slf4j.Marker;

// Referenced classes of package ch.qos.logback.classic.turbo:
//            TurboFilter, MDCValueLevelPair

public class DynamicThresholdFilter extends TurboFilter
{

    private Level defaultThreshold;
    private String key;
    private FilterReply onHigherOrEqual;
    private FilterReply onLower;
    private Map valueLevelMap;

    public DynamicThresholdFilter()
    {
        valueLevelMap = new HashMap();
        defaultThreshold = Level.ERROR;
        onHigherOrEqual = FilterReply.NEUTRAL;
        onLower = FilterReply.DENY;
    }

    public void addMDCValueLevelPair(MDCValueLevelPair mdcvaluelevelpair)
    {
        if (valueLevelMap.containsKey(mdcvaluelevelpair.getValue()))
        {
            addError((new StringBuilder()).append(mdcvaluelevelpair.getValue()).append(" has been already set").toString());
            return;
        } else
        {
            valueLevelMap.put(mdcvaluelevelpair.getValue(), mdcvaluelevelpair.getLevel());
            return;
        }
    }

    public FilterReply decide(Marker marker, Logger logger, Level level, String s, Object aobj[], Throwable throwable)
    {
        logger = MDC.get(key);
        if (!isStarted())
        {
            return FilterReply.NEUTRAL;
        }
        marker = null;
        if (logger != null)
        {
            marker = (Level)valueLevelMap.get(logger);
        }
        logger = marker;
        if (marker == null)
        {
            logger = defaultThreshold;
        }
        if (level.isGreaterOrEqual(logger))
        {
            return onHigherOrEqual;
        } else
        {
            return onLower;
        }
    }

    public Level getDefaultThreshold()
    {
        return defaultThreshold;
    }

    public String getKey()
    {
        return key;
    }

    public FilterReply getOnHigherOrEqual()
    {
        return onHigherOrEqual;
    }

    public FilterReply getOnLower()
    {
        return onLower;
    }

    public void setDefaultThreshold(Level level)
    {
        defaultThreshold = level;
    }

    public void setKey(String s)
    {
        key = s;
    }

    public void setOnHigherOrEqual(FilterReply filterreply)
    {
        onHigherOrEqual = filterreply;
    }

    public void setOnLower(FilterReply filterreply)
    {
        onLower = filterreply;
    }

    public void start()
    {
        if (key == null)
        {
            addError("No key name was specified");
        }
        super.start();
    }
}
