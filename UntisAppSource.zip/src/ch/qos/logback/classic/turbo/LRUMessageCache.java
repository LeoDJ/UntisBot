// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.classic.turbo;

import java.util.LinkedHashMap;

class LRUMessageCache extends LinkedHashMap
{

    private static final long serialVersionUID = 1L;
    final int cacheSize;

    LRUMessageCache(int i)
    {
        super((int)((float)i * 1.333333F), 0.75F, true);
        if (i < 1)
        {
            throw new IllegalArgumentException("Cache size cannot be smaller than 1");
        } else
        {
            cacheSize = i;
            return;
        }
    }

    public void clear()
    {
        this;
        JVM INSTR monitorenter ;
        super.clear();
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    int getMessageCountAndThenIncrement(String s)
    {
        if (s == null)
        {
            return 0;
        }
        this;
        JVM INSTR monitorenter ;
        Integer integer = (Integer)super.get(s);
        if (integer != null)
        {
            break MISSING_BLOCK_LABEL_40;
        }
        integer = Integer.valueOf(0);
_L1:
        super.put(s, integer);
        this;
        JVM INSTR monitorexit ;
        return integer.intValue();
        integer = Integer.valueOf(integer.intValue() + 1);
          goto _L1
        s;
        this;
        JVM INSTR monitorexit ;
        throw s;
    }

    protected boolean removeEldestEntry(java.util.Map.Entry entry)
    {
        return size() > cacheSize;
    }
}
