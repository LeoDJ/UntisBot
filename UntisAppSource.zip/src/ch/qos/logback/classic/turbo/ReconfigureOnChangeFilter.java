// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.classic.turbo;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.joran.JoranConfigurator;
import ch.qos.logback.core.Context;
import ch.qos.logback.core.joran.spi.ConfigurationWatchList;
import ch.qos.logback.core.joran.spi.JoranException;
import ch.qos.logback.core.joran.util.ConfigurationWatchListUtil;
import ch.qos.logback.core.spi.FilterReply;
import ch.qos.logback.core.status.StatusUtil;
import java.net.URL;
import java.util.List;
import java.util.concurrent.ExecutorService;
import org.slf4j.Marker;

// Referenced classes of package ch.qos.logback.classic.turbo:
//            TurboFilter

public class ReconfigureOnChangeFilter extends TurboFilter
{
    class ReconfiguringThread
        implements Runnable
    {

        final ReconfigureOnChangeFilter this$0;

        private void fallbackConfiguration(LoggerContext loggercontext, List list, URL url)
        {
            JoranConfigurator joranconfigurator = new JoranConfigurator();
            joranconfigurator.setContext(doConfigure);
            if (list != null)
            {
                addWarn("Falling back to previously registered safe configuration.");
                try
                {
                    loggercontext.reset();
                    JoranConfigurator.informContextOfURLUsedForConfiguration(doConfigure, url);
                    joranconfigurator.doConfigure(list);
                    addInfo("Re-registering previous fallback configuration once more as a fallback configuration point");
                    joranconfigurator.registerSafeConfiguration();
                    return;
                }
                // Misplaced declaration of an exception variable
                catch (LoggerContext loggercontext)
                {
                    addError("Unexpected exception thrown by a configuration considered safe.", loggercontext);
                }
                return;
            } else
            {
                addWarn("No previous configuration to fall back on.");
                return;
            }
        }

        private void performXMLConfiguration(LoggerContext loggercontext)
        {
            JoranConfigurator joranconfigurator = new JoranConfigurator();
            joranconfigurator.setContext(doConfigure);
            StatusUtil statusutil = new StatusUtil(doConfigure);
            List list = joranconfigurator.recallSafeConfiguration();
            URL url = ConfigurationWatchListUtil.getMainWatchURL(doConfigure);
            loggercontext.reset();
            long l = System.currentTimeMillis();
            try
            {
                joranconfigurator.doConfigure(mainConfigurationURL);
                if (statusutil.hasXMLParsingErrors(l))
                {
                    fallbackConfiguration(loggercontext, list, url);
                }
                return;
            }
            catch (JoranException joranexception)
            {
                fallbackConfiguration(loggercontext, list, url);
            }
        }

        public void run()
        {
            if (mainConfigurationURL == null)
            {
                addInfo("Due to missing top level configuration file, skipping reconfiguration");
            } else
            {
                LoggerContext loggercontext = (LoggerContext)doConfigure;
                addInfo((new StringBuilder()).append("Will reset and reconfigure context named [").append(doConfigure.getName()).append("]").toString());
                if (mainConfigurationURL.toString().endsWith("xml"))
                {
                    performXMLConfiguration(loggercontext);
                    return;
                }
            }
        }

        ReconfiguringThread()
        {
            this$0 = ReconfigureOnChangeFilter.this;
            super();
        }
    }


    public static final long DEFAULT_REFRESH_PERIOD = 60000L;
    private static final long MASK_DECREASE_THRESHOLD = 800L;
    private static final long MASK_INCREASE_THRESHOLD = 100L;
    private static final int MAX_MASK = 65535;
    ConfigurationWatchList configurationWatchList;
    private long invocationCounter;
    private volatile long lastMaskCheck;
    URL mainConfigurationURL;
    private volatile long mask;
    protected volatile long nextCheck;
    long refreshPeriod;

    public ReconfigureOnChangeFilter()
    {
        refreshPeriod = 60000L;
        invocationCounter = 0L;
        mask = 15L;
        lastMaskCheck = System.currentTimeMillis();
    }

    private void updateMaskIfNecessary(long l)
    {
        long l1 = l - lastMaskCheck;
        lastMaskCheck = l;
        if (l1 < 100L && mask < 65535L)
        {
            mask = mask << 1 | 1L;
        } else
        if (l1 > 800L)
        {
            mask = mask >>> 2;
            return;
        }
    }

    protected boolean changeDetected(long l)
    {
        if (l >= nextCheck)
        {
            updateNextCheck(l);
            return configurationWatchList.changeDetected();
        } else
        {
            return false;
        }
    }

    public FilterReply decide(Marker marker, Logger logger, Level level, String s, Object aobj[], Throwable throwable)
    {
        if (!isStarted())
        {
            return FilterReply.NEUTRAL;
        }
        long l = invocationCounter;
        invocationCounter = 1L + l;
        if ((l & mask) != mask)
        {
            return FilterReply.NEUTRAL;
        }
        l = System.currentTimeMillis();
        synchronized (configurationWatchList)
        {
            updateMaskIfNecessary(l);
            if (changeDetected(l))
            {
                disableSubsequentReconfiguration();
                detachReconfigurationToNewThread();
            }
        }
        return FilterReply.NEUTRAL;
        logger;
        marker;
        JVM INSTR monitorexit ;
        throw logger;
    }

    void detachReconfigurationToNewThread()
    {
        addInfo((new StringBuilder()).append("Detected change in [").append(configurationWatchList.getCopyOfFileWatchList()).append("]").toString());
        context.getExecutorService().submit(new ReconfiguringThread());
    }

    void disableSubsequentReconfiguration()
    {
        nextCheck = 0x7fffffffffffffffL;
    }

    public long getRefreshPeriod()
    {
        return refreshPeriod;
    }

    public void setRefreshPeriod(long l)
    {
        refreshPeriod = l;
    }

    public void start()
    {
        configurationWatchList = ConfigurationWatchListUtil.getConfigurationWatchList(context);
        if (configurationWatchList != null)
        {
            mainConfigurationURL = configurationWatchList.getMainURL();
            if (mainConfigurationURL == null)
            {
                addWarn("Due to missing top level configuration file, automatic reconfiguration is impossible.");
                return;
            }
            List list = configurationWatchList.getCopyOfFileWatchList();
            long l = refreshPeriod / 1000L;
            addInfo((new StringBuilder()).append("Will scan for changes in [").append(list).append("] every ").append(l).append(" seconds. ").toString());
            synchronized (configurationWatchList)
            {
                updateNextCheck(System.currentTimeMillis());
            }
            super.start();
            return;
        } else
        {
            addWarn("Empty ConfigurationWatchList in context");
            return;
        }
        exception;
        configurationwatchlist;
        JVM INSTR monitorexit ;
        throw exception;
    }

    public String toString()
    {
        return (new StringBuilder()).append("ReconfigureOnChangeFilter{invocationCounter=").append(invocationCounter).append('}').toString();
    }

    void updateNextCheck(long l)
    {
        nextCheck = refreshPeriod + l;
    }







}
