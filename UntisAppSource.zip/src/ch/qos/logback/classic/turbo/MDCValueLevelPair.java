// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.classic.turbo;

import ch.qos.logback.classic.Level;

public class MDCValueLevelPair
{

    private Level level;
    private String value;

    public MDCValueLevelPair()
    {
    }

    public Level getLevel()
    {
        return level;
    }

    public String getValue()
    {
        return value;
    }

    public void setLevel(Level level1)
    {
        level = level1;
    }

    public void setValue(String s)
    {
        value = s;
    }
}
