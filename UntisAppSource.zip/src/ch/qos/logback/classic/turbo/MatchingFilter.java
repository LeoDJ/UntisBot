// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.classic.turbo;

import ch.qos.logback.core.spi.FilterReply;

// Referenced classes of package ch.qos.logback.classic.turbo:
//            TurboFilter

public abstract class MatchingFilter extends TurboFilter
{

    protected FilterReply onMatch;
    protected FilterReply onMismatch;

    public MatchingFilter()
    {
        onMatch = FilterReply.NEUTRAL;
        onMismatch = FilterReply.NEUTRAL;
    }

    public final void setOnMatch(String s)
    {
        if ("NEUTRAL".equals(s))
        {
            onMatch = FilterReply.NEUTRAL;
        } else
        {
            if ("ACCEPT".equals(s))
            {
                onMatch = FilterReply.ACCEPT;
                return;
            }
            if ("DENY".equals(s))
            {
                onMatch = FilterReply.DENY;
                return;
            }
        }
    }

    public final void setOnMismatch(String s)
    {
        if ("NEUTRAL".equals(s))
        {
            onMismatch = FilterReply.NEUTRAL;
        } else
        {
            if ("ACCEPT".equals(s))
            {
                onMismatch = FilterReply.ACCEPT;
                return;
            }
            if ("DENY".equals(s))
            {
                onMismatch = FilterReply.DENY;
                return;
            }
        }
    }
}
