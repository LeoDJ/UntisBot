// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.classic.jul;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;

public class JULHelper
{

    public JULHelper()
    {
    }

    public static java.util.logging.Level asJULLevel(Level level)
    {
        if (level == null)
        {
            throw new IllegalArgumentException("Unexpected level [null]");
        }
        switch (level.levelInt)
        {
        default:
            throw new IllegalArgumentException((new StringBuilder()).append("Unexpected level [").append(level).append("]").toString());

        case -2147483648: 
            return java.util.logging.Level.ALL;

        case 5000: 
            return java.util.logging.Level.FINEST;

        case 10000: 
            return java.util.logging.Level.FINE;

        case 20000: 
            return java.util.logging.Level.INFO;

        case 30000: 
            return java.util.logging.Level.WARNING;

        case 40000: 
            return java.util.logging.Level.SEVERE;

        case 2147483647: 
            return java.util.logging.Level.OFF;
        }
    }

    public static java.util.logging.Logger asJULLogger(Logger logger)
    {
        return asJULLogger(logger.getName());
    }

    public static java.util.logging.Logger asJULLogger(String s)
    {
        return java.util.logging.Logger.getLogger(asJULLoggerName(s));
    }

    public static String asJULLoggerName(String s)
    {
        String s1 = s;
        if ("ROOT".equals(s))
        {
            s1 = "";
        }
        return s1;
    }

    public static final boolean isRegularNonRootLogger(java.util.logging.Logger logger)
    {
        while (logger == null || logger.getName().equals("")) 
        {
            return false;
        }
        return true;
    }

    public static final boolean isRoot(java.util.logging.Logger logger)
    {
        if (logger == null)
        {
            return false;
        } else
        {
            return logger.getName().equals("");
        }
    }
}
