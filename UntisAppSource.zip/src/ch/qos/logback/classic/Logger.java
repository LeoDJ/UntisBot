// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.classic;

import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.classic.spi.LoggingEvent;
import ch.qos.logback.classic.util.LoggerNameUtil;
import ch.qos.logback.core.Appender;
import ch.qos.logback.core.spi.AppenderAttachable;
import ch.qos.logback.core.spi.AppenderAttachableImpl;
import ch.qos.logback.core.spi.FilterReply;
import java.io.ObjectStreamException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import org.slf4j.LoggerFactory;
import org.slf4j.Marker;
import org.slf4j.spi.LocationAwareLogger;

// Referenced classes of package ch.qos.logback.classic:
//            LoggerContext, Level

public final class Logger
    implements org.slf4j.Logger, LocationAwareLogger, AppenderAttachable, Serializable
{

    private static final int DEFAULT_CHILD_ARRAY_SIZE = 5;
    public static final String FQCN = ch/qos/logback/classic/Logger.getName();
    private static final long serialVersionUID = 0x4bb1f08f92d542c2L;
    private transient AppenderAttachableImpl aai;
    private transient boolean additive;
    private transient List childrenList;
    private transient int effectiveLevelInt;
    private transient Level level;
    final transient LoggerContext loggerContext;
    private String name;
    private transient Logger parent;

    Logger(String s, Logger logger, LoggerContext loggercontext)
    {
        additive = true;
        name = s;
        parent = logger;
        loggerContext = loggercontext;
    }

    private int appendLoopOnAppenders(ILoggingEvent iloggingevent)
    {
        if (aai != null)
        {
            return aai.appendLoopOnAppenders(iloggingevent);
        } else
        {
            return 0;
        }
    }

    private void buildLoggingEventAndAppend(String s, Marker marker, Level level1, String s1, Object aobj[], Throwable throwable)
    {
        s = new LoggingEvent(s, this, level1, s1, throwable, aobj);
        s.setMarker(marker);
        callAppenders(s);
    }

    private FilterReply callTurboFilters(Marker marker, Level level1)
    {
        return loggerContext.getTurboFilterChainDecision_0_3OrMore(marker, this, level1, null, null, null);
    }

    private void filterAndLog_0_Or3Plus(String s, Marker marker, Level level1, String s1, Object aobj[], Throwable throwable)
    {
        FilterReply filterreply = loggerContext.getTurboFilterChainDecision_0_3OrMore(marker, this, level1, s1, aobj, throwable);
        if (filterreply != FilterReply.NEUTRAL ? filterreply == FilterReply.DENY : effectiveLevelInt > level1.levelInt)
        {
            return;
        } else
        {
            buildLoggingEventAndAppend(s, marker, level1, s1, aobj, throwable);
            return;
        }
    }

    private void filterAndLog_1(String s, Marker marker, Level level1, String s1, Object obj, Throwable throwable)
    {
        FilterReply filterreply = loggerContext.getTurboFilterChainDecision_1(marker, this, level1, s1, obj, throwable);
        if (filterreply != FilterReply.NEUTRAL ? filterreply == FilterReply.DENY : effectiveLevelInt > level1.levelInt)
        {
            return;
        } else
        {
            buildLoggingEventAndAppend(s, marker, level1, s1, new Object[] {
                obj
            }, throwable);
            return;
        }
    }

    private void filterAndLog_2(String s, Marker marker, Level level1, String s1, Object obj, Object obj1, Throwable throwable)
    {
        FilterReply filterreply = loggerContext.getTurboFilterChainDecision_2(marker, this, level1, s1, obj, obj1, throwable);
        if (filterreply != FilterReply.NEUTRAL ? filterreply == FilterReply.DENY : effectiveLevelInt > level1.levelInt)
        {
            return;
        } else
        {
            buildLoggingEventAndAppend(s, marker, level1, s1, new Object[] {
                obj, obj1
            }, throwable);
            return;
        }
    }

    private void handleParentLevelChange(int i)
    {
        this;
        JVM INSTR monitorenter ;
        if (level != null) goto _L2; else goto _L1
_L1:
        effectiveLevelInt = i;
        if (childrenList == null) goto _L2; else goto _L3
_L3:
        int k = childrenList.size();
        int j = 0;
_L4:
        if (j >= k)
        {
            break; /* Loop/switch isn't completed */
        }
        ((Logger)childrenList.get(j)).handleParentLevelChange(i);
        j++;
        if (true) goto _L4; else goto _L2
_L2:
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    private boolean isRootLogger()
    {
        return parent == null;
    }

    private void localLevelReset()
    {
        effectiveLevelInt = 10000;
        if (isRootLogger())
        {
            level = Level.DEBUG;
            return;
        } else
        {
            level = null;
            return;
        }
    }

    public void addAppender(Appender appender)
    {
        this;
        JVM INSTR monitorenter ;
        if (aai == null)
        {
            aai = new AppenderAttachableImpl();
        }
        aai.addAppender(appender);
        this;
        JVM INSTR monitorexit ;
        return;
        appender;
        throw appender;
    }

    public void callAppenders(ILoggingEvent iloggingevent)
    {
        int i = 0;
        Logger logger = this;
        do
        {
label0:
            {
                int j = i;
                if (logger != null)
                {
                    i += logger.appendLoopOnAppenders(iloggingevent);
                    if (logger.additive)
                    {
                        break label0;
                    }
                    j = i;
                }
                if (j == 0)
                {
                    loggerContext.noAppenderDefinedWarning(this);
                }
                return;
            }
            logger = logger.parent;
        } while (true);
    }

    Logger createChildByLastNamePart(String s)
    {
        if (LoggerNameUtil.getFirstSeparatorIndexOf(s) != -1)
        {
            throw new IllegalArgumentException((new StringBuilder()).append("Child name [").append(s).append(" passed as parameter, may not include [").append('.').append("]").toString());
        }
        if (childrenList == null)
        {
            childrenList = new ArrayList();
        }
        if (isRootLogger())
        {
            s = new Logger(s, this, loggerContext);
        } else
        {
            s = new Logger((new StringBuilder()).append(name).append('.').append(s).toString(), this, loggerContext);
        }
        childrenList.add(s);
        s.effectiveLevelInt = effectiveLevelInt;
        return s;
    }

    Logger createChildByName(String s)
    {
        if (LoggerNameUtil.getSeparatorIndexOf(s, name.length() + 1) != -1)
        {
            throw new IllegalArgumentException((new StringBuilder()).append("For logger [").append(name).append("] child name [").append(s).append(" passed as parameter, may not include '.' after index").append(name.length() + 1).toString());
        }
        if (childrenList == null)
        {
            childrenList = new ArrayList(5);
        }
        s = new Logger(s, this, loggerContext);
        childrenList.add(s);
        s.effectiveLevelInt = effectiveLevelInt;
        return s;
    }

    public void debug(String s)
    {
        filterAndLog_0_Or3Plus(FQCN, null, Level.DEBUG, s, null, null);
    }

    public void debug(String s, Object obj)
    {
        filterAndLog_1(FQCN, null, Level.DEBUG, s, obj, null);
    }

    public void debug(String s, Object obj, Object obj1)
    {
        filterAndLog_2(FQCN, null, Level.DEBUG, s, obj, obj1, null);
    }

    public void debug(String s, Throwable throwable)
    {
        filterAndLog_0_Or3Plus(FQCN, null, Level.DEBUG, s, null, throwable);
    }

    public void debug(String s, Object aobj[])
    {
        filterAndLog_0_Or3Plus(FQCN, null, Level.DEBUG, s, aobj, null);
    }

    public void debug(Marker marker, String s)
    {
        filterAndLog_0_Or3Plus(FQCN, marker, Level.DEBUG, s, null, null);
    }

    public void debug(Marker marker, String s, Object obj)
    {
        filterAndLog_1(FQCN, marker, Level.DEBUG, s, obj, null);
    }

    public void debug(Marker marker, String s, Object obj, Object obj1)
    {
        filterAndLog_2(FQCN, marker, Level.DEBUG, s, obj, obj1, null);
    }

    public void debug(Marker marker, String s, Throwable throwable)
    {
        filterAndLog_0_Or3Plus(FQCN, marker, Level.DEBUG, s, null, throwable);
    }

    public void debug(Marker marker, String s, Object aobj[])
    {
        filterAndLog_0_Or3Plus(FQCN, marker, Level.DEBUG, s, aobj, null);
    }

    public void detachAndStopAllAppenders()
    {
        if (aai != null)
        {
            aai.detachAndStopAllAppenders();
        }
    }

    public boolean detachAppender(Appender appender)
    {
        if (aai == null)
        {
            return false;
        } else
        {
            return aai.detachAppender(appender);
        }
    }

    public boolean detachAppender(String s)
    {
        if (aai == null)
        {
            return false;
        } else
        {
            return aai.detachAppender(s);
        }
    }

    public void error(String s)
    {
        filterAndLog_0_Or3Plus(FQCN, null, Level.ERROR, s, null, null);
    }

    public void error(String s, Object obj)
    {
        filterAndLog_1(FQCN, null, Level.ERROR, s, obj, null);
    }

    public void error(String s, Object obj, Object obj1)
    {
        filterAndLog_2(FQCN, null, Level.ERROR, s, obj, obj1, null);
    }

    public void error(String s, Throwable throwable)
    {
        filterAndLog_0_Or3Plus(FQCN, null, Level.ERROR, s, null, throwable);
    }

    public void error(String s, Object aobj[])
    {
        filterAndLog_0_Or3Plus(FQCN, null, Level.ERROR, s, aobj, null);
    }

    public void error(Marker marker, String s)
    {
        filterAndLog_0_Or3Plus(FQCN, marker, Level.ERROR, s, null, null);
    }

    public void error(Marker marker, String s, Object obj)
    {
        filterAndLog_1(FQCN, marker, Level.ERROR, s, obj, null);
    }

    public void error(Marker marker, String s, Object obj, Object obj1)
    {
        filterAndLog_2(FQCN, marker, Level.ERROR, s, obj, obj1, null);
    }

    public void error(Marker marker, String s, Throwable throwable)
    {
        filterAndLog_0_Or3Plus(FQCN, marker, Level.ERROR, s, null, throwable);
    }

    public void error(Marker marker, String s, Object aobj[])
    {
        filterAndLog_0_Or3Plus(FQCN, marker, Level.ERROR, s, aobj, null);
    }

    public Appender getAppender(String s)
    {
        if (aai == null)
        {
            return null;
        } else
        {
            return aai.getAppender(s);
        }
    }

    Logger getChildByName(String s)
    {
        if (childrenList != null) goto _L2; else goto _L1
_L1:
        Logger logger = null;
_L4:
        return logger;
_L2:
        int j = childrenList.size();
        int i = 0;
label0:
        do
        {
label1:
            {
                if (i >= j)
                {
                    break label1;
                }
                Logger logger1 = (Logger)childrenList.get(i);
                logger = logger1;
                if (s.equals(logger1.getName()))
                {
                    break label0;
                }
                i++;
            }
        } while (true);
        if (true) goto _L4; else goto _L3
_L3:
        return null;
    }

    public Level getEffectiveLevel()
    {
        return Level.toLevel(effectiveLevelInt);
    }

    int getEffectiveLevelInt()
    {
        return effectiveLevelInt;
    }

    public Level getLevel()
    {
        return level;
    }

    public LoggerContext getLoggerContext()
    {
        return loggerContext;
    }

    public String getName()
    {
        return name;
    }

    public void info(String s)
    {
        filterAndLog_0_Or3Plus(FQCN, null, Level.INFO, s, null, null);
    }

    public void info(String s, Object obj)
    {
        filterAndLog_1(FQCN, null, Level.INFO, s, obj, null);
    }

    public void info(String s, Object obj, Object obj1)
    {
        filterAndLog_2(FQCN, null, Level.INFO, s, obj, obj1, null);
    }

    public void info(String s, Throwable throwable)
    {
        filterAndLog_0_Or3Plus(FQCN, null, Level.INFO, s, null, throwable);
    }

    public void info(String s, Object aobj[])
    {
        filterAndLog_0_Or3Plus(FQCN, null, Level.INFO, s, aobj, null);
    }

    public void info(Marker marker, String s)
    {
        filterAndLog_0_Or3Plus(FQCN, marker, Level.INFO, s, null, null);
    }

    public void info(Marker marker, String s, Object obj)
    {
        filterAndLog_1(FQCN, marker, Level.INFO, s, obj, null);
    }

    public void info(Marker marker, String s, Object obj, Object obj1)
    {
        filterAndLog_2(FQCN, marker, Level.INFO, s, obj, obj1, null);
    }

    public void info(Marker marker, String s, Throwable throwable)
    {
        filterAndLog_0_Or3Plus(FQCN, marker, Level.INFO, s, null, throwable);
    }

    public void info(Marker marker, String s, Object aobj[])
    {
        filterAndLog_0_Or3Plus(FQCN, marker, Level.INFO, s, aobj, null);
    }

    public boolean isAdditive()
    {
        return additive;
    }

    public boolean isAttached(Appender appender)
    {
        if (aai == null)
        {
            return false;
        } else
        {
            return aai.isAttached(appender);
        }
    }

    public boolean isDebugEnabled()
    {
        return isDebugEnabled(null);
    }

    public boolean isDebugEnabled(Marker marker)
    {
        marker = callTurboFilters(marker, Level.DEBUG);
        if (marker != FilterReply.NEUTRAL) goto _L2; else goto _L1
_L1:
        if (effectiveLevelInt > 10000) goto _L4; else goto _L3
_L3:
        return true;
_L4:
        return false;
_L2:
        if (marker == FilterReply.DENY)
        {
            return false;
        }
        if (marker != FilterReply.ACCEPT)
        {
            throw new IllegalStateException((new StringBuilder()).append("Unknown FilterReply value: ").append(marker).toString());
        }
        if (true) goto _L3; else goto _L5
_L5:
    }

    public boolean isEnabledFor(Level level1)
    {
        return isEnabledFor(null, level1);
    }

    public boolean isEnabledFor(Marker marker, Level level1)
    {
        marker = callTurboFilters(marker, level1);
        if (marker != FilterReply.NEUTRAL) goto _L2; else goto _L1
_L1:
        if (effectiveLevelInt > level1.levelInt) goto _L4; else goto _L3
_L3:
        return true;
_L4:
        return false;
_L2:
        if (marker == FilterReply.DENY)
        {
            return false;
        }
        if (marker != FilterReply.ACCEPT)
        {
            throw new IllegalStateException((new StringBuilder()).append("Unknown FilterReply value: ").append(marker).toString());
        }
        if (true) goto _L3; else goto _L5
_L5:
    }

    public boolean isErrorEnabled()
    {
        return isErrorEnabled(null);
    }

    public boolean isErrorEnabled(Marker marker)
    {
        marker = callTurboFilters(marker, Level.ERROR);
        if (marker != FilterReply.NEUTRAL) goto _L2; else goto _L1
_L1:
        if (effectiveLevelInt > 40000) goto _L4; else goto _L3
_L3:
        return true;
_L4:
        return false;
_L2:
        if (marker == FilterReply.DENY)
        {
            return false;
        }
        if (marker != FilterReply.ACCEPT)
        {
            throw new IllegalStateException((new StringBuilder()).append("Unknown FilterReply value: ").append(marker).toString());
        }
        if (true) goto _L3; else goto _L5
_L5:
    }

    public boolean isInfoEnabled()
    {
        return isInfoEnabled(null);
    }

    public boolean isInfoEnabled(Marker marker)
    {
        marker = callTurboFilters(marker, Level.INFO);
        if (marker != FilterReply.NEUTRAL) goto _L2; else goto _L1
_L1:
        if (effectiveLevelInt > 20000) goto _L4; else goto _L3
_L3:
        return true;
_L4:
        return false;
_L2:
        if (marker == FilterReply.DENY)
        {
            return false;
        }
        if (marker != FilterReply.ACCEPT)
        {
            throw new IllegalStateException((new StringBuilder()).append("Unknown FilterReply value: ").append(marker).toString());
        }
        if (true) goto _L3; else goto _L5
_L5:
    }

    public boolean isTraceEnabled()
    {
        return isTraceEnabled(null);
    }

    public boolean isTraceEnabled(Marker marker)
    {
        marker = callTurboFilters(marker, Level.TRACE);
        if (marker != FilterReply.NEUTRAL) goto _L2; else goto _L1
_L1:
        if (effectiveLevelInt > 5000) goto _L4; else goto _L3
_L3:
        return true;
_L4:
        return false;
_L2:
        if (marker == FilterReply.DENY)
        {
            return false;
        }
        if (marker != FilterReply.ACCEPT)
        {
            throw new IllegalStateException((new StringBuilder()).append("Unknown FilterReply value: ").append(marker).toString());
        }
        if (true) goto _L3; else goto _L5
_L5:
    }

    public boolean isWarnEnabled()
    {
        return isWarnEnabled(null);
    }

    public boolean isWarnEnabled(Marker marker)
    {
        marker = callTurboFilters(marker, Level.WARN);
        if (marker != FilterReply.NEUTRAL) goto _L2; else goto _L1
_L1:
        if (effectiveLevelInt > 30000) goto _L4; else goto _L3
_L3:
        return true;
_L4:
        return false;
_L2:
        if (marker == FilterReply.DENY)
        {
            return false;
        }
        if (marker != FilterReply.ACCEPT)
        {
            throw new IllegalStateException((new StringBuilder()).append("Unknown FilterReply value: ").append(marker).toString());
        }
        if (true) goto _L3; else goto _L5
_L5:
    }

    public Iterator iteratorForAppenders()
    {
        if (aai == null)
        {
            return Collections.EMPTY_LIST.iterator();
        } else
        {
            return aai.iteratorForAppenders();
        }
    }

    public void log(Marker marker, String s, int i, String s1, Object aobj[], Throwable throwable)
    {
        filterAndLog_0_Or3Plus(s, marker, Level.fromLocationAwareLoggerInteger(i), s1, aobj, throwable);
    }

    protected Object readResolve()
        throws ObjectStreamException
    {
        return LoggerFactory.getLogger(getName());
    }

    void recursiveReset()
    {
        detachAndStopAllAppenders();
        localLevelReset();
        additive = true;
        if (childrenList != null)
        {
            Iterator iterator = childrenList.iterator();
            while (iterator.hasNext()) 
            {
                ((Logger)iterator.next()).recursiveReset();
            }
        }
    }

    public void setAdditive(boolean flag)
    {
        additive = flag;
    }

    public void setLevel(Level level1)
    {
        this;
        JVM INSTR monitorenter ;
        Level level2 = level;
        if (level2 != level1) goto _L2; else goto _L1
_L1:
        this;
        JVM INSTR monitorexit ;
        return;
_L2:
        if (level1 != null)
        {
            break MISSING_BLOCK_LABEL_42;
        }
        if (isRootLogger())
        {
            throw new IllegalArgumentException("The level of the root logger cannot be set to null");
        }
        break MISSING_BLOCK_LABEL_42;
        level1;
        this;
        JVM INSTR monitorexit ;
        throw level1;
        level = level1;
        if (level1 != null) goto _L4; else goto _L3
_L3:
        effectiveLevelInt = parent.effectiveLevelInt;
        level1 = parent.getEffectiveLevel();
_L8:
        if (childrenList == null) goto _L6; else goto _L5
_L5:
        int j = childrenList.size();
        int i = 0;
_L7:
        if (i >= j)
        {
            break; /* Loop/switch isn't completed */
        }
        ((Logger)childrenList.get(i)).handleParentLevelChange(effectiveLevelInt);
        i++;
        if (true) goto _L7; else goto _L6
_L4:
        effectiveLevelInt = level1.levelInt;
          goto _L8
_L6:
        loggerContext.fireOnLevelChange(this, level1);
          goto _L1
    }

    public String toString()
    {
        return (new StringBuilder()).append("Logger[").append(name).append("]").toString();
    }

    public void trace(String s)
    {
        filterAndLog_0_Or3Plus(FQCN, null, Level.TRACE, s, null, null);
    }

    public void trace(String s, Object obj)
    {
        filterAndLog_1(FQCN, null, Level.TRACE, s, obj, null);
    }

    public void trace(String s, Object obj, Object obj1)
    {
        filterAndLog_2(FQCN, null, Level.TRACE, s, obj, obj1, null);
    }

    public void trace(String s, Throwable throwable)
    {
        filterAndLog_0_Or3Plus(FQCN, null, Level.TRACE, s, null, throwable);
    }

    public void trace(String s, Object aobj[])
    {
        filterAndLog_0_Or3Plus(FQCN, null, Level.TRACE, s, aobj, null);
    }

    public void trace(Marker marker, String s)
    {
        filterAndLog_0_Or3Plus(FQCN, marker, Level.TRACE, s, null, null);
    }

    public void trace(Marker marker, String s, Object obj)
    {
        filterAndLog_1(FQCN, marker, Level.TRACE, s, obj, null);
    }

    public void trace(Marker marker, String s, Object obj, Object obj1)
    {
        filterAndLog_2(FQCN, marker, Level.TRACE, s, obj, obj1, null);
    }

    public void trace(Marker marker, String s, Throwable throwable)
    {
        filterAndLog_0_Or3Plus(FQCN, marker, Level.TRACE, s, null, throwable);
    }

    public void trace(Marker marker, String s, Object aobj[])
    {
        filterAndLog_0_Or3Plus(FQCN, marker, Level.TRACE, s, aobj, null);
    }

    public void warn(String s)
    {
        filterAndLog_0_Or3Plus(FQCN, null, Level.WARN, s, null, null);
    }

    public void warn(String s, Object obj)
    {
        filterAndLog_1(FQCN, null, Level.WARN, s, obj, null);
    }

    public void warn(String s, Object obj, Object obj1)
    {
        filterAndLog_2(FQCN, null, Level.WARN, s, obj, obj1, null);
    }

    public void warn(String s, Throwable throwable)
    {
        filterAndLog_0_Or3Plus(FQCN, null, Level.WARN, s, null, throwable);
    }

    public void warn(String s, Object aobj[])
    {
        filterAndLog_0_Or3Plus(FQCN, null, Level.WARN, s, aobj, null);
    }

    public void warn(Marker marker, String s)
    {
        filterAndLog_0_Or3Plus(FQCN, marker, Level.WARN, s, null, null);
    }

    public void warn(Marker marker, String s, Object obj)
    {
        filterAndLog_1(FQCN, marker, Level.WARN, s, obj, null);
    }

    public void warn(Marker marker, String s, Object obj, Object obj1)
    {
        filterAndLog_2(FQCN, marker, Level.WARN, s, obj, obj1, null);
    }

    public void warn(Marker marker, String s, Throwable throwable)
    {
        filterAndLog_0_Or3Plus(FQCN, marker, Level.WARN, s, null, throwable);
    }

    public void warn(Marker marker, String s, Object aobj[])
    {
        filterAndLog_0_Or3Plus(FQCN, marker, Level.WARN, s, aobj, null);
    }

}
