// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.classic.spi;

import ch.qos.logback.core.CoreConstants;

// Referenced classes of package ch.qos.logback.classic.spi:
//            ThrowableProxy, StackTraceElementProxy, IThrowableProxy, ClassPackagingData

public class ThrowableProxyUtil
{

    private static final int BUILDER_CAPACITY = 2048;
    public static final int REGULAR_EXCEPTION_INDENT = 1;
    public static final int SUPPRESSED_EXCEPTION_INDENT = 1;

    public ThrowableProxyUtil()
    {
    }

    public static String asString(IThrowableProxy ithrowableproxy)
    {
        StringBuilder stringbuilder = new StringBuilder(2048);
        recursiveAppend(stringbuilder, null, 1, ithrowableproxy);
        return stringbuilder.toString();
    }

    public static void build(ThrowableProxy throwableproxy, Throwable throwable, ThrowableProxy throwableproxy1)
    {
        throwable = throwable.getStackTrace();
        int i = -1;
        if (throwableproxy1 != null)
        {
            i = findNumberOfCommonFrames(throwable, throwableproxy1.getStackTraceElementProxyArray());
        }
        throwableproxy.commonFrames = i;
        throwableproxy.stackTraceElementProxyArray = steArrayToStepArray(throwable);
    }

    static int findNumberOfCommonFrames(StackTraceElement astacktraceelement[], StackTraceElementProxy astacktraceelementproxy[])
    {
        int i;
        int j;
        int l;
        i = 0;
        j = 0;
        l = j;
        if (astacktraceelementproxy == null) goto _L2; else goto _L1
_L1:
        if (astacktraceelement != null) goto _L4; else goto _L3
_L3:
        l = j;
_L2:
        return l;
_L4:
        int k;
        k = astacktraceelement.length - 1;
        j = astacktraceelementproxy.length - 1;
_L8:
        l = i;
        if (k < 0) goto _L2; else goto _L5
_L5:
        l = i;
        if (j < 0) goto _L2; else goto _L6
_L6:
        l = i;
        if (!astacktraceelement[k].equals(astacktraceelementproxy[j].ste)) goto _L2; else goto _L7
_L7:
        i++;
        k--;
        j--;
          goto _L8
    }

    public static void indent(StringBuilder stringbuilder, int i)
    {
        for (int j = 0; j < i; j++)
        {
            stringbuilder.append('\t');
        }

    }

    private static void recursiveAppend(StringBuilder stringbuilder, String s, int i, IThrowableProxy ithrowableproxy)
    {
        if (ithrowableproxy == null)
        {
            return;
        }
        subjoinFirstLine(stringbuilder, s, i, ithrowableproxy);
        stringbuilder.append(CoreConstants.LINE_SEPARATOR);
        subjoinSTEPArray(stringbuilder, i, ithrowableproxy);
        s = ithrowableproxy.getSuppressed();
        if (s != null)
        {
            int k = s.length;
            for (int j = 0; j < k; j++)
            {
                recursiveAppend(stringbuilder, "Suppressed: ", i + 1, s[j]);
            }

        }
        recursiveAppend(stringbuilder, "Caused by: ", i, ithrowableproxy.getCause());
    }

    static StackTraceElementProxy[] steArrayToStepArray(StackTraceElement astacktraceelement[])
    {
        int i = 0;
        if (astacktraceelement == null)
        {
            return new StackTraceElementProxy[0];
        }
        StackTraceElementProxy astacktraceelementproxy[];
        for (astacktraceelementproxy = new StackTraceElementProxy[astacktraceelement.length]; i < astacktraceelementproxy.length; i++)
        {
            astacktraceelementproxy[i] = new StackTraceElementProxy(astacktraceelement[i]);
        }

        return astacktraceelementproxy;
    }

    private static void subjoinExceptionMessage(StringBuilder stringbuilder, IThrowableProxy ithrowableproxy)
    {
        stringbuilder.append(ithrowableproxy.getClassName()).append(": ").append(ithrowableproxy.getMessage());
    }

    public static void subjoinFirstLine(StringBuilder stringbuilder, IThrowableProxy ithrowableproxy)
    {
        if (ithrowableproxy.getCommonFrames() > 0)
        {
            stringbuilder.append("Caused by: ");
        }
        subjoinExceptionMessage(stringbuilder, ithrowableproxy);
    }

    private static void subjoinFirstLine(StringBuilder stringbuilder, String s, int i, IThrowableProxy ithrowableproxy)
    {
        indent(stringbuilder, i - 1);
        if (s != null)
        {
            stringbuilder.append(s);
        }
        subjoinExceptionMessage(stringbuilder, ithrowableproxy);
    }

    public static void subjoinFirstLineRootCauseFirst(StringBuilder stringbuilder, IThrowableProxy ithrowableproxy)
    {
        if (ithrowableproxy.getCause() != null)
        {
            stringbuilder.append("Wrapped by: ");
        }
        subjoinExceptionMessage(stringbuilder, ithrowableproxy);
    }

    public static void subjoinPackagingData(StringBuilder stringbuilder, StackTraceElementProxy stacktraceelementproxy)
    {
        if (stacktraceelementproxy != null)
        {
            stacktraceelementproxy = stacktraceelementproxy.getClassPackagingData();
            if (stacktraceelementproxy != null)
            {
                if (!stacktraceelementproxy.isExact())
                {
                    stringbuilder.append(" ~[");
                } else
                {
                    stringbuilder.append(" [");
                }
                stringbuilder.append(stacktraceelementproxy.getCodeLocation()).append(':').append(stacktraceelementproxy.getVersion()).append(']');
            }
        }
    }

    public static void subjoinSTEP(StringBuilder stringbuilder, StackTraceElementProxy stacktraceelementproxy)
    {
        stringbuilder.append(stacktraceelementproxy.toString());
        subjoinPackagingData(stringbuilder, stacktraceelementproxy);
    }

    public static void subjoinSTEPArray(StringBuilder stringbuilder, int i, IThrowableProxy ithrowableproxy)
    {
        StackTraceElementProxy astacktraceelementproxy[] = ithrowableproxy.getStackTraceElementProxyArray();
        int k = ithrowableproxy.getCommonFrames();
        for (int j = 0; j < astacktraceelementproxy.length - k; j++)
        {
            ithrowableproxy = astacktraceelementproxy[j];
            indent(stringbuilder, i);
            subjoinSTEP(stringbuilder, ithrowableproxy);
            stringbuilder.append(CoreConstants.LINE_SEPARATOR);
        }

        if (k > 0)
        {
            indent(stringbuilder, i);
            stringbuilder.append("... ").append(k).append(" common frames omitted").append(CoreConstants.LINE_SEPARATOR);
        }
    }

    public static void subjoinSTEPArray(StringBuilder stringbuilder, IThrowableProxy ithrowableproxy)
    {
        subjoinSTEPArray(stringbuilder, 1, ithrowableproxy);
    }
}
