// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.classic.spi;

import ch.qos.logback.classic.Logger;
import java.io.Serializable;
import java.util.Comparator;

public class LoggerComparator
    implements Comparator, Serializable
{

    private static final long serialVersionUID = 1L;

    public LoggerComparator()
    {
    }

    public int compare(Logger logger, Logger logger1)
    {
        if (logger.getName().equals(logger1.getName()))
        {
            return 0;
        }
        if (logger.getName().equals("ROOT"))
        {
            return -1;
        }
        if (logger1.getName().equals("ROOT"))
        {
            return 1;
        } else
        {
            return logger.getName().compareTo(logger1.getName());
        }
    }

    public volatile int compare(Object obj, Object obj1)
    {
        return compare((Logger)obj, (Logger)obj1);
    }
}
