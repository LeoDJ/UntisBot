// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.classic.spi;


public class EventArgUtil
{

    public EventArgUtil()
    {
    }

    public static Object[] arrangeArguments(Object aobj[])
    {
        return aobj;
    }

    public static final Throwable extractThrowable(Object aobj[])
    {
        if (aobj == null || aobj.length == 0)
        {
            return null;
        }
        aobj = ((Object []) (aobj[aobj.length - 1]));
        if (aobj instanceof Throwable)
        {
            return (Throwable)aobj;
        } else
        {
            return null;
        }
    }

    public static boolean successfulExtraction(Throwable throwable)
    {
        return throwable != null;
    }

    public static Object[] trimmedCopy(Object aobj[])
    {
        if (aobj == null || aobj.length == 0)
        {
            throw new IllegalStateException("non-sensical empty or null argument array");
        } else
        {
            int i = aobj.length - 1;
            Object aobj1[] = new Object[i];
            System.arraycopy(((Object) (aobj)), 0, ((Object) (aobj1)), 0, i);
            return aobj1;
        }
    }
}
