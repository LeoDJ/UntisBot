// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.classic.util;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import org.slf4j.spi.MDCAdapter;

public final class LogbackMDCAdapter
    implements MDCAdapter
{

    private static final int READ_OPERATION = 2;
    private static final int WRITE_OPERATION = 1;
    final InheritableThreadLocal copyOnInheritThreadLocal = new InheritableThreadLocal();
    final ThreadLocal lastOperation = new ThreadLocal();

    public LogbackMDCAdapter()
    {
    }

    private Map duplicateAndInsertNewMap(Map map)
    {
        Map map1 = Collections.synchronizedMap(new HashMap());
        if (map == null) goto _L2; else goto _L1
_L1:
        map;
        JVM INSTR monitorenter ;
        map1.putAll(map);
        map;
        JVM INSTR monitorexit ;
_L2:
        copyOnInheritThreadLocal.set(map1);
        return map1;
        Exception exception;
        exception;
        map;
        JVM INSTR monitorexit ;
        throw exception;
    }

    private Integer getAndSetLastOperation(int i)
    {
        Integer integer = (Integer)lastOperation.get();
        lastOperation.set(Integer.valueOf(i));
        return integer;
    }

    private boolean wasLastOpReadOrNull(Integer integer)
    {
        return integer == null || integer.intValue() == 2;
    }

    public void clear()
    {
        lastOperation.set(Integer.valueOf(1));
        copyOnInheritThreadLocal.remove();
    }

    public String get(String s)
    {
        Map map = getPropertyMap();
        if (map != null && s != null)
        {
            return (String)map.get(s);
        } else
        {
            return null;
        }
    }

    public Map getCopyOfContextMap()
    {
        lastOperation.set(Integer.valueOf(2));
        Map map = (Map)copyOnInheritThreadLocal.get();
        if (map == null)
        {
            return null;
        } else
        {
            return new HashMap(map);
        }
    }

    public Set getKeys()
    {
        Map map = getPropertyMap();
        if (map != null)
        {
            return map.keySet();
        } else
        {
            return null;
        }
    }

    public Map getPropertyMap()
    {
        lastOperation.set(Integer.valueOf(2));
        return (Map)copyOnInheritThreadLocal.get();
    }

    public void put(String s, String s1)
        throws IllegalArgumentException
    {
        if (s == null)
        {
            throw new IllegalArgumentException("key cannot be null");
        }
        Map map = (Map)copyOnInheritThreadLocal.get();
        if (wasLastOpReadOrNull(getAndSetLastOperation(1)) || map == null)
        {
            duplicateAndInsertNewMap(map).put(s, s1);
            return;
        } else
        {
            map.put(s, s1);
            return;
        }
    }

    public void remove(String s)
    {
        Map map;
        if (s != null)
        {
            if ((map = (Map)copyOnInheritThreadLocal.get()) != null)
            {
                if (wasLastOpReadOrNull(getAndSetLastOperation(1)))
                {
                    duplicateAndInsertNewMap(map).remove(s);
                    return;
                } else
                {
                    map.remove(s);
                    return;
                }
            }
        }
    }

    public void setContextMap(Map map)
    {
        lastOperation.set(Integer.valueOf(1));
        Map map1 = Collections.synchronizedMap(new HashMap());
        map1.putAll(map);
        copyOnInheritThreadLocal.set(map1);
    }
}
