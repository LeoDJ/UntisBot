// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.classic.util;

import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.core.spi.ContextAware;
import ch.qos.logback.core.spi.LifeCycle;
import ch.qos.logback.core.status.StatusListener;
import ch.qos.logback.core.status.StatusManager;
import ch.qos.logback.core.util.OptionHelper;

public class StatusListenerConfigHelper
{

    public StatusListenerConfigHelper()
    {
    }

    private static void addStatusListener(LoggerContext loggercontext, String s)
    {
        initListener(loggercontext, createListenerPerClassName(loggercontext, s));
    }

    private static StatusListener createListenerPerClassName(LoggerContext loggercontext, String s)
    {
        try
        {
            loggercontext = (StatusListener)OptionHelper.instantiateByClassName(s, ch/qos/logback/core/status/StatusListener, loggercontext);
        }
        // Misplaced declaration of an exception variable
        catch (LoggerContext loggercontext)
        {
            loggercontext.printStackTrace();
            return null;
        }
        return loggercontext;
    }

    private static void initListener(LoggerContext loggercontext, StatusListener statuslistener)
    {
        if (statuslistener != null)
        {
            if (statuslistener instanceof ContextAware)
            {
                ((ContextAware)statuslistener).setContext(loggercontext);
            }
            if (statuslistener instanceof LifeCycle)
            {
                ((LifeCycle)statuslistener).start();
            }
            loggercontext.getStatusManager().add(statuslistener);
        }
    }

    static void installIfAsked(LoggerContext loggercontext)
    {
        String s = OptionHelper.getSystemProperty("logback.statusListenerClass");
        if (!OptionHelper.isEmpty(s))
        {
            addStatusListener(loggercontext, s);
        }
    }
}
