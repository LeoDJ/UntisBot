// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.classic.util;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.spi.ILoggingEvent;

public class LevelToSyslogSeverity
{

    public LevelToSyslogSeverity()
    {
    }

    public static int convert(ILoggingEvent iloggingevent)
    {
        iloggingevent = iloggingevent.getLevel();
        switch (((Level) (iloggingevent)).levelInt)
        {
        default:
            throw new IllegalArgumentException((new StringBuilder()).append("Level ").append(iloggingevent).append(" is not a valid level for a printing method").toString());

        case 40000: 
            return 3;

        case 30000: 
            return 4;

        case 20000: 
            return 6;

        case 5000: 
        case 10000: 
            return 7;
        }
    }
}
