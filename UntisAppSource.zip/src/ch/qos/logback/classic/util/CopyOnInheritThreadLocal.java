// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.classic.util;

import java.util.HashMap;

public class CopyOnInheritThreadLocal extends InheritableThreadLocal
{

    public CopyOnInheritThreadLocal()
    {
    }

    protected volatile Object childValue(Object obj)
    {
        return childValue((HashMap)obj);
    }

    protected HashMap childValue(HashMap hashmap)
    {
        if (hashmap == null)
        {
            return null;
        } else
        {
            return new HashMap(hashmap);
        }
    }
}
