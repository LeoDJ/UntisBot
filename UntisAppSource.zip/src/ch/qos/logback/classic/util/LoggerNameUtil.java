// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.classic.util;


public class LoggerNameUtil
{

    public LoggerNameUtil()
    {
    }

    public static int getFirstSeparatorIndexOf(String s)
    {
        return getSeparatorIndexOf(s, 0);
    }

    public static int getSeparatorIndexOf(String s, int i)
    {
        int j = s.indexOf('.', i);
        int k = s.indexOf('$', i);
        if (j == -1 && k == -1)
        {
            i = -1;
        } else
        {
            if (j == -1)
            {
                return k;
            }
            i = j;
            if (k != -1)
            {
                i = j;
                if (j >= k)
                {
                    return k;
                }
            }
        }
        return i;
    }
}
