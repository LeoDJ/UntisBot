// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.classic.android;

import ch.qos.logback.core.Context;
import ch.qos.logback.core.android.CommonPathUtil;
import ch.qos.logback.core.joran.spi.JoranException;
import ch.qos.logback.core.status.StatusManager;
import ch.qos.logback.core.status.WarnStatus;
import ch.qos.logback.core.util.Loader;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

// Referenced classes of package ch.qos.logback.classic.android:
//            ASaxEventRecorder

public class AndroidManifestPropertiesUtil
{

    public AndroidManifestPropertiesUtil()
    {
    }

    public static void setAndroidProperties(Context context)
        throws JoranException
    {
        StatusManager statusmanager;
        Object obj;
        Object obj1;
        obj = new ASaxEventRecorder();
        ((ASaxEventRecorder) (obj)).setFilter(new String[] {
            "-"
        });
        ((ASaxEventRecorder) (obj)).setAttributeWatch("manifest");
        statusmanager = context.getStatusManager();
        obj1 = Loader.getClassLoaderOfObject(context).getResourceAsStream("AndroidManifest.xml");
        if (obj1 == null)
        {
            statusmanager.add(new WarnStatus("Could not find AndroidManifest.xml", context));
            return;
        }
        ((ASaxEventRecorder) (obj)).recordEvents(((InputStream) (obj1)));
        String s;
        try
        {
            ((InputStream) (obj1)).close();
        }
        catch (IOException ioexception1) { }
        context.putProperty("EXT_DIR", CommonPathUtil.getMountedExternalStorageDirectoryPath());
        obj = ((ASaxEventRecorder) (obj)).getAttributeWatchValues();
        obj1 = ((Map) (obj)).keySet().iterator();
        if (!((Iterator) (obj1)).hasNext())
        {
            break; /* Loop/switch isn't completed */
        }
        s = (String)((Iterator) (obj1)).next();
        if (s.equals("android:versionName"))
        {
            context.putProperty("VERSION_NAME", (String)((Map) (obj)).get(s));
        } else
        if (s.equals("android:versionCode"))
        {
            context.putProperty("VERSION_CODE", (String)((Map) (obj)).get(s));
        } else
        if (s.equals("package"))
        {
            context.putProperty("PACKAGE_NAME", (String)((Map) (obj)).get(s));
        }
        continue; /* Loop/switch isn't completed */
        context;
        try
        {
            ((InputStream) (obj1)).close();
        }
        catch (IOException ioexception) { }
        throw context;
        if (true) goto _L2; else goto _L1
_L2:
        break MISSING_BLOCK_LABEL_102;
_L1:
        obj = (String)((Map) (obj)).get("package");
        if (obj != null && ((String) (obj)).length() > 0)
        {
            context.putProperty("DATA_DIR", CommonPathUtil.getFilesDirectoryPath(((String) (obj))));
            return;
        } else
        {
            statusmanager.add(new WarnStatus("Package name not found. Some properties cannot be set.", context));
            return;
        }
    }
}
