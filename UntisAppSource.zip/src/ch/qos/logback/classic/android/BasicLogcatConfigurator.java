// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.classic.android;

import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.encoder.PatternLayoutEncoder;
import ch.qos.logback.core.status.InfoStatus;
import ch.qos.logback.core.status.StatusManager;
import org.slf4j.LoggerFactory;

// Referenced classes of package ch.qos.logback.classic.android:
//            LogcatAppender

public class BasicLogcatConfigurator
{

    private BasicLogcatConfigurator()
    {
    }

    public static void configure(LoggerContext loggercontext)
    {
        Object obj = loggercontext.getStatusManager();
        if (obj != null)
        {
            ((StatusManager) (obj)).add(new InfoStatus("Setting up default configuration.", loggercontext));
        }
        obj = new LogcatAppender();
        ((LogcatAppender) (obj)).setContext(loggercontext);
        ((LogcatAppender) (obj)).setName("logcat");
        PatternLayoutEncoder patternlayoutencoder = new PatternLayoutEncoder();
        patternlayoutencoder.setContext(loggercontext);
        patternlayoutencoder.setPattern("%msg");
        patternlayoutencoder.start();
        ((LogcatAppender) (obj)).setEncoder(patternlayoutencoder);
        ((LogcatAppender) (obj)).start();
        loggercontext.getLogger("ROOT").addAppender(((ch.qos.logback.core.Appender) (obj)));
    }

    public static void configureDefaultContext()
    {
        configure((LoggerContext)LoggerFactory.getILoggerFactory());
    }
}
