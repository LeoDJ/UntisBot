// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.classic.android;

import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteStatement;
import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.db.SQLBuilder;
import ch.qos.logback.classic.db.names.DBNameResolver;
import ch.qos.logback.classic.db.names.DefaultDBNameResolver;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.classic.spi.IThrowableProxy;
import ch.qos.logback.classic.spi.LoggerContextVO;
import ch.qos.logback.classic.spi.ThrowableProxyUtil;
import ch.qos.logback.core.Context;
import ch.qos.logback.core.UnsynchronizedAppenderBase;
import ch.qos.logback.core.android.CommonPathUtil;
import java.io.File;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class SQLiteAppender extends UnsynchronizedAppenderBase
{

    private static final int ARG0_INDEX = 7;
    private static final int CALLER_CLASS_INDEX = 12;
    private static final int CALLER_FILENAME_INDEX = 11;
    private static final int CALLER_LINE_INDEX = 14;
    private static final int CALLER_METHOD_INDEX = 13;
    private static final short EXCEPTION_EXISTS = 2;
    private static final int FORMATTED_MESSAGE_INDEX = 2;
    private static final int LEVEL_STRING_INDEX = 4;
    private static final int LOGGER_NAME_INDEX = 3;
    private static final short PROPERTIES_EXIST = 1;
    private static final int REFERENCE_FLAG_INDEX = 6;
    private static final int THREAD_NAME_INDEX = 5;
    private static final int TIMESTMP_INDEX = 1;
    private SQLiteDatabase db;
    private DBNameResolver dbNameResolver;
    private String insertExceptionSQL;
    private String insertPropertiesSQL;
    private String insertSQL;

    public SQLiteAppender()
    {
    }

    private String asStringTruncatedTo254(Object obj)
    {
        Object obj1 = null;
        if (obj != null)
        {
            obj1 = obj.toString();
        }
        obj = obj1;
        if (obj1 != null)
        {
            obj = obj1;
            if (((String) (obj1)).length() > 254)
            {
                obj = ((String) (obj1)).substring(0, 254);
            }
        }
        obj1 = obj;
        if (obj == null)
        {
            obj1 = "";
        }
        return ((String) (obj1));
    }

    private void bindCallerData(SQLiteStatement sqlitestatement, StackTraceElement astacktraceelement[])
        throws SQLException
    {
        if (astacktraceelement != null && astacktraceelement.length > 0)
        {
            astacktraceelement = astacktraceelement[0];
            if (astacktraceelement != null)
            {
                sqlitestatement.bindString(11, astacktraceelement.getFileName());
                sqlitestatement.bindString(12, astacktraceelement.getClassName());
                sqlitestatement.bindString(13, astacktraceelement.getMethodName());
                sqlitestatement.bindString(14, Integer.toString(astacktraceelement.getLineNumber()));
            }
        }
    }

    private void bindLoggingEvent(SQLiteStatement sqlitestatement, ILoggingEvent iloggingevent)
        throws SQLException
    {
        sqlitestatement.bindLong(1, iloggingevent.getTimeStamp());
        sqlitestatement.bindString(2, iloggingevent.getFormattedMessage());
        sqlitestatement.bindString(3, iloggingevent.getLoggerName());
        sqlitestatement.bindString(4, iloggingevent.getLevel().toString());
        sqlitestatement.bindString(5, iloggingevent.getThreadName());
        sqlitestatement.bindLong(6, computeReferenceMask(iloggingevent));
    }

    private void bindLoggingEventArguments(SQLiteStatement sqlitestatement, Object aobj[])
        throws SQLException
    {
        int j = 0;
        int i;
        if (aobj != null)
        {
            i = aobj.length;
        } else
        {
            i = 0;
        }
        for (; j < i && j < 4; j++)
        {
            sqlitestatement.bindString(j + 7, asStringTruncatedTo254(aobj[j]));
        }

    }

    private static short computeReferenceMask(ILoggingEvent iloggingevent)
    {
        int i = 0;
        short word0;
        int j;
        int k;
        if (iloggingevent.getMDCPropertyMap() != null)
        {
            j = iloggingevent.getMDCPropertyMap().keySet().size();
        } else
        {
            j = 0;
        }
        if (iloggingevent.getLoggerContextVO().getPropertyMap() != null)
        {
            k = iloggingevent.getLoggerContextVO().getPropertyMap().size();
        } else
        {
            k = 0;
        }
        if (j > 0 || k > 0)
        {
            i = 1;
        }
        word0 = i;
        if (iloggingevent.getThrowableProxy() != null)
        {
            word0 = (short)(i | 2);
        }
        return word0;
    }

    private void insertException(SQLiteStatement sqlitestatement, String s, short word0, long l)
        throws SQLException
    {
        sqlitestatement.bindLong(1, l);
        sqlitestatement.bindLong(2, word0);
        sqlitestatement.bindString(3, s);
        sqlitestatement.executeInsert();
    }

    private void insertProperties(Map map, long l)
        throws SQLException
    {
        SQLiteStatement sqlitestatement;
        if (map.size() <= 0)
        {
            break MISSING_BLOCK_LABEL_115;
        }
        sqlitestatement = db.compileStatement(insertPropertiesSQL);
        for (map = map.entrySet().iterator(); map.hasNext(); sqlitestatement.executeInsert())
        {
            java.util.Map.Entry entry = (java.util.Map.Entry)map.next();
            sqlitestatement.bindLong(1, l);
            sqlitestatement.bindString(2, (String)entry.getKey());
            sqlitestatement.bindString(3, (String)entry.getValue());
        }

        break MISSING_BLOCK_LABEL_110;
        map;
        sqlitestatement.close();
        throw map;
        sqlitestatement.close();
    }

    private void insertThrowable(IThrowableProxy ithrowableproxy, long l)
        throws SQLException
    {
        short word1;
        SQLiteStatement sqlitestatement;
        sqlitestatement = db.compileStatement(insertExceptionSQL);
        word1 = 0;
_L4:
        if (ithrowableproxy == null)
        {
            break; /* Loop/switch isn't completed */
        }
        Object obj;
        obj = new StringBuilder();
        ThrowableProxyUtil.subjoinFirstLine(((StringBuilder) (obj)), ithrowableproxy);
        obj = ((StringBuilder) (obj)).toString();
        short word0 = (short)(word1 + 1);
        ch.qos.logback.classic.spi.StackTraceElementProxy astacktraceelementproxy[];
        int j;
        insertException(sqlitestatement, ((String) (obj)), word1, l);
        j = ithrowableproxy.getCommonFrames();
        astacktraceelementproxy = ithrowableproxy.getStackTraceElementProxyArray();
        int i = 0;
_L2:
        Object obj1;
        if (i >= astacktraceelementproxy.length - j)
        {
            break; /* Loop/switch isn't completed */
        }
        obj1 = new StringBuilder();
        ((StringBuilder) (obj1)).append('\t');
        ThrowableProxyUtil.subjoinSTEP(((StringBuilder) (obj1)), astacktraceelementproxy[i]);
        obj1 = ((StringBuilder) (obj1)).toString();
        word1 = (short)(word0 + 1);
        insertException(sqlitestatement, ((String) (obj1)), word0, l);
        i++;
        word0 = word1;
        if (true) goto _L2; else goto _L1
_L1:
        word1 = word0;
        if (j <= 0)
        {
            break MISSING_BLOCK_LABEL_221;
        }
        astacktraceelementproxy = new StringBuilder();
        astacktraceelementproxy.append('\t').append("... ").append(j).append(" common frames omitted");
        astacktraceelementproxy = astacktraceelementproxy.toString();
        word1 = (short)(word0 + 1);
        insertException(sqlitestatement, astacktraceelementproxy, word0, l);
        ithrowableproxy = ithrowableproxy.getCause();
        if (true) goto _L4; else goto _L3
_L3:
        sqlitestatement.close();
        return;
        ithrowableproxy;
        sqlitestatement.close();
        throw ithrowableproxy;
    }

    private Map mergePropertyMaps(ILoggingEvent iloggingevent)
    {
        HashMap hashmap = new HashMap();
        Map map = iloggingevent.getLoggerContextVO().getPropertyMap();
        if (map != null)
        {
            hashmap.putAll(map);
        }
        iloggingevent = iloggingevent.getMDCPropertyMap();
        if (iloggingevent != null)
        {
            hashmap.putAll(iloggingevent);
        }
        return hashmap;
    }

    private void secondarySubAppend(ILoggingEvent iloggingevent, long l)
        throws SQLException
    {
        insertProperties(mergePropertyMaps(iloggingevent), l);
        if (iloggingevent.getThrowableProxy() != null)
        {
            insertThrowable(iloggingevent.getThrowableProxy(), l);
        }
    }

    private long subAppend(ILoggingEvent iloggingevent, SQLiteStatement sqlitestatement)
        throws SQLException
    {
        bindLoggingEvent(sqlitestatement, iloggingevent);
        bindLoggingEventArguments(sqlitestatement, iloggingevent.getArgumentArray());
        bindCallerData(sqlitestatement, iloggingevent.getCallerData());
        long l;
        try
        {
            l = sqlitestatement.executeInsert();
        }
        // Misplaced declaration of an exception variable
        catch (ILoggingEvent iloggingevent)
        {
            addWarn("Failed to insert loggingEvent", iloggingevent);
            return -1L;
        }
        return l;
    }

    public void append(ILoggingEvent iloggingevent)
    {
        if (!isStarted())
        {
            break MISSING_BLOCK_LABEL_109;
        }
        SQLiteStatement sqlitestatement = db.compileStatement(insertSQL);
        long l;
        db.beginTransaction();
        l = subAppend(iloggingevent, sqlitestatement);
        if (l == -1L)
        {
            break MISSING_BLOCK_LABEL_54;
        }
        secondarySubAppend(iloggingevent, l);
        db.setTransactionSuccessful();
        try
        {
            if (db.inTransaction())
            {
                db.endTransaction();
            }
            sqlitestatement.close();
            return;
        }
        // Misplaced declaration of an exception variable
        catch (ILoggingEvent iloggingevent)
        {
            addError("Cannot append event", iloggingevent);
        }
        break MISSING_BLOCK_LABEL_109;
        iloggingevent;
        if (db.inTransaction())
        {
            db.endTransaction();
        }
        sqlitestatement.close();
        throw iloggingevent;
    }

    public volatile void append(Object obj)
    {
        append((ILoggingEvent)obj);
    }

    protected void finalize()
        throws Throwable
    {
        db.close();
    }

    public void setDbNameResolver(DBNameResolver dbnameresolver)
    {
        dbNameResolver = dbnameresolver;
    }

    public void start()
    {
        Object obj = null;
        boolean flag = true;
        started = false;
        if (getContext() != null)
        {
            obj = getContext().getProperty("PACKAGE_NAME");
        }
        if (obj == null || ((String) (obj)).length() == 0)
        {
            addError("Cannot create database without package name");
        } else
        {
            try
            {
                obj = new File(CommonPathUtil.getDatabaseDirectoryPath(((String) (obj))), "logback.db");
                ((File) (obj)).getParentFile().mkdirs();
                db = SQLiteDatabase.openOrCreateDatabase(((File) (obj)).getPath(), null);
            }
            catch (SQLiteException sqliteexception1)
            {
                addError("Cannot open database", sqliteexception1);
                flag = false;
            }
            if (flag)
            {
                if (dbNameResolver == null)
                {
                    dbNameResolver = new DefaultDBNameResolver();
                }
                insertExceptionSQL = SQLBuilder.buildInsertExceptionSQL(dbNameResolver);
                insertPropertiesSQL = SQLBuilder.buildInsertPropertiesSQL(dbNameResolver);
                insertSQL = SQLBuilder.buildInsertSQL(dbNameResolver);
                try
                {
                    db.execSQL(SQLBuilder.buildCreateLoggingEventTableSQL(dbNameResolver));
                    db.execSQL(SQLBuilder.buildCreatePropertyTableSQL(dbNameResolver));
                    db.execSQL(SQLBuilder.buildCreateExceptionTableSQL(dbNameResolver));
                    super.start();
                    started = true;
                    return;
                }
                catch (SQLiteException sqliteexception)
                {
                    addError("Cannot create database tables", sqliteexception);
                }
                return;
            }
        }
    }

    public void stop()
    {
        db.close();
    }
}
