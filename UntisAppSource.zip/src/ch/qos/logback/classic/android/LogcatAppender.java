// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.classic.android;

import android.util.Log;
import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.PatternLayout;
import ch.qos.logback.classic.encoder.PatternLayoutEncoder;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.AppenderBase;
import ch.qos.logback.core.Layout;

public class LogcatAppender extends AppenderBase
{

    private static final int MAX_TAG_LENGTH = 23;
    private boolean checkLoggable;
    private PatternLayoutEncoder encoder;
    private PatternLayoutEncoder tagEncoder;

    public LogcatAppender()
    {
        encoder = null;
        tagEncoder = null;
        checkLoggable = false;
    }

    public void append(ILoggingEvent iloggingevent)
    {
        if (isStarted()) goto _L2; else goto _L1
_L1:
        return;
_L2:
        String s = getTag(iloggingevent);
        iloggingevent.getLevel().levelInt;
        JVM INSTR lookupswitch 6: default 80
    //                   -2147483648: 81
    //                   5000: 81
    //                   10000: 115
    //                   20000: 149
    //                   30000: 183
    //                   40000: 217;
           goto _L3 _L4 _L4 _L5 _L6 _L7 _L8
_L8:
        continue; /* Loop/switch isn't completed */
_L3:
        return;
_L4:
        if (checkLoggable && !Log.isLoggable(s, 2)) goto _L1; else goto _L9
_L9:
        Log.v(s, encoder.getLayout().doLayout(iloggingevent));
        return;
_L5:
        if (checkLoggable && !Log.isLoggable(s, 3)) goto _L1; else goto _L10
_L10:
        Log.d(s, encoder.getLayout().doLayout(iloggingevent));
        return;
_L6:
        if (checkLoggable && !Log.isLoggable(s, 4)) goto _L1; else goto _L11
_L11:
        Log.i(s, encoder.getLayout().doLayout(iloggingevent));
        return;
_L7:
        if (checkLoggable && !Log.isLoggable(s, 5)) goto _L1; else goto _L12
_L12:
        Log.w(s, encoder.getLayout().doLayout(iloggingevent));
        return;
        if (checkLoggable && !Log.isLoggable(s, 6)) goto _L1; else goto _L13
_L13:
        Log.e(s, encoder.getLayout().doLayout(iloggingevent));
        return;
    }

    public volatile void append(Object obj)
    {
        append((ILoggingEvent)obj);
    }

    public boolean getCheckLoggable()
    {
        return checkLoggable;
    }

    public PatternLayoutEncoder getEncoder()
    {
        return encoder;
    }

    protected String getTag(ILoggingEvent iloggingevent)
    {
        Object obj;
        if (tagEncoder != null)
        {
            iloggingevent = tagEncoder.getLayout().doLayout(iloggingevent);
        } else
        {
            iloggingevent = iloggingevent.getLoggerName();
        }
        obj = iloggingevent;
        if (checkLoggable)
        {
            obj = iloggingevent;
            if (iloggingevent.length() > 23)
            {
                obj = (new StringBuilder()).append(iloggingevent.substring(0, 22)).append("*").toString();
            }
        }
        return ((String) (obj));
    }

    public PatternLayoutEncoder getTagEncoder()
    {
        return tagEncoder;
    }

    public void setCheckLoggable(boolean flag)
    {
        checkLoggable = flag;
    }

    public void setEncoder(PatternLayoutEncoder patternlayoutencoder)
    {
        encoder = patternlayoutencoder;
    }

    public void setTagEncoder(PatternLayoutEncoder patternlayoutencoder)
    {
        tagEncoder = patternlayoutencoder;
    }

    public void start()
    {
        if (encoder == null || encoder.getLayout() == null)
        {
            addError((new StringBuilder()).append("No layout set for the appender named [").append(name).append("].").toString());
            return;
        }
        if (tagEncoder != null)
        {
            Layout layout = tagEncoder.getLayout();
            if (layout == null)
            {
                addError((new StringBuilder()).append("No tag layout set for the appender named [").append(name).append("].").toString());
                return;
            }
            if (layout instanceof PatternLayout)
            {
                String s = tagEncoder.getPattern();
                if (!s.contains("%nopex"))
                {
                    tagEncoder.stop();
                    tagEncoder.setPattern((new StringBuilder()).append(s).append("%nopex").toString());
                    tagEncoder.start();
                }
                ((PatternLayout)layout).setPostCompileProcessor(null);
            }
        }
        super.start();
    }
}
