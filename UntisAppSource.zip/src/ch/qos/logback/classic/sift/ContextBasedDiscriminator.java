// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.classic.sift;

import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.classic.spi.LoggerContextVO;
import ch.qos.logback.core.sift.AbstractDiscriminator;

public class ContextBasedDiscriminator extends AbstractDiscriminator
{

    private static final String KEY = "contextName";
    private String defaultValue;

    public ContextBasedDiscriminator()
    {
    }

    public String getDefaultValue()
    {
        return defaultValue;
    }

    public String getDiscriminatingValue(ILoggingEvent iloggingevent)
    {
        String s = iloggingevent.getLoggerContextVO().getName();
        iloggingevent = s;
        if (s == null)
        {
            iloggingevent = defaultValue;
        }
        return iloggingevent;
    }

    public volatile String getDiscriminatingValue(Object obj)
    {
        return getDiscriminatingValue((ILoggingEvent)obj);
    }

    public String getKey()
    {
        return "contextName";
    }

    public void setDefaultValue(String s)
    {
        defaultValue = s;
    }

    public void setKey(String s)
    {
        throw new UnsupportedOperationException("Key cannot be set. Using fixed key contextName");
    }
}
