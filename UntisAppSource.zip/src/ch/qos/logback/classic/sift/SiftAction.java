// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.classic.sift;

import ch.qos.logback.core.joran.action.Action;
import ch.qos.logback.core.joran.event.InPlayListener;
import ch.qos.logback.core.joran.event.SaxEvent;
import ch.qos.logback.core.joran.spi.ActionException;
import ch.qos.logback.core.joran.spi.InterpretationContext;
import java.util.ArrayList;
import java.util.List;
import org.xml.sax.Attributes;

// Referenced classes of package ch.qos.logback.classic.sift:
//            SiftingAppender, AppenderFactoryUsingJoran

public class SiftAction extends Action
    implements InPlayListener
{

    List seList;

    public SiftAction()
    {
    }

    public void begin(InterpretationContext interpretationcontext, String s, Attributes attributes)
        throws ActionException
    {
        seList = new ArrayList();
        interpretationcontext.addInPlayListener(this);
    }

    public void end(InterpretationContext interpretationcontext, String s)
        throws ActionException
    {
        interpretationcontext.removeInPlayListener(this);
        s = ((String) (interpretationcontext.peekObject()));
        if (s instanceof SiftingAppender)
        {
            s = (SiftingAppender)s;
            interpretationcontext = interpretationcontext.getCopyOfPropertyMap();
            s.setAppenderFactory(new AppenderFactoryUsingJoran(seList, s.getDiscriminatorKey(), interpretationcontext));
        }
    }

    public List getSeList()
    {
        return seList;
    }

    public void inPlay(SaxEvent saxevent)
    {
        seList.add(saxevent);
    }
}
