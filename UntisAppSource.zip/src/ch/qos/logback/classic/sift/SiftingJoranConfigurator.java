// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.classic.sift;

import ch.qos.logback.classic.util.DefaultNestedComponentRules;
import ch.qos.logback.core.Appender;
import ch.qos.logback.core.joran.action.AppenderAction;
import ch.qos.logback.core.joran.spi.DefaultNestedComponentRegistry;
import ch.qos.logback.core.joran.spi.ElementPath;
import ch.qos.logback.core.joran.spi.ElementSelector;
import ch.qos.logback.core.joran.spi.InterpretationContext;
import ch.qos.logback.core.joran.spi.Interpreter;
import ch.qos.logback.core.joran.spi.RuleStore;
import ch.qos.logback.core.sift.SiftingJoranConfiguratorBase;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class SiftingJoranConfigurator extends SiftingJoranConfiguratorBase
{

    SiftingJoranConfigurator(String s, String s1, Map map)
    {
        super(s, s1, map);
    }

    protected void addDefaultNestedComponentRegistryRules(DefaultNestedComponentRegistry defaultnestedcomponentregistry)
    {
        DefaultNestedComponentRules.addDefaultNestedComponentRegistryRules(defaultnestedcomponentregistry);
    }

    protected void addInstanceRules(RuleStore rulestore)
    {
        super.addInstanceRules(rulestore);
        rulestore.addRule(new ElementSelector("configuration/appender"), new AppenderAction());
    }

    protected void buildInterpreter()
    {
        super.buildInterpreter();
        Object obj = interpreter.getInterpretationContext().getObjectMap();
        ((Map) (obj)).put("APPENDER_BAG", new HashMap());
        ((Map) (obj)).put("FILTER_CHAIN_BAG", new HashMap());
        obj = new HashMap();
        ((Map) (obj)).putAll(parentPropertyMap);
        ((Map) (obj)).put(key, value);
        interpreter.setInterpretationContextPropertiesMap(((Map) (obj)));
    }

    public Appender getAppender()
    {
        Object obj = (HashMap)interpreter.getInterpretationContext().getObjectMap().get("APPENDER_BAG");
        oneAndOnlyOneCheck(((Map) (obj)));
        obj = ((HashMap) (obj)).values();
        if (((Collection) (obj)).size() == 0)
        {
            return null;
        } else
        {
            return (Appender)((Collection) (obj)).iterator().next();
        }
    }

    protected ElementPath initialElementPath()
    {
        return new ElementPath("configuration");
    }
}
