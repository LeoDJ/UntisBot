// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.classic;

import java.io.Serializable;

public final class Level
    implements Serializable
{

    public static final Level ALL = new Level(0x80000000, "ALL");
    public static final int ALL_INT = 0x80000000;
    public static final Integer ALL_INTEGER = Integer.valueOf(0x80000000);
    public static final Level DEBUG = new Level(10000, "DEBUG");
    public static final int DEBUG_INT = 10000;
    public static final Integer DEBUG_INTEGER = Integer.valueOf(10000);
    public static final Level ERROR = new Level(40000, "ERROR");
    public static final int ERROR_INT = 40000;
    public static final Integer ERROR_INTEGER = Integer.valueOf(40000);
    public static final Level INFO = new Level(20000, "INFO");
    public static final int INFO_INT = 20000;
    public static final Integer INFO_INTEGER = Integer.valueOf(20000);
    public static final Level OFF = new Level(0x7fffffff, "OFF");
    public static final int OFF_INT = 0x7fffffff;
    public static final Integer OFF_INTEGER = Integer.valueOf(0x7fffffff);
    public static final Level TRACE = new Level(5000, "TRACE");
    public static final int TRACE_INT = 5000;
    public static final Integer TRACE_INTEGER = Integer.valueOf(5000);
    public static final Level WARN = new Level(30000, "WARN");
    public static final int WARN_INT = 30000;
    public static final Integer WARN_INTEGER = Integer.valueOf(30000);
    private static final long serialVersionUID = 0xf4b3c2f0fcd34c67L;
    public final int levelInt;
    public final String levelStr;

    private Level(int i, String s)
    {
        levelInt = i;
        levelStr = s;
    }

    public static Level fromLocationAwareLoggerInteger(int i)
    {
        switch (i)
        {
        default:
            throw new IllegalArgumentException((new StringBuilder()).append(i).append(" not a valid level value").toString());

        case 0: // '\0'
            return TRACE;

        case 10: // '\n'
            return DEBUG;

        case 20: // '\024'
            return INFO;

        case 30: // '\036'
            return WARN;

        case 40: // '('
            return ERROR;
        }
    }

    private Object readResolve()
    {
        return toLevel(levelInt);
    }

    public static Level toLevel(int i)
    {
        return toLevel(i, DEBUG);
    }

    public static Level toLevel(int i, Level level)
    {
        switch (i)
        {
        default:
            return level;

        case -2147483648: 
            return ALL;

        case 5000: 
            return TRACE;

        case 10000: 
            return DEBUG;

        case 20000: 
            return INFO;

        case 30000: 
            return WARN;

        case 40000: 
            return ERROR;

        case 2147483647: 
            return OFF;
        }
    }

    public static Level toLevel(String s)
    {
        return toLevel(s, DEBUG);
    }

    public static Level toLevel(String s, Level level)
    {
        if (s != null)
        {
            if (s.equalsIgnoreCase("ALL"))
            {
                return ALL;
            }
            if (s.equalsIgnoreCase("TRACE"))
            {
                return TRACE;
            }
            if (s.equalsIgnoreCase("DEBUG"))
            {
                return DEBUG;
            }
            if (s.equalsIgnoreCase("INFO"))
            {
                return INFO;
            }
            if (s.equalsIgnoreCase("WARN"))
            {
                return WARN;
            }
            if (s.equalsIgnoreCase("ERROR"))
            {
                return ERROR;
            }
            if (s.equalsIgnoreCase("OFF"))
            {
                return OFF;
            }
        }
        return level;
    }

    public static int toLocationAwareLoggerInteger(Level level)
    {
        if (level == null)
        {
            throw new IllegalArgumentException("null level parameter is not admitted");
        }
        switch (level.toInt())
        {
        default:
            throw new IllegalArgumentException((new StringBuilder()).append(level).append(" not a valid level value").toString());

        case 5000: 
            return 0;

        case 10000: 
            return 10;

        case 20000: 
            return 20;

        case 30000: 
            return 30;

        case 40000: 
            return 40;
        }
    }

    public static Level valueOf(String s)
    {
        return toLevel(s, DEBUG);
    }

    public boolean isGreaterOrEqual(Level level)
    {
        return levelInt >= level.levelInt;
    }

    public int toInt()
    {
        return levelInt;
    }

    public Integer toInteger()
    {
        switch (levelInt)
        {
        default:
            throw new IllegalStateException((new StringBuilder()).append("Level ").append(levelStr).append(", ").append(levelInt).append(" is unknown.").toString());

        case -2147483648: 
            return ALL_INTEGER;

        case 5000: 
            return TRACE_INTEGER;

        case 10000: 
            return DEBUG_INTEGER;

        case 20000: 
            return INFO_INTEGER;

        case 30000: 
            return WARN_INTEGER;

        case 40000: 
            return ERROR_INTEGER;

        case 2147483647: 
            return OFF_INTEGER;
        }
    }

    public String toString()
    {
        return levelStr;
    }

}
