// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.classic.boolex;

import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.boolex.EvaluationException;
import ch.qos.logback.core.boolex.EventEvaluatorBase;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.slf4j.Marker;

public class OnMarkerEvaluator extends EventEvaluatorBase
{

    List markerList;

    public OnMarkerEvaluator()
    {
        markerList = new ArrayList();
    }

    public void addMarker(String s)
    {
        markerList.add(s);
    }

    public boolean evaluate(ILoggingEvent iloggingevent)
        throws NullPointerException, EvaluationException
    {
        iloggingevent = iloggingevent.getMarker();
        if (iloggingevent == null)
        {
            return false;
        }
        for (Iterator iterator = markerList.iterator(); iterator.hasNext();)
        {
            if (iloggingevent.contains((String)iterator.next()))
            {
                return true;
            }
        }

        return false;
    }

    public volatile boolean evaluate(Object obj)
        throws NullPointerException, EvaluationException
    {
        return evaluate((ILoggingEvent)obj);
    }
}
