// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.classic.boolex;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.boolex.EvaluationException;
import ch.qos.logback.core.boolex.EventEvaluatorBase;

public class OnErrorEvaluator extends EventEvaluatorBase
{

    public OnErrorEvaluator()
    {
    }

    public boolean evaluate(ILoggingEvent iloggingevent)
        throws NullPointerException, EvaluationException
    {
        return iloggingevent.getLevel().levelInt >= 40000;
    }

    public volatile boolean evaluate(Object obj)
        throws NullPointerException, EvaluationException
    {
        return evaluate((ILoggingEvent)obj);
    }
}
