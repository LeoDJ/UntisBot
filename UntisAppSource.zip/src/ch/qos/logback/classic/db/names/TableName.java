// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.classic.db.names;


public final class TableName extends Enum
{

    private static final TableName $VALUES[];
    public static final TableName LOGGING_EVENT;
    public static final TableName LOGGING_EVENT_EXCEPTION;
    public static final TableName LOGGING_EVENT_PROPERTY;

    private TableName(String s, int i)
    {
        super(s, i);
    }

    public static TableName valueOf(String s)
    {
        return (TableName)Enum.valueOf(ch/qos/logback/classic/db/names/TableName, s);
    }

    public static TableName[] values()
    {
        return (TableName[])$VALUES.clone();
    }

    static 
    {
        LOGGING_EVENT = new TableName("LOGGING_EVENT", 0);
        LOGGING_EVENT_PROPERTY = new TableName("LOGGING_EVENT_PROPERTY", 1);
        LOGGING_EVENT_EXCEPTION = new TableName("LOGGING_EVENT_EXCEPTION", 2);
        $VALUES = (new TableName[] {
            LOGGING_EVENT, LOGGING_EVENT_PROPERTY, LOGGING_EVENT_EXCEPTION
        });
    }
}
