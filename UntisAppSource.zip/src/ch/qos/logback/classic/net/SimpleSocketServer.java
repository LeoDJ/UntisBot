// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.classic.net;

import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.joran.JoranConfigurator;
import ch.qos.logback.core.joran.spi.JoranException;
import java.io.IOException;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import javax.net.ServerSocketFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

// Referenced classes of package ch.qos.logback.classic.net:
//            SocketNode

public class SimpleSocketServer extends Thread
{

    private boolean closed;
    private CountDownLatch latch;
    private final LoggerContext lc;
    Logger logger;
    private final int port;
    private ServerSocket serverSocket;
    private List socketNodeList;

    public SimpleSocketServer(LoggerContext loggercontext, int i)
    {
        logger = LoggerFactory.getLogger(ch/qos/logback/classic/net/SimpleSocketServer);
        closed = false;
        socketNodeList = new ArrayList();
        lc = loggercontext;
        port = i;
    }

    public static void configureLC(LoggerContext loggercontext, String s)
        throws JoranException
    {
        JoranConfigurator joranconfigurator = new JoranConfigurator();
        loggercontext.reset();
        joranconfigurator.setContext(loggercontext);
        joranconfigurator.doConfigure(s);
    }

    protected static void doMain(Class class1, String as[])
        throws Exception
    {
        int i;
        if (as.length == 2)
        {
            i = parsePortNumber(as[0]);
        } else
        {
            usage("Wrong number of arguments.");
            i = -1;
        }
        class1 = as[1];
        as = (LoggerContext)LoggerFactory.getILoggerFactory();
        configureLC(as, class1);
        (new SimpleSocketServer(as, i)).start();
    }

    public static void main(String args[])
        throws Exception
    {
        doMain(ch/qos/logback/classic/net/SimpleSocketServer, args);
    }

    static int parsePortNumber(String s)
    {
        int i;
        try
        {
            i = Integer.parseInt(s);
        }
        catch (NumberFormatException numberformatexception)
        {
            numberformatexception.printStackTrace();
            usage((new StringBuilder()).append("Could not interpret port number [").append(s).append("].").toString());
            return -1;
        }
        return i;
    }

    static void usage(String s)
    {
        System.err.println(s);
        System.err.println((new StringBuilder()).append("Usage: java ").append(ch/qos/logback/classic/net/SimpleSocketServer.getName()).append(" port configFile").toString());
        System.exit(1);
    }

    public void close()
    {
        closed = true;
        if (serverSocket == null)
        {
            break MISSING_BLOCK_LABEL_24;
        }
        serverSocket.close();
        serverSocket = null;
_L2:
        logger.info("closing this server");
        Object obj = socketNodeList;
        obj;
        JVM INSTR monitorenter ;
        for (Iterator iterator = socketNodeList.iterator(); iterator.hasNext(); ((SocketNode)iterator.next()).close()) { }
        break MISSING_BLOCK_LABEL_110;
        Exception exception;
        exception;
        obj;
        JVM INSTR monitorexit ;
        throw exception;
        obj;
        logger.error("Failed to close serverSocket", ((Throwable) (obj)));
        serverSocket = null;
        if (true) goto _L2; else goto _L1
_L1:
        obj;
        serverSocket = null;
        throw obj;
        obj;
        JVM INSTR monitorexit ;
        if (socketNodeList.size() != 0)
        {
            logger.warn("Was expecting a 0-sized socketNodeList after server shutdown");
        }
        return;
    }

    protected String getClientThreadName(Socket socket)
    {
        return String.format("Logback SocketNode (client: %s)", new Object[] {
            socket.getRemoteSocketAddress()
        });
    }

    public CountDownLatch getLatch()
    {
        return latch;
    }

    protected ServerSocketFactory getServerSocketFactory()
    {
        return ServerSocketFactory.getDefault();
    }

    protected String getServerThreadName()
    {
        return String.format("Logback %s (port %d)", new Object[] {
            getClass().getSimpleName(), Integer.valueOf(port)
        });
    }

    public boolean isClosed()
    {
        return closed;
    }

    public void run()
    {
        String s = Thread.currentThread().getName();
        String s1 = getServerThreadName();
        Thread.currentThread().setName(s1);
        logger.info((new StringBuilder()).append("Listening on port ").append(port).toString());
        serverSocket = getServerSocketFactory().createServerSocket(port);
_L3:
        if (closed) goto _L2; else goto _L1
_L1:
        Socket socket;
        SocketNode socketnode;
        logger.info("Waiting to accept a new client.");
        signalAlmostReadiness();
        socket = serverSocket.accept();
        logger.info((new StringBuilder()).append("Connected to client at ").append(socket.getInetAddress()).toString());
        logger.info("Starting new socket node.");
        socketnode = new SocketNode(this, socket, lc);
        synchronized (socketNodeList)
        {
            socketNodeList.add(socketnode);
        }
        (new Thread(socketnode, getClientThreadName(socket))).start();
          goto _L3
_L5:
        if (!closed)
        {
            break MISSING_BLOCK_LABEL_247;
        }
        logger.info("Exception in run method for a closed server. This is normal.");
_L6:
        Thread.currentThread().setName(s);
        return;
        exception;
        obj;
        JVM INSTR monitorexit ;
        try
        {
            throw exception;
        }
        // Misplaced declaration of an exception variable
        catch (Object obj) { }
        finally
        {
            Thread.currentThread().setName(s);
        }
        if (true) goto _L5; else goto _L4
_L4:
        throw obj;
_L2:
        Thread.currentThread().setName(s);
        return;
        logger.error("Unexpected failure in run method", ((Throwable) (obj)));
          goto _L6
    }

    void setLatch(CountDownLatch countdownlatch)
    {
        latch = countdownlatch;
    }

    void signalAlmostReadiness()
    {
        if (latch != null && latch.getCount() != 0L)
        {
            latch.countDown();
        }
    }

    public void socketNodeClosing(SocketNode socketnode)
    {
        logger.debug("Removing {}", socketnode);
        synchronized (socketNodeList)
        {
            socketNodeList.remove(socketnode);
        }
        return;
        socketnode;
        list;
        JVM INSTR monitorexit ;
        throw socketnode;
    }
}
