// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.classic.net;

import ch.qos.logback.classic.PatternLayout;
import ch.qos.logback.classic.pattern.SyslogStartConverter;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.classic.spi.IThrowableProxy;
import ch.qos.logback.classic.util.LevelToSyslogSeverity;
import ch.qos.logback.core.Layout;
import ch.qos.logback.core.net.SyslogAppenderBase;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Map;

public class SyslogAppender extends SyslogAppenderBase
{

    public static final String DEFAULT_STACKTRACE_PATTERN = "\t";
    public static final String DEFAULT_SUFFIX_PATTERN = "[%thread] %logger %msg";
    PatternLayout stackTraceLayout;
    String stackTracePattern;
    boolean throwableExcluded;

    public SyslogAppender()
    {
        stackTraceLayout = new PatternLayout();
        stackTracePattern = "\t";
        throwableExcluded = false;
    }

    private void handleThrowableFirstLine(OutputStream outputstream, IThrowableProxy ithrowableproxy, String s, boolean flag)
        throws IOException
    {
        s = (new StringBuilder()).append(s);
        if (!flag)
        {
            s.append("Caused by: ");
        }
        s.append(ithrowableproxy.getClassName()).append(": ").append(ithrowableproxy.getMessage());
        outputstream.write(s.toString().getBytes());
        outputstream.flush();
    }

    private void setupStackTraceLayout()
    {
        stackTraceLayout.getInstanceConverterMap().put("syslogStart", ch/qos/logback/classic/pattern/SyslogStartConverter.getName());
        stackTraceLayout.setPattern((new StringBuilder()).append(getPrefixPattern()).append(stackTracePattern).toString());
        stackTraceLayout.setContext(getContext());
        stackTraceLayout.start();
    }

    public Layout buildLayout()
    {
        PatternLayout patternlayout = new PatternLayout();
        patternlayout.getInstanceConverterMap().put("syslogStart", ch/qos/logback/classic/pattern/SyslogStartConverter.getName());
        if (suffixPattern == null)
        {
            suffixPattern = "[%thread] %logger %msg";
        }
        patternlayout.setPattern((new StringBuilder()).append(getPrefixPattern()).append(suffixPattern).toString());
        patternlayout.setContext(getContext());
        patternlayout.start();
        return patternlayout;
    }

    String getPrefixPattern()
    {
        return (new StringBuilder()).append("%syslogStart{").append(getFacility()).append("}%nopex{}").toString();
    }

    public int getSeverityForEvent(Object obj)
    {
        return LevelToSyslogSeverity.convert((ILoggingEvent)obj);
    }

    public String getStackTracePattern()
    {
        return stackTracePattern;
    }

    public boolean isThrowableExcluded()
    {
        return throwableExcluded;
    }

    protected void postProcess(Object obj, OutputStream outputstream)
    {
        if (!throwableExcluded) goto _L2; else goto _L1
_L1:
        return;
_L2:
        Object obj1;
        boolean flag;
        obj1 = (ILoggingEvent)obj;
        obj = ((ILoggingEvent) (obj1)).getThrowableProxy();
        if (obj == null)
        {
            continue; /* Loop/switch isn't completed */
        }
        obj1 = stackTraceLayout.doLayout(((ILoggingEvent) (obj1)));
        flag = true;
_L5:
        if (obj == null)
        {
            continue; /* Loop/switch isn't completed */
        }
        ch.qos.logback.classic.spi.StackTraceElementProxy astacktraceelementproxy[] = ((IThrowableProxy) (obj)).getStackTraceElementProxyArray();
        ch.qos.logback.classic.spi.StackTraceElementProxy stacktraceelementproxy;
        StringBuilder stringbuilder;
        int i;
        int j;
        try
        {
            handleThrowableFirstLine(outputstream, ((IThrowableProxy) (obj)), ((String) (obj1)), flag);
            j = astacktraceelementproxy.length;
        }
        // Misplaced declaration of an exception variable
        catch (Object obj)
        {
            return;
        }
        i = 0;
_L4:
        if (i >= j)
        {
            break; /* Loop/switch isn't completed */
        }
        stacktraceelementproxy = astacktraceelementproxy[i];
        stringbuilder = new StringBuilder();
        stringbuilder.append(((String) (obj1))).append(stacktraceelementproxy);
        outputstream.write(stringbuilder.toString().getBytes());
        outputstream.flush();
        i++;
        if (true) goto _L4; else goto _L3
_L3:
        obj = ((IThrowableProxy) (obj)).getCause();
        flag = false;
          goto _L5
        if (true) goto _L1; else goto _L6
_L6:
    }

    public void setStackTracePattern(String s)
    {
        stackTracePattern = s;
    }

    public void setThrowableExcluded(boolean flag)
    {
        throwableExcluded = flag;
    }

    boolean stackTraceHeaderLine(StringBuilder stringbuilder, boolean flag)
    {
        return false;
    }

    public void start()
    {
        super.start();
        setupStackTraceLayout();
    }
}
