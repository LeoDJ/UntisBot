// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.classic.net.server;

import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.util.CloseUtil;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.net.Socket;

// Referenced classes of package ch.qos.logback.classic.net.server:
//            RemoteAppenderClient

class RemoteAppenderStreamClient
    implements RemoteAppenderClient
{

    private final String id;
    private final InputStream inputStream;
    private LoggerContext lc;
    private Logger logger;
    private final Socket socket;

    public RemoteAppenderStreamClient(String s, InputStream inputstream)
    {
        id = s;
        socket = null;
        inputStream = inputstream;
    }

    public RemoteAppenderStreamClient(String s, Socket socket1)
    {
        id = s;
        socket = socket1;
        inputStream = null;
    }

    private ObjectInputStream createObjectInputStream()
        throws IOException
    {
        if (inputStream != null)
        {
            return new ObjectInputStream(inputStream);
        } else
        {
            return new ObjectInputStream(socket.getInputStream());
        }
    }

    public void close()
    {
        if (socket == null)
        {
            return;
        } else
        {
            CloseUtil.closeQuietly(socket);
            return;
        }
    }

    public void run()
    {
        Object obj;
        logger.info((new StringBuilder()).append(this).append(": connected").toString());
        obj = null;
        Object obj1 = createObjectInputStream();
        obj = obj1;
_L2:
        obj1 = obj;
        ILoggingEvent iloggingevent = (ILoggingEvent)((ObjectInputStream) (obj)).readObject();
        obj1 = obj;
        Logger logger1 = lc.getLogger(iloggingevent.getLoggerName());
        obj1 = obj;
        if (!logger1.isEnabledFor(iloggingevent.getLevel())) goto _L2; else goto _L1
_L1:
        obj1 = obj;
        logger1.callAppenders(iloggingevent);
          goto _L2
        obj1;
_L12:
        if (obj != null)
        {
            CloseUtil.closeQuietly(((java.io.Closeable) (obj)));
        }
        close();
        logger.info((new StringBuilder()).append(this).append(": connection closed").toString());
        return;
        Object obj3;
        obj3;
        obj = null;
_L10:
        obj1 = obj;
        logger.info((new StringBuilder()).append(this).append(": ").append(obj3).toString());
        if (obj != null)
        {
            CloseUtil.closeQuietly(((java.io.Closeable) (obj)));
        }
        close();
        logger.info((new StringBuilder()).append(this).append(": connection closed").toString());
        return;
        obj;
        obj = null;
_L8:
        obj1 = obj;
        logger.error((new StringBuilder()).append(this).append(": unknown event class").toString());
        if (obj != null)
        {
            CloseUtil.closeQuietly(((java.io.Closeable) (obj)));
        }
        close();
        logger.info((new StringBuilder()).append(this).append(": connection closed").toString());
        return;
        obj3;
        obj = null;
_L6:
        obj1 = obj;
        logger.error((new StringBuilder()).append(this).append(": ").append(obj3).toString());
        if (obj != null)
        {
            CloseUtil.closeQuietly(((java.io.Closeable) (obj)));
        }
        close();
        logger.info((new StringBuilder()).append(this).append(": connection closed").toString());
        return;
        Exception exception;
        exception;
        obj1 = null;
_L4:
        if (obj1 != null)
        {
            CloseUtil.closeQuietly(((java.io.Closeable) (obj1)));
        }
        close();
        logger.info((new StringBuilder()).append(this).append(": connection closed").toString());
        throw exception;
        exception;
        if (true) goto _L4; else goto _L3
_L3:
        obj3;
        if (true) goto _L6; else goto _L5
_L5:
        Object obj2;
        obj2;
        if (true) goto _L8; else goto _L7
_L7:
        obj3;
        if (true) goto _L10; else goto _L9
_L9:
        obj2;
        if (true) goto _L12; else goto _L11
_L11:
    }

    public void setLoggerContext(LoggerContext loggercontext)
    {
        lc = loggercontext;
        logger = loggercontext.getLogger(getClass().getPackage().getName());
    }

    public String toString()
    {
        return (new StringBuilder()).append("client ").append(id).toString();
    }
}
