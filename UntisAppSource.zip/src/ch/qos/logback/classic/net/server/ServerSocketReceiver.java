// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.classic.net.server;

import ch.qos.logback.classic.net.ReceiverBase;
import ch.qos.logback.core.Context;
import ch.qos.logback.core.net.server.ServerListener;
import ch.qos.logback.core.net.server.ServerRunner;
import ch.qos.logback.core.util.CloseUtil;
import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.UnknownHostException;
import java.util.concurrent.Executor;
import javax.net.ServerSocketFactory;

// Referenced classes of package ch.qos.logback.classic.net.server:
//            RemoteAppenderServerListener, RemoteAppenderServerRunner

public class ServerSocketReceiver extends ReceiverBase
{

    public static final int DEFAULT_BACKLOG = 50;
    private String address;
    private int backlog;
    private int port;
    private ServerRunner runner;
    private ServerSocket serverSocket;

    public ServerSocketReceiver()
    {
        port = 4560;
        backlog = 50;
    }

    protected ServerListener createServerListener(ServerSocket serversocket)
    {
        return new RemoteAppenderServerListener(serversocket);
    }

    protected ServerRunner createServerRunner(ServerListener serverlistener, Executor executor)
    {
        return new RemoteAppenderServerRunner(serverlistener, executor);
    }

    public String getAddress()
    {
        return address;
    }

    public int getBacklog()
    {
        return backlog;
    }

    protected InetAddress getInetAddress()
        throws UnknownHostException
    {
        if (getAddress() == null)
        {
            return null;
        } else
        {
            return InetAddress.getByName(getAddress());
        }
    }

    public int getPort()
    {
        return port;
    }

    protected Runnable getRunnableTask()
    {
        return runner;
    }

    protected ServerSocketFactory getServerSocketFactory()
        throws Exception
    {
        return ServerSocketFactory.getDefault();
    }

    protected void onStop()
    {
        if (runner == null)
        {
            return;
        }
        try
        {
            runner.stop();
            return;
        }
        catch (IOException ioexception)
        {
            addError((new StringBuilder()).append("server shutdown error: ").append(ioexception).toString(), ioexception);
        }
        return;
    }

    public void setAddress(String s)
    {
        address = s;
    }

    public void setBacklog(int i)
    {
        backlog = i;
    }

    public void setPort(int i)
    {
        port = i;
    }

    protected boolean shouldStart()
    {
        try
        {
            runner = createServerRunner(createServerListener(getServerSocketFactory().createServerSocket(getPort(), getBacklog(), getInetAddress())), getContext().getExecutorService());
            runner.setContext(getContext());
        }
        catch (Exception exception)
        {
            addError((new StringBuilder()).append("server startup error: ").append(exception).toString(), exception);
            CloseUtil.closeQuietly(serverSocket);
            return false;
        }
        return true;
    }
}
