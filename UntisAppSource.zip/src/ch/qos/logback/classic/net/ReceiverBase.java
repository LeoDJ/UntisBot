// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.classic.net;

import ch.qos.logback.core.Context;
import ch.qos.logback.core.spi.ContextAwareBase;
import ch.qos.logback.core.spi.LifeCycle;
import java.util.concurrent.ExecutorService;

public abstract class ReceiverBase extends ContextAwareBase
    implements LifeCycle
{

    private boolean started;

    public ReceiverBase()
    {
    }

    protected abstract Runnable getRunnableTask();

    public final boolean isStarted()
    {
        return started;
    }

    protected abstract void onStop();

    protected abstract boolean shouldStart();

    public final void start()
    {
        if (!isStarted())
        {
            if (getContext() == null)
            {
                throw new IllegalStateException("context not set");
            }
            if (shouldStart())
            {
                getContext().getExecutorService().execute(getRunnableTask());
                started = true;
                return;
            }
        }
    }

    public final void stop()
    {
        if (!isStarted())
        {
            return;
        }
        try
        {
            onStop();
        }
        catch (RuntimeException runtimeexception)
        {
            addError((new StringBuilder()).append("on stop: ").append(runtimeexception).toString(), runtimeexception);
        }
        started = false;
    }
}
