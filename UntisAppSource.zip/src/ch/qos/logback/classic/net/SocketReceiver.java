// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.classic.net;

import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.Context;
import ch.qos.logback.core.net.DefaultSocketConnector;
import ch.qos.logback.core.net.SocketConnector;
import ch.qos.logback.core.util.CloseUtil;
import java.io.EOFException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.ConnectException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.concurrent.RejectedExecutionException;
import javax.net.SocketFactory;

// Referenced classes of package ch.qos.logback.classic.net:
//            ReceiverBase

public class SocketReceiver extends ReceiverBase
    implements Runnable, ch.qos.logback.core.net.SocketConnector.ExceptionHandler
{

    private static final int DEFAULT_ACCEPT_CONNECTION_DELAY = 5000;
    private int acceptConnectionTimeout;
    private InetAddress address;
    private Future connectorTask;
    private int port;
    private String receiverId;
    private int reconnectionDelay;
    private String remoteHost;
    private volatile Socket socket;

    public SocketReceiver()
    {
        acceptConnectionTimeout = 5000;
    }

    private Future activateConnector(SocketConnector socketconnector)
    {
        try
        {
            socketconnector = getContext().getExecutorService().submit(socketconnector);
        }
        // Misplaced declaration of an exception variable
        catch (SocketConnector socketconnector)
        {
            return null;
        }
        return socketconnector;
    }

    private SocketConnector createConnector(InetAddress inetaddress, int i, int j, int k)
    {
        inetaddress = newConnector(inetaddress, i, j, k);
        inetaddress.setExceptionHandler(this);
        inetaddress.setSocketFactory(getSocketFactory());
        return inetaddress;
    }

    private void dispatchEvents(LoggerContext loggercontext)
    {
        socket.setSoTimeout(acceptConnectionTimeout);
        ObjectInputStream objectinputstream = new ObjectInputStream(socket.getInputStream());
        socket.setSoTimeout(0);
        addInfo((new StringBuilder()).append(receiverId).append("connection established").toString());
        do
        {
            ILoggingEvent iloggingevent;
            Logger logger;
            do
            {
                iloggingevent = (ILoggingEvent)objectinputstream.readObject();
                logger = loggercontext.getLogger(iloggingevent.getLoggerName());
            } while (!logger.isEnabledFor(iloggingevent.getLevel()));
            logger.callAppenders(iloggingevent);
        } while (true);
        loggercontext;
        addInfo((new StringBuilder()).append(receiverId).append("end-of-stream detected").toString());
        CloseUtil.closeQuietly(socket);
        socket = null;
        addInfo((new StringBuilder()).append(receiverId).append("connection closed").toString());
        return;
        loggercontext;
        addInfo((new StringBuilder()).append(receiverId).append("connection failed: ").append(loggercontext).toString());
        CloseUtil.closeQuietly(socket);
        socket = null;
        addInfo((new StringBuilder()).append(receiverId).append("connection closed").toString());
        return;
        loggercontext;
        addInfo((new StringBuilder()).append(receiverId).append("unknown event class: ").append(loggercontext).toString());
        CloseUtil.closeQuietly(socket);
        socket = null;
        addInfo((new StringBuilder()).append(receiverId).append("connection closed").toString());
        return;
        loggercontext;
        CloseUtil.closeQuietly(socket);
        socket = null;
        addInfo((new StringBuilder()).append(receiverId).append("connection closed").toString());
        throw loggercontext;
    }

    private Socket waitForConnectorToReturnASocket()
        throws InterruptedException
    {
        Socket socket1;
        try
        {
            socket1 = (Socket)connectorTask.get();
            connectorTask = null;
        }
        catch (ExecutionException executionexception)
        {
            return null;
        }
        return socket1;
    }

    public void connectionFailed(SocketConnector socketconnector, Exception exception)
    {
        if (exception instanceof InterruptedException)
        {
            addInfo("connector interrupted");
            return;
        }
        if (exception instanceof ConnectException)
        {
            addInfo((new StringBuilder()).append(receiverId).append("connection refused").toString());
            return;
        } else
        {
            addInfo((new StringBuilder()).append(receiverId).append(exception).toString());
            return;
        }
    }

    protected Runnable getRunnableTask()
    {
        return this;
    }

    protected SocketFactory getSocketFactory()
    {
        return SocketFactory.getDefault();
    }

    protected SocketConnector newConnector(InetAddress inetaddress, int i, int j, int k)
    {
        return new DefaultSocketConnector(inetaddress, i, j, k);
    }

    protected void onStop()
    {
        if (socket != null)
        {
            CloseUtil.closeQuietly(socket);
        }
    }

    public void run()
    {
        LoggerContext loggercontext = (LoggerContext)getContext();
_L5:
        if (Thread.currentThread().isInterrupted()) goto _L2; else goto _L1
_L1:
        Future future;
        connectorTask = activateConnector(createConnector(address, port, 0, reconnectionDelay));
        future = connectorTask;
        if (future != null) goto _L3; else goto _L2
_L2:
        addInfo("shutting down");
        return;
_L3:
        socket = waitForConnectorToReturnASocket();
        if (socket == null) goto _L2; else goto _L4
_L4:
        dispatchEvents(loggercontext);
          goto _L5
        InterruptedException interruptedexception;
        interruptedexception;
          goto _L2
    }

    public void setAcceptConnectionTimeout(int i)
    {
        acceptConnectionTimeout = i;
    }

    public void setPort(int i)
    {
        port = i;
    }

    public void setReconnectionDelay(int i)
    {
        reconnectionDelay = i;
    }

    public void setRemoteHost(String s)
    {
        remoteHost = s;
    }

    protected boolean shouldStart()
    {
        UnknownHostException unknownhostexception;
        int i;
        int j;
        if (port == 0)
        {
            addError("No port was configured for receiver. For more information, please visit http://logback.qos.ch/codes.html#receiver_no_port");
            j = 1;
        } else
        {
            j = 0;
        }
        i = j;
        if (remoteHost == null)
        {
            i = j + 1;
            addError("No host name or address was configured for receiver. For more information, please visit http://logback.qos.ch/codes.html#receiver_no_host");
        }
        if (reconnectionDelay == 0)
        {
            reconnectionDelay = 30000;
        }
        j = i;
        if (i != 0)
        {
            break MISSING_BLOCK_LABEL_67;
        }
        address = InetAddress.getByName(remoteHost);
        j = i;
_L1:
        if (j == 0)
        {
            receiverId = (new StringBuilder()).append("receiver ").append(remoteHost).append(":").append(port).append(": ").toString();
        }
        return j == 0;
        unknownhostexception;
        addError((new StringBuilder()).append("unknown host: ").append(remoteHost).toString());
        j = i + 1;
          goto _L1
    }
}
