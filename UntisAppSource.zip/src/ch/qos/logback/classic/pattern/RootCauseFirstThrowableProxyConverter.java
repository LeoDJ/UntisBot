// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.classic.pattern;

import ch.qos.logback.classic.spi.IThrowableProxy;
import ch.qos.logback.classic.spi.ThrowableProxyUtil;
import ch.qos.logback.core.CoreConstants;

// Referenced classes of package ch.qos.logback.classic.pattern:
//            ExtendedThrowableProxyConverter

public class RootCauseFirstThrowableProxyConverter extends ExtendedThrowableProxyConverter
{

    public RootCauseFirstThrowableProxyConverter()
    {
    }

    protected void recursiveAppendRootCauseFirst(StringBuilder stringbuilder, String s, int i, IThrowableProxy ithrowableproxy)
    {
        String s1 = s;
        if (ithrowableproxy.getCause() != null)
        {
            recursiveAppendRootCauseFirst(stringbuilder, s, i, ithrowableproxy.getCause());
            s1 = null;
        }
        ThrowableProxyUtil.indent(stringbuilder, i - 1);
        if (s1 != null)
        {
            stringbuilder.append(s1);
        }
        ThrowableProxyUtil.subjoinFirstLineRootCauseFirst(stringbuilder, ithrowableproxy);
        stringbuilder.append(CoreConstants.LINE_SEPARATOR);
        subjoinSTEPArray(stringbuilder, i, ithrowableproxy);
        s = ithrowableproxy.getSuppressed();
        if (s != null)
        {
            int k = s.length;
            for (int j = 0; j < k; j++)
            {
                recursiveAppendRootCauseFirst(stringbuilder, "Suppressed: ", i + 1, s[j]);
            }

        }
    }

    protected String throwableProxyToString(IThrowableProxy ithrowableproxy)
    {
        StringBuilder stringbuilder = new StringBuilder(2048);
        recursiveAppendRootCauseFirst(stringbuilder, null, 1, ithrowableproxy);
        return stringbuilder.toString();
    }
}
