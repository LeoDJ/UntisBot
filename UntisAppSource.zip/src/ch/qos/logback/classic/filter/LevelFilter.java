// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.classic.filter;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.filter.AbstractMatcherFilter;
import ch.qos.logback.core.spi.FilterReply;

public class LevelFilter extends AbstractMatcherFilter
{

    Level level;

    public LevelFilter()
    {
    }

    public FilterReply decide(ILoggingEvent iloggingevent)
    {
        if (!isStarted())
        {
            return FilterReply.NEUTRAL;
        }
        if (iloggingevent.getLevel().equals(level))
        {
            return onMatch;
        } else
        {
            return onMismatch;
        }
    }

    public volatile FilterReply decide(Object obj)
    {
        return decide((ILoggingEvent)obj);
    }

    public void setLevel(Level level1)
    {
        level = level1;
    }

    public void start()
    {
        if (level != null)
        {
            super.start();
        }
    }
}
