// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.classic.filter;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.filter.Filter;
import ch.qos.logback.core.spi.FilterReply;

public class ThresholdFilter extends Filter
{

    Level level;

    public ThresholdFilter()
    {
    }

    public FilterReply decide(ILoggingEvent iloggingevent)
    {
        if (!isStarted())
        {
            return FilterReply.NEUTRAL;
        }
        if (iloggingevent.getLevel().isGreaterOrEqual(level))
        {
            return FilterReply.NEUTRAL;
        } else
        {
            return FilterReply.DENY;
        }
    }

    public volatile FilterReply decide(Object obj)
    {
        return decide((ILoggingEvent)obj);
    }

    public void setLevel(String s)
    {
        level = Level.toLevel(s);
    }

    public void start()
    {
        if (level != null)
        {
            super.start();
        }
    }
}
