// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.classic.html;

import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.classic.spi.IThrowableProxy;
import ch.qos.logback.classic.spi.StackTraceElementProxy;
import ch.qos.logback.core.CoreConstants;
import ch.qos.logback.core.helpers.Transform;
import ch.qos.logback.core.html.IThrowableRenderer;

public class DefaultThrowableRenderer
    implements IThrowableRenderer
{

    static final String TRACE_PREFIX = "<br />&nbsp;&nbsp;&nbsp;&nbsp;";

    public DefaultThrowableRenderer()
    {
    }

    public void printFirstLine(StringBuilder stringbuilder, IThrowableProxy ithrowableproxy)
    {
        if (ithrowableproxy.getCommonFrames() > 0)
        {
            stringbuilder.append("<br />").append("Caused by: ");
        }
        stringbuilder.append(ithrowableproxy.getClassName()).append(": ").append(Transform.escapeTags(ithrowableproxy.getMessage()));
        stringbuilder.append(CoreConstants.LINE_SEPARATOR);
    }

    public void render(StringBuilder stringbuilder, ILoggingEvent iloggingevent)
    {
        iloggingevent = iloggingevent.getThrowableProxy();
        stringbuilder.append("<tr><td class=\"Exception\" colspan=\"6\">");
        for (; iloggingevent != null; iloggingevent = iloggingevent.getCause())
        {
            render(stringbuilder, ((IThrowableProxy) (iloggingevent)));
        }

        stringbuilder.append("</td></tr>");
    }

    void render(StringBuilder stringbuilder, IThrowableProxy ithrowableproxy)
    {
        printFirstLine(stringbuilder, ithrowableproxy);
        int j = ithrowableproxy.getCommonFrames();
        ithrowableproxy = ithrowableproxy.getStackTraceElementProxyArray();
        for (int i = 0; i < ithrowableproxy.length - j; i++)
        {
            StackTraceElementProxy stacktraceelementproxy = ithrowableproxy[i];
            stringbuilder.append("<br />&nbsp;&nbsp;&nbsp;&nbsp;");
            stringbuilder.append(Transform.escapeTags(stacktraceelementproxy.toString()));
            stringbuilder.append(CoreConstants.LINE_SEPARATOR);
        }

        if (j > 0)
        {
            stringbuilder.append("<br />&nbsp;&nbsp;&nbsp;&nbsp;");
            stringbuilder.append("\t... ").append(j).append(" common frames omitted").append(CoreConstants.LINE_SEPARATOR);
        }
    }

    public volatile void render(StringBuilder stringbuilder, Object obj)
    {
        render(stringbuilder, (ILoggingEvent)obj);
    }
}
