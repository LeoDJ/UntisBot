// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ch.qos.logback.classic.html;

import ch.qos.logback.core.html.CssBuilder;

public class UrlCssBuilder
    implements CssBuilder
{

    String url;

    public UrlCssBuilder()
    {
        url = "http://logback.qos.ch/css/classic.css";
    }

    public void addCss(StringBuilder stringbuilder)
    {
        stringbuilder.append("<link REL=StyleSheet HREF=\"");
        stringbuilder.append(url);
        stringbuilder.append("\" TITLE=\"Basic\" />");
    }

    public String getUrl()
    {
        return url;
    }

    public void setUrl(String s)
    {
        url = s;
    }
}
