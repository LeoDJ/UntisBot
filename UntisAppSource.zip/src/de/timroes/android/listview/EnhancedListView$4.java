// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package de.timroes.android.listview;

import android.widget.AbsListView;

// Referenced classes of package de.timroes.android.listview:
//            EnhancedListView

class this._cls0
    implements android.widget.lListener
{

    final EnhancedListView this$0;

    public void onScroll(AbsListView abslistview, int i, int j, int k)
    {
    }

    public void onScrollStateChanged(AbsListView abslistview, int i)
    {
        boolean flag = true;
        abslistview = EnhancedListView.this;
        if (i != 1)
        {
            flag = false;
        }
        EnhancedListView.access$702(abslistview, flag);
    }

    ()
    {
        this$0 = EnhancedListView.this;
        super();
    }
}
