// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package de.timroes.android.listview;


// Referenced classes of package de.timroes.android.listview:
//            EnhancedListView

public static abstract class 
{

    public void discard()
    {
    }

    public String getTitle()
    {
        return null;
    }

    public abstract void undo();

    public ()
    {
    }
}
