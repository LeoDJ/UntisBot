// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package de.timroes.android.listview;

import android.view.View;
import com.nineoldandroids.animation.Animator;
import com.nineoldandroids.animation.AnimatorListenerAdapter;

// Referenced classes of package de.timroes.android.listview:
//            EnhancedListView

class dapter extends AnimatorListenerAdapter
{

    final EnhancedListView this$0;
    final View val$childView;
    final int val$position;
    final View val$view;

    public void onAnimationEnd(Animator animator)
    {
        EnhancedListView.access$000(EnhancedListView.this, val$view, val$childView, val$position);
    }

    dapter()
    {
        this$0 = final_enhancedlistview;
        val$view = view1;
        val$childView = view2;
        val$position = I.this;
        super();
    }
}
