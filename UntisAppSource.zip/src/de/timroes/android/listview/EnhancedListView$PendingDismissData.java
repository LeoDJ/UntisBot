// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package de.timroes.android.listview;

import android.view.View;

// Referenced classes of package de.timroes.android.listview:
//            EnhancedListView

private class childView
    implements Comparable
{

    public View childView;
    public int position;
    final EnhancedListView this$0;
    public View view;

    public int compareTo(childView childview)
    {
        return childview.position - position;
    }

    public volatile int compareTo(Object obj)
    {
        return compareTo((compareTo)obj);
    }

    (int i, View view1, View view2)
    {
        this$0 = EnhancedListView.this;
        super();
        position = i;
        view = view1;
        childView = view2;
    }
}
