// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package de.timroes.android.listview;

import android.view.View;
import com.nineoldandroids.animation.Animator;
import com.nineoldandroids.animation.AnimatorListenerAdapter;
import com.nineoldandroids.view.ViewHelper;
import java.util.Iterator;
import java.util.List;
import java.util.SortedSet;

// Referenced classes of package de.timroes.android.listview:
//            EnhancedListView

class dapter extends AnimatorListenerAdapter
{

    final EnhancedListView this$0;
    final View val$dismissView;
    final int val$originalHeight;

    public void onAnimationEnd(Animator animator)
    {
        animator = ((Animator) (EnhancedListView.access$100(EnhancedListView.this)));
        animator;
        JVM INSTR monitorenter ;
        EnhancedListView.access$206(EnhancedListView.this);
        EnhancedListView.access$300(EnhancedListView.this).remove(val$dismissView);
        boolean flag;
        if (EnhancedListView.access$200(EnhancedListView.this) == 0)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        animator;
        JVM INSTR monitorexit ;
        if (!flag)
        {
            break MISSING_BLOCK_LABEL_217;
        }
        for (animator = EnhancedListView.access$400(EnhancedListView.this).iterator(); animator.hasNext(); EnhancedListView.access$608(EnhancedListView.this))
        {
            ndingDismissData ndingdismissdata = (ndingDismissData)animator.next();
            EnhancedListView.access$500(EnhancedListView.this).onDismiss(EnhancedListView.this, ndingdismissdata.position);
        }

        break MISSING_BLOCK_LABEL_130;
        Exception exception;
        exception;
        animator;
        JVM INSTR monitorexit ;
        throw exception;
        ndingDismissData ndingdismissdata1;
        android.view.ams ams;
        for (animator = EnhancedListView.access$400(EnhancedListView.this).iterator(); animator.hasNext(); ndingdismissdata1.childView.setLayoutParams(ams))
        {
            ndingdismissdata1 = (ndingDismissData)animator.next();
            ViewHelper.setAlpha(ndingdismissdata1.view, 1.0F);
            ViewHelper.setTranslationX(ndingdismissdata1.view, 0.0F);
            ams = ndingdismissdata1.childView.getLayoutParams();
            ams.height = val$originalHeight;
        }

        EnhancedListView.access$400(EnhancedListView.this).clear();
    }

    DismissCallback()
    {
        this$0 = final_enhancedlistview;
        val$dismissView = view;
        val$originalHeight = I.this;
        super();
    }
}
