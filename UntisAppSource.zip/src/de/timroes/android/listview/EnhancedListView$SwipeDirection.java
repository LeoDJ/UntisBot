// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package de.timroes.android.listview;


// Referenced classes of package de.timroes.android.listview:
//            EnhancedListView

public static final class A extends Enum
{

    private static final END $VALUES[];
    public static final END BOTH;
    public static final END END;
    public static final END START;

    public static A valueOf(String s)
    {
        return (A)Enum.valueOf(de/timroes/android/listview/EnhancedListView$SwipeDirection, s);
    }

    public static A[] values()
    {
        return (A[])$VALUES.clone();
    }

    static 
    {
        BOTH = new <init>("BOTH", 0);
        START = new <init>("START", 1);
        END = new <init>("END", 2);
        $VALUES = (new .VALUES[] {
            BOTH, START, END
        });
    }

    private A(String s, int i)
    {
        super(s, i);
    }
}
