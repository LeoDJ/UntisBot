// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package de.timroes.android.listview;


// Referenced classes of package de.timroes.android.listview:
//            EnhancedListView

static class ipeDirection
{

    static final int $SwitchMap$de$timroes$android$listview$EnhancedListView$SwipeDirection[];

    static 
    {
        $SwitchMap$de$timroes$android$listview$EnhancedListView$SwipeDirection = new int[ipeDirection.values().length];
        try
        {
            $SwitchMap$de$timroes$android$listview$EnhancedListView$SwipeDirection[ipeDirection.BOTH.ordinal()] = 1;
        }
        catch (NoSuchFieldError nosuchfielderror2) { }
        try
        {
            $SwitchMap$de$timroes$android$listview$EnhancedListView$SwipeDirection[ipeDirection.START.ordinal()] = 2;
        }
        catch (NoSuchFieldError nosuchfielderror1) { }
        try
        {
            $SwitchMap$de$timroes$android$listview$EnhancedListView$SwipeDirection[ipeDirection.END.ordinal()] = 3;
        }
        catch (NoSuchFieldError nosuchfielderror)
        {
            return;
        }
    }
}
