// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package de.timroes.android.listview;


// Referenced classes of package de.timroes.android.listview:
//            EnhancedListView

public static final class  extends Enum
{

    private static final COLLAPSED_POPUP $VALUES[];
    public static final COLLAPSED_POPUP COLLAPSED_POPUP;
    public static final COLLAPSED_POPUP MULTILEVEL_POPUP;
    public static final COLLAPSED_POPUP SINGLE_POPUP;

    public static  valueOf(String s)
    {
        return ()Enum.valueOf(de/timroes/android/listview/EnhancedListView$UndoStyle, s);
    }

    public static [] values()
    {
        return ([])$VALUES.clone();
    }

    static 
    {
        SINGLE_POPUP = new <init>("SINGLE_POPUP", 0);
        MULTILEVEL_POPUP = new <init>("MULTILEVEL_POPUP", 1);
        COLLAPSED_POPUP = new <init>("COLLAPSED_POPUP", 2);
        $VALUES = (new .VALUES[] {
            SINGLE_POPUP, MULTILEVEL_POPUP, COLLAPSED_POPUP
        });
    }

    private (String s, int i)
    {
        super(s, i);
    }
}
