// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package de.timroes.android.listview;

import android.view.View;
import com.nineoldandroids.animation.ValueAnimator;

// Referenced classes of package de.timroes.android.listview:
//            EnhancedListView

class val.listItemView
    implements com.nineoldandroids.animation.torUpdateListener
{

    final EnhancedListView this$0;
    final View val$listItemView;
    final android.view.ams val$lp;

    public void onAnimationUpdate(ValueAnimator valueanimator)
    {
        val$lp.height = ((Integer)valueanimator.getAnimatedValue()).intValue();
        val$listItemView.setLayoutParams(val$lp);
    }

    matorUpdateListener()
    {
        this$0 = final_enhancedlistview;
        val$lp = ams;
        val$listItemView = View.this;
        super();
    }
}
