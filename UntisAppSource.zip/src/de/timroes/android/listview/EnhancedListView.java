// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package de.timroes.android.listview;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.AbsListView;
import android.widget.ListView;
import com.nineoldandroids.animation.Animator;
import com.nineoldandroids.animation.AnimatorListenerAdapter;
import com.nineoldandroids.animation.ValueAnimator;
import com.nineoldandroids.view.ViewHelper;
import com.nineoldandroids.view.ViewPropertyAnimator;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;

public class EnhancedListView extends ListView
{
    public static interface OnDismissCallback
    {

        public abstract Undoable onDismiss(EnhancedListView enhancedlistview, int i);
    }

    private class PendingDismissData
        implements Comparable
    {

        public View childView;
        public int position;
        final EnhancedListView this$0;
        public View view;

        public int compareTo(PendingDismissData pendingdismissdata)
        {
            return pendingdismissdata.position - position;
        }

        public volatile int compareTo(Object obj)
        {
            return compareTo((PendingDismissData)obj);
        }

        PendingDismissData(int i, View view1, View view2)
        {
            this$0 = EnhancedListView.this;
            super();
            position = i;
            view = view1;
            childView = view2;
        }
    }

    public static final class SwipeDirection extends Enum
    {

        private static final SwipeDirection $VALUES[];
        public static final SwipeDirection BOTH;
        public static final SwipeDirection END;
        public static final SwipeDirection START;

        public static SwipeDirection valueOf(String s)
        {
            return (SwipeDirection)Enum.valueOf(de/timroes/android/listview/EnhancedListView$SwipeDirection, s);
        }

        public static SwipeDirection[] values()
        {
            return (SwipeDirection[])$VALUES.clone();
        }

        static 
        {
            BOTH = new SwipeDirection("BOTH", 0);
            START = new SwipeDirection("START", 1);
            END = new SwipeDirection("END", 2);
            $VALUES = (new SwipeDirection[] {
                BOTH, START, END
            });
        }

        private SwipeDirection(String s, int i)
        {
            super(s, i);
        }
    }

    public static final class UndoStyle extends Enum
    {

        private static final UndoStyle $VALUES[];
        public static final UndoStyle COLLAPSED_POPUP;
        public static final UndoStyle MULTILEVEL_POPUP;
        public static final UndoStyle SINGLE_POPUP;

        public static UndoStyle valueOf(String s)
        {
            return (UndoStyle)Enum.valueOf(de/timroes/android/listview/EnhancedListView$UndoStyle, s);
        }

        public static UndoStyle[] values()
        {
            return (UndoStyle[])$VALUES.clone();
        }

        static 
        {
            SINGLE_POPUP = new UndoStyle("SINGLE_POPUP", 0);
            MULTILEVEL_POPUP = new UndoStyle("MULTILEVEL_POPUP", 1);
            COLLAPSED_POPUP = new UndoStyle("COLLAPSED_POPUP", 2);
            $VALUES = (new UndoStyle[] {
                SINGLE_POPUP, MULTILEVEL_POPUP, COLLAPSED_POPUP
            });
        }

        private UndoStyle(String s, int i)
        {
            super(s, i);
        }
    }

    public static abstract class Undoable
    {

        public void discard()
        {
        }

        public String getTitle()
        {
            return null;
        }

        public abstract void undo();

        public Undoable()
        {
        }
    }


    private List mAnimatedViews;
    private final Object mAnimationLock[];
    private long mAnimationTime;
    private int mDismissAnimationRefCount;
    private OnDismissCallback mDismissCallback;
    private int mDownPosition;
    private float mDownX;
    private int mMaxFlingVelocity;
    private int mMinFlingVelocity;
    private SortedSet mPendingDismisses;
    private float mScreenDensity;
    private int mSlop;
    private SwipeDirection mSwipeDirection;
    private View mSwipeDownChild;
    private View mSwipeDownView;
    private boolean mSwipeEnabled;
    private boolean mSwipePaused;
    private boolean mSwiping;
    private int mSwipingLayout;
    private boolean mTouchBeforeAutoHide;
    private int mValidDelayedMsgId;
    private VelocityTracker mVelocityTracker;
    private int mViewWidth;

    public EnhancedListView(Context context)
    {
        super(context);
        mAnimationLock = new Object[0];
        mTouchBeforeAutoHide = true;
        mSwipeDirection = SwipeDirection.BOTH;
        mPendingDismisses = new TreeSet();
        mAnimatedViews = new LinkedList();
        mViewWidth = 1;
        init(context);
    }

    public EnhancedListView(Context context, AttributeSet attributeset)
    {
        super(context, attributeset);
        mAnimationLock = new Object[0];
        mTouchBeforeAutoHide = true;
        mSwipeDirection = SwipeDirection.BOTH;
        mPendingDismisses = new TreeSet();
        mAnimatedViews = new LinkedList();
        mViewWidth = 1;
        init(context);
    }

    public EnhancedListView(Context context, AttributeSet attributeset, int i)
    {
        super(context, attributeset, i);
        mAnimationLock = new Object[0];
        mTouchBeforeAutoHide = true;
        mSwipeDirection = SwipeDirection.BOTH;
        mPendingDismisses = new TreeSet();
        mAnimatedViews = new LinkedList();
        mViewWidth = 1;
        init(context);
    }

    private void init(Context context)
    {
        ViewConfiguration viewconfiguration = ViewConfiguration.get(context);
        mSlop = viewconfiguration.getScaledTouchSlop();
        mMinFlingVelocity = viewconfiguration.getScaledMinimumFlingVelocity();
        mMaxFlingVelocity = viewconfiguration.getScaledMaximumFlingVelocity();
        mAnimationTime = context.getResources().getInteger(0x10e0000);
        mScreenDensity = getResources().getDisplayMetrics().density;
        setOnScrollListener(makeScrollListener());
    }

    private boolean isSwipeDirectionValid(float f)
    {
        int i;
        boolean flag = true;
        i = ((flag) ? 1 : 0);
        if (android.os.Build.VERSION.SDK_INT >= 17)
        {
            i = ((flag) ? 1 : 0);
            if (getLayoutDirection() == 1)
            {
                i = -1;
            }
        }
        static class _cls5
        {

            static final int $SwitchMap$de$timroes$android$listview$EnhancedListView$SwipeDirection[];

            static 
            {
                $SwitchMap$de$timroes$android$listview$EnhancedListView$SwipeDirection = new int[SwipeDirection.values().length];
                try
                {
                    $SwitchMap$de$timroes$android$listview$EnhancedListView$SwipeDirection[SwipeDirection.BOTH.ordinal()] = 1;
                }
                catch (NoSuchFieldError nosuchfielderror2) { }
                try
                {
                    $SwitchMap$de$timroes$android$listview$EnhancedListView$SwipeDirection[SwipeDirection.START.ordinal()] = 2;
                }
                catch (NoSuchFieldError nosuchfielderror1) { }
                try
                {
                    $SwitchMap$de$timroes$android$listview$EnhancedListView$SwipeDirection[SwipeDirection.END.ordinal()] = 3;
                }
                catch (NoSuchFieldError nosuchfielderror)
                {
                    return;
                }
            }
        }

        _cls5..SwitchMap.de.timroes.android.listview.EnhancedListView.SwipeDirection[mSwipeDirection.ordinal()];
        JVM INSTR tableswitch 2 3: default 56
    //                   2 58
    //                   3 69;
           goto _L1 _L2 _L3
_L1:
        return true;
_L2:
        if ((float)i * f >= 0.0F)
        {
            return false;
        }
        continue; /* Loop/switch isn't completed */
_L3:
        if ((float)i * f <= 0.0F)
        {
            return false;
        }
        if (true) goto _L1; else goto _L4
_L4:
    }

    private android.widget.AbsListView.OnScrollListener makeScrollListener()
    {
        return new android.widget.AbsListView.OnScrollListener() {

            final EnhancedListView this$0;

            public void onScroll(AbsListView abslistview, int i, int j, int k)
            {
            }

            public void onScrollStateChanged(AbsListView abslistview, int i)
            {
                boolean flag = true;
                abslistview = EnhancedListView.this;
                if (i != 1)
                {
                    flag = false;
                }
                abslistview.mSwipePaused = flag;
            }

            
            {
                this$0 = EnhancedListView.this;
                super();
            }
        };
    }

    private void performDismiss(final View dismissView, final View listItemView, int i)
    {
        final android.view.ViewGroup.LayoutParams lp = listItemView.getLayoutParams();
        final int originalHeight = listItemView.getHeight();
        ValueAnimator valueanimator = ValueAnimator.ofInt(new int[] {
            originalHeight, 1
        }).setDuration(mAnimationTime);
        valueanimator.addListener(new AnimatorListenerAdapter() {

            final EnhancedListView this$0;
            final View val$dismissView;
            final int val$originalHeight;

            public void onAnimationEnd(Animator animator)
            {
                animator = ((Animator) (mAnimationLock));
                animator;
                JVM INSTR monitorenter ;
                int i = 
// JavaClassFileOutputException: get_constant: invalid tag

            
            {
                this$0 = EnhancedListView.this;
                dismissView = view;
                originalHeight = i;
                super();
            }
        });
        valueanimator.addUpdateListener(new com.nineoldandroids.animation.ValueAnimator.AnimatorUpdateListener() {

            final EnhancedListView this$0;
            final View val$listItemView;
            final android.view.ViewGroup.LayoutParams val$lp;

            public void onAnimationUpdate(ValueAnimator valueanimator1)
            {
                lp.height = ((Integer)valueanimator1.getAnimatedValue()).intValue();
                listItemView.setLayoutParams(lp);
            }

            
            {
                this$0 = EnhancedListView.this;
                lp = layoutparams;
                listItemView = view;
                super();
            }
        });
        mPendingDismisses.add(new PendingDismissData(i, dismissView, listItemView));
        valueanimator.start();
    }

    private void slideOutView(final View view, final View childView, final int position, boolean flag)
    {
label0:
        {
            synchronized (mAnimationLock)
            {
                if (!mAnimatedViews.contains(view))
                {
                    break label0;
                }
            }
            return;
        }
        mDismissAnimationRefCount = mDismissAnimationRefCount + 1;
        mAnimatedViews.add(view);
        obj;
        JVM INSTR monitorexit ;
        obj = ViewPropertyAnimator.animate(view);
        float f;
        if (flag)
        {
            f = mViewWidth;
        } else
        {
            f = -mViewWidth;
        }
        ((ViewPropertyAnimator) (obj)).translationX(f).alpha(0.0F).setDuration(mAnimationTime).setListener(new AnimatorListenerAdapter() {

            final EnhancedListView this$0;
            final View val$childView;
            final int val$position;
            final View val$view;

            public void onAnimationEnd(Animator animator)
            {
                performDismiss(view, childView, position);
            }

            
            {
                this$0 = EnhancedListView.this;
                view = view1;
                childView = view2;
                position = i;
                super();
            }
        });
        return;
        view;
        obj;
        JVM INSTR monitorexit ;
        throw view;
    }

    public void delete(int i)
    {
        if (mDismissCallback == null)
        {
            throw new IllegalStateException("You must set an OnDismissCallback, before deleting items.");
        }
        if (i < 0 || i >= getCount())
        {
            throw new IndexOutOfBoundsException(String.format("Tried to delete item %d. #items in list: %d", new Object[] {
                Integer.valueOf(i), Integer.valueOf(getCount())
            }));
        }
        View view2 = getChildAt(i - getFirstVisiblePosition());
        View view = null;
        if (mSwipingLayout > 0)
        {
            view = view2.findViewById(mSwipingLayout);
        }
        View view1 = view;
        if (view == null)
        {
            view1 = view2;
        }
        slideOutView(view1, view2, i, true);
    }

    public EnhancedListView disableSwipeToDismiss()
    {
        mSwipeEnabled = false;
        return this;
    }

    public EnhancedListView enableSwipeToDismiss()
    {
        if (mDismissCallback == null)
        {
            throw new IllegalStateException("You must pass an OnDismissCallback to the list before enabling Swipe to Dismiss.");
        } else
        {
            mSwipeEnabled = true;
            return this;
        }
    }

    public boolean onTouchEvent(MotionEvent motionevent)
    {
        if (!mSwipeEnabled)
        {
            return super.onTouchEvent(motionevent);
        }
        if (mViewWidth < 2)
        {
            mViewWidth = getWidth();
        }
        motionevent.getActionMasked();
        JVM INSTR tableswitch 0 2: default 60
    //                   0 66
    //                   1 296
    //                   2 630;
           goto _L1 _L2 _L3 _L4
_L1:
        return super.onTouchEvent(motionevent);
_L2:
        Object obj;
        int i;
        int j;
        int k;
        int l;
        int i1;
        int j1;
        if (mSwipePaused)
        {
            return super.onTouchEvent(motionevent);
        }
        obj = new Rect();
        j = getChildCount();
        int ai[] = new int[2];
        getLocationOnScreen(ai);
        k = (int)motionevent.getRawX();
        l = ai[0];
        i1 = (int)motionevent.getRawY();
        j1 = ai[1];
        i = getHeaderViewsCount();
_L13:
        if (i >= j) goto _L6; else goto _L5
_L5:
        View view = getChildAt(i);
        if (view == null) goto _L8; else goto _L7
_L7:
        view.getHitRect(((Rect) (obj)));
        if (!((Rect) (obj)).contains(k - l, i1 - j1)) goto _L8; else goto _L9
_L9:
        if (mSwipingLayout <= 0) goto _L11; else goto _L10
_L10:
        obj = view.findViewById(mSwipingLayout);
        if (obj == null) goto _L11; else goto _L12
_L12:
        mSwipeDownView = ((View) (obj));
        mSwipeDownChild = view;
_L6:
        if (mSwipeDownView != null)
        {
            mDownX = motionevent.getRawX();
            mDownPosition = getPositionForView(mSwipeDownView) - getHeaderViewsCount();
            mVelocityTracker = VelocityTracker.obtain();
            mVelocityTracker.addMovement(motionevent);
        }
        super.onTouchEvent(motionevent);
        return true;
_L11:
        mSwipeDownChild = view;
        mSwipeDownView = view;
        if (true) goto _L6; else goto _L8
_L8:
        i++;
          goto _L13
_L3:
        if (mVelocityTracker == null)
        {
            continue; /* Loop/switch isn't completed */
        }
        float f = motionevent.getRawX() - mDownX;
        mVelocityTracker.addMovement(motionevent);
        mVelocityTracker.computeCurrentVelocity(1000);
        float f2 = Math.abs(mVelocityTracker.getXVelocity());
        float f4 = Math.abs(mVelocityTracker.getYVelocity());
        boolean flag1 = false;
        boolean flag3 = false;
        boolean flag;
        boolean flag2;
        if (Math.abs(f) > (float)(mViewWidth / 2) && mSwiping)
        {
            flag = true;
            if (f > 0.0F)
            {
                flag2 = true;
            } else
            {
                flag2 = false;
            }
        } else
        {
            flag = flag1;
            flag2 = flag3;
            if ((float)mMinFlingVelocity <= f2)
            {
                flag = flag1;
                flag2 = flag3;
                if (f2 <= (float)mMaxFlingVelocity)
                {
                    flag = flag1;
                    flag2 = flag3;
                    if (f4 < f2)
                    {
                        flag = flag1;
                        flag2 = flag3;
                        if (mSwiping)
                        {
                            flag = flag1;
                            flag2 = flag3;
                            if (isSwipeDirectionValid(mVelocityTracker.getXVelocity()))
                            {
                                flag = flag1;
                                flag2 = flag3;
                                if (f >= (float)mViewWidth * 0.2F)
                                {
                                    flag = true;
                                    if (mVelocityTracker.getXVelocity() > 0.0F)
                                    {
                                        flag2 = true;
                                    } else
                                    {
                                        flag2 = false;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        if (!flag)
        {
            break; /* Loop/switch isn't completed */
        }
        slideOutView(mSwipeDownView, mSwipeDownChild, mDownPosition, flag2);
_L16:
        mVelocityTracker = null;
        mDownX = 0.0F;
        mSwipeDownView = null;
        mSwipeDownChild = null;
        mDownPosition = -1;
        mSwiping = false;
        if (true) goto _L1; else goto _L14
_L14:
        if (!mSwiping) goto _L16; else goto _L15
_L15:
        ViewPropertyAnimator.animate(mSwipeDownView).translationX(0.0F).alpha(1.0F).setDuration(mAnimationTime).setListener(null);
          goto _L16
_L4:
        if (mVelocityTracker != null && !mSwipePaused)
        {
            mVelocityTracker.addMovement(motionevent);
            float f3 = motionevent.getRawX() - mDownX;
            float f1;
            if (isSwipeDirectionValid(f3))
            {
                f1 = f3;
                if (Math.abs(f3) > (float)mSlop)
                {
                    mSwiping = true;
                    requestDisallowInterceptTouchEvent(true);
                    MotionEvent motionevent1 = MotionEvent.obtain(motionevent);
                    motionevent1.setAction(motionevent.getActionIndex() << 8 | 3);
                    super.onTouchEvent(motionevent1);
                    f1 = f3;
                }
            } else
            {
                mDownX = motionevent.getRawX();
                f1 = 0.0F;
            }
            if (mSwiping)
            {
                ViewHelper.setTranslationX(mSwipeDownView, f1);
                ViewHelper.setAlpha(mSwipeDownView, Math.max(0.0F, Math.min(1.0F, 1.0F - (2.0F * Math.abs(f1)) / (float)mViewWidth)));
                return true;
            }
        }
        if (true) goto _L1; else goto _L17
_L17:
    }

    public EnhancedListView setDismissCallback(OnDismissCallback ondismisscallback)
    {
        mDismissCallback = ondismisscallback;
        return this;
    }

    public EnhancedListView setRequireTouchBeforeDismiss(boolean flag)
    {
        mTouchBeforeAutoHide = flag;
        return this;
    }

    public EnhancedListView setSwipeDirection(SwipeDirection swipedirection)
    {
        mSwipeDirection = swipedirection;
        return this;
    }

    public EnhancedListView setSwipingLayout(int i)
    {
        mSwipingLayout = i;
        return this;
    }





/*
    static int access$206(EnhancedListView enhancedlistview)
    {
        int i = enhancedlistview.mDismissAnimationRefCount - 1;
        enhancedlistview.mDismissAnimationRefCount = i;
        return i;
    }

*/





/*
    static int access$608(EnhancedListView enhancedlistview)
    {
        int i = enhancedlistview.mValidDelayedMsgId;
        enhancedlistview.mValidDelayedMsgId = i + 1;
        return i;
    }

*/


/*
    static boolean access$702(EnhancedListView enhancedlistview, boolean flag)
    {
        enhancedlistview.mSwipePaused = flag;
        return flag;
    }

*/
}
