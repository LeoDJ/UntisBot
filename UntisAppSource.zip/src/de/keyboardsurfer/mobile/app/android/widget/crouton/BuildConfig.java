// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package de.keyboardsurfer.mobile.app.android.widget.crouton;


public final class BuildConfig
{

    public static final String BUILD_TYPE = "release";
    public static final boolean DEBUG = false;
    public static final String FLAVOR = "";
    public static final String PACKAGE_NAME = "de.keyboardsurfer.mobile.app.android.widget.crouton";
    public static final int VERSION_CODE = 7;
    public static final String VERSION_NAME = "1.8.4";

    public BuildConfig()
    {
    }
}
