// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package de.keyboardsurfer.android.widget.crouton;


// Referenced classes of package de.keyboardsurfer.android.widget.crouton:
//            Manager

private static final class 
{

    public static final int ADD_CROUTON_TO_VIEW = 0xc20074dd;
    public static final int DISPLAY_CROUTON = 0xc2007;
    public static final int REMOVE_CROUTON = 0xc2007de1;

    private ()
    {
    }
}
